<?php
/**
 * Admin view: settings-form.php
 */
defined( 'ABSPATH' ) || exit;
?>
<table class="form-table" role="presentation">
    <?php do_settings_fields( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_form', 'wcf_form_section' ); ?>
</table>
