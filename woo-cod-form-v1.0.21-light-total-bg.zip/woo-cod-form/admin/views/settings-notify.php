<?php
/**
 * Admin view: settings-notify.php
 */
defined( 'ABSPATH' ) || exit;
?>
<table class="form-table" role="presentation">
    <?php do_settings_fields( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_notify', 'wcf_notify_section' ); ?>
</table>
