<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wcf-card-panel">
    <?php do_settings_sections( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_templates' ); ?>
</div>
