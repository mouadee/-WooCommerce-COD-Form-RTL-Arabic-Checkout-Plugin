<?php
/**
 * Admin view: settings-general.php
 *
 * Rendered inside a <form> by Admin_Panel::render_settings_tab().
 * Settings API fields are already registered by Settings_Manager.
 * This file outputs only the settings table via do_settings_fields().
 */
defined( 'ABSPATH' ) || exit;
?>
<table class="form-table" role="presentation">
    <?php do_settings_fields( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_general', 'wcf_general_section' ); ?>
</table>
