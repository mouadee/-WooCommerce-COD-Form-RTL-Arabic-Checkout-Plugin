<?php
/**
 * Admin view: settings-conversion.php
 */
defined( 'ABSPATH' ) || exit;
?>
<table class="form-table" role="presentation">
    <?php do_settings_fields( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_conversion', 'wcf_conversion_section' ); ?>
</table>
