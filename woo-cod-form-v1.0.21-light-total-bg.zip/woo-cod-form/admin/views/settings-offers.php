<?php defined( 'ABSPATH' ) || exit; ?>
<div class="wcf-card-panel wcf-offers-admin-page" dir="rtl">
    <div class="wcf-settings-head">
        <span class="wcf-settings-icon">🎁</span>
        <div>
            <h2><?php esc_html_e( 'العروض والباقات', 'woo-cod-form' ); ?></h2>
            <p><?php esc_html_e( 'أنشئ 3 بطاقات عروض واضحة لرفع متوسط قيمة الطلب. يتم حفظ الباقة وتطبيق السعر النهائي في WooCommerce من السيرفر.', 'woo-cod-form' ); ?></p>
        </div>
    </div>
    <?php do_settings_sections( \WCF\Modules\Admin\Admin_Panel::MENU_SLUG . '_offers' ); ?>
</div>
