/**
 * File: admin/js/admin-panel.js
 *
 * Admin panel JavaScript for WooCommerce COD Form.
 * Minimal — the WP Settings API handles most interactions server-side.
 *
 * Handles:
 *   - Dependency toggles (e.g. hide timer fields when timer is disabled)
 */
( function ( $ ) {
    'use strict';

    $( function () {

        // Toggle timer duration + message visibility based on enable checkbox.
        const timerCheck = $( '#wcf_timer_enabled' );

        function toggleTimerFields() {
            const on = timerCheck.is( ':checked' );
            $( '#wcf_timer_minutes, #wcf_timer_message' )
                .closest( 'tr' )
                .toggle( on );
        }

        if ( timerCheck.length ) {
            toggleTimerFields();
            timerCheck.on( 'change', toggleTimerFields );
        }

        // Toggle social proof message field.
        const socialCheck = $( '#wcf_social_enabled' );

        function toggleSocialField() {
            $( '#wcf_social_message' ).closest( 'tr' ).toggle( socialCheck.is( ':checked' ) );
        }

        if ( socialCheck.length ) {
            toggleSocialField();
            socialCheck.on( 'change', toggleSocialField );
        }

    } );

} )( jQuery );
