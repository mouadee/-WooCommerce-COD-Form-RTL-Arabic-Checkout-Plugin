/**
 * File: public/js/cod-form.js
 *
 * Handles all frontend COD form interactions:
 *   - Quantity stepper (+/- buttons)
 *   - Variation selection → live price update (via AJAX)
 *   - Client-side field validation (UX only — server re-validates)
 *   - Form AJAX submission → success / error handling
 *   - Inline confirmation reveal or page redirect
 *   - Countdown timer
 *   - Social proof cycling
 *
 * No framework dependency. Pure ES2020.
 * All text strings come from wcfData.i18n (localised by PHP).
 */

( function () {
    'use strict';

    // -----------------------------------------------------------------------
    // Guard
    // -----------------------------------------------------------------------

    const DATA = window.wcfData;

    if ( ! DATA ) {
        return;
    }

    // -----------------------------------------------------------------------
    // DOM refs
    // -----------------------------------------------------------------------

    function $( sel, ctx ) {
        return ( ctx || document ).querySelector( sel );
    }

    function $$( sel, ctx ) {
        return Array.from( ( ctx || document ).querySelectorAll( sel ) );
    }

    const form       = $( '#wcf-order-form' );
    const msgBox     = $( '#wcf-form-messages' );
    const submitBtn  = $( '#wcf-submit-btn' );

    if ( ! form ) {
        return;
    }

    // -----------------------------------------------------------------------
    // Quantity stepper
    // -----------------------------------------------------------------------

    const qtyInput = $( '.wcf-qty-input', form );

    function qtyBounds() {
        return {
            min: Math.max( 1, parseInt( qtyInput?.min || '1', 10 ) || 1 ),
            max: Math.max( 1, parseInt( qtyInput?.max || DATA.maxQuantity || '5', 10 ) || 5 )
        };
    }

    function normaliseQty() {
        if ( ! qtyInput ) return 1;
        const bounds = qtyBounds();
        let value = parseInt( qtyInput.value || bounds.min, 10 );
        if ( Number.isNaN( value ) ) value = bounds.min;
        value = Math.min( bounds.max, Math.max( bounds.min, value ) );
        qtyInput.value = value;
        return value;
    }

    $( '.wcf-qty-minus', form )?.addEventListener( 'click', () => {
        const bounds = qtyBounds();
        qtyInput.value = Math.max( bounds.min, normaliseQty() - 1 );
        updateTotalPrice();
    } );

    $( '.wcf-qty-plus', form )?.addEventListener( 'click', () => {
        const bounds = qtyBounds();
        qtyInput.value = Math.min( bounds.max, normaliseQty() + 1 );
        updateTotalPrice();
    } );

    qtyInput?.addEventListener( 'input', updateTotalPrice );
    qtyInput?.addEventListener( 'change', updateTotalPrice );

    const selectedBundle = $( '#wcf-selected-bundle', form );
    $$( '.wcf-bundle-card', form ).forEach( card => {
        card.addEventListener( 'click', () => {
            $$( '.wcf-bundle-card', form ).forEach( c => c.classList.remove( 'active' ) );
            card.classList.add( 'active' );
            if ( selectedBundle ) selectedBundle.value = card.dataset.bundleId || '';
            if ( qtyInput ) qtyInput.value = card.dataset.qty || '1';
            updateTotalPrice();
        } );
    } );

    $$( '.wcf-offer-pill', form ).forEach( pill => {
        pill.addEventListener( 'click', () => {
            if ( qtyInput ) { qtyInput.value = pill.dataset.qty || '1'; updateTotalPrice(); }
        } );
    } );

    // -----------------------------------------------------------------------
    // Variation selector → live price update
    // -----------------------------------------------------------------------

    const variationSel  = $( 'select[name="variation_id"]', form );
    const variationHid  = $( '#wcf-variation-id', form );
    const priceDisplay  = $( '#wcf-price-value' );

    let currentPrice = DATA.product?.price ?? 0;

    if ( variationSel ) {
        variationSel.addEventListener( 'change', function () {
            const selected = this.options[ this.selectedIndex ];
            variationHid && ( variationHid.value = this.value );

            if ( this.value ) {
                const price    = parseFloat( selected.dataset.price || 0 );
                const priceHtml = selected.dataset.priceHtml || '';
                currentPrice = price;
                if ( priceDisplay && priceHtml && ! $( '.wcf-bundle-card', form ) ) {
                    priceDisplay.innerHTML = priceHtml;
                }
            } else {
                currentPrice = DATA.product?.price ?? 0;
                if ( priceDisplay && ! $( '.wcf-bundle-card', form ) ) {
                    priceDisplay.innerHTML = DATA.product?.price_html ?? '';
                }
            }

            updateTotalPrice();
        } );
    }

    function discountTotalForQty( qty ) {
        const rules = Array.isArray( DATA.quantityDiscounts ) ? DATA.quantityDiscounts : [];
        const exact = rules.find( r => parseInt( r.qty, 10 ) === qty );
        return exact ? Number( exact.total ) : null;
    }

    function activeBundleTotal() {
        const active = $( '.wcf-bundle-card.active', form );
        if ( ! active ) return null;
        const total = parseFloat( active.dataset.total || '' );
        return Number.isFinite( total ) ? total : null;
    }

    function formatMoney( value ) {
        const symbol = DATA.currency || '';
        try {
            return new Intl.NumberFormat( document.documentElement.lang || 'ar-MA', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            } ).format( value ) + ' ' + symbol;
        } catch ( e ) {
            return value.toFixed( 2 ) + ' ' + symbol;
        }
    }

    function updateTotalPrice() {
        if ( ! priceDisplay ) {
            return;
        }
        const qty   = normaliseQty();
        const bundleTotal = activeBundleTotal();
        const discounted = bundleTotal !== null ? bundleTotal : discountTotalForQty( qty );
        const total = discounted !== null ? discounted : Number( currentPrice * qty );
        $$( '.wcf-offer-pill', form ).forEach( pill => pill.classList.toggle( 'active', parseInt( pill.dataset.qty || '0', 10 ) === qty ) );
        priceDisplay.textContent = formatMoney( total );
    }

    updateTotalPrice();

    // -----------------------------------------------------------------------
    // Form submission
    // -----------------------------------------------------------------------

    form.addEventListener( 'submit', async function ( e ) {
        e.preventDefault();

        clearMessages();

        if ( ! clientValidate() ) {
            return;
        }

        setLoading( true );

        const body = new FormData( form );

        try {
            const res  = await fetch( DATA.ajaxUrl, { method: 'POST', body } );
            const json = await res.json();

            if ( json.success ) {
                handleSuccess( json.data );
            } else {
                handleError( json.data );
            }
        } catch ( err ) {
            showMessage( DATA.i18n.genericError, 'error' );
        } finally {
            setLoading( false );
        }
    } );

    // -----------------------------------------------------------------------
    // Success handler
    // -----------------------------------------------------------------------

    function handleSuccess( data ) {
        const thankyouUrl = DATA.thankyouUrl ?? '';

        if ( thankyouUrl ) {
            const url = new URL( thankyouUrl );
            url.searchParams.set( 'order_id', data.order_id );
            window.location.href = url.toString();
            return;
        }

        // Inline confirmation — hide form, show confirmation block.
        form.style.display = 'none';

        const confirm = $( '#wcf-confirmation' );
        fireTrackingEvents( data );

        if ( confirm ) {
            const idVal = confirm.querySelector( '.wcf-order-id-value' );
            if ( idVal ) {
                idVal.textContent = data.order_id;
            }
            confirm.style.display = '';
            confirm.scrollIntoView( { behavior: 'smooth', block: 'start' } );
        } else {
            showMessage( data.message || DATA.i18n.success, 'success' );
        }
    }


    function fireTrackingEvents( data ) {
        const tracking = DATA.tracking || {};
        if ( ! tracking.purchaseEvent ) return;
        const payload = {
            order_id: data.order_id,
            product_id: DATA.productId,
            currency: DATA.currencyCode || '',
            event_source: 'woo_cod_form'
        };
        if ( window.fbq && tracking.facebookPixelId ) {
            window.fbq( 'track', 'Lead', payload );
            window.fbq( 'trackCustom', 'COD_Submitted', payload );
        }
        if ( window.ttq && tracking.tiktokPixelId ) {
            window.ttq.track( 'SubmitForm', payload );
        }
        window.dataLayer = window.dataLayer || [];
        if ( tracking.gtmId || window.dataLayer ) {
            window.dataLayer.push( Object.assign( { event: 'COD_Submitted' }, payload ) );
        }
    }

    // -----------------------------------------------------------------------
    // Error handler
    // -----------------------------------------------------------------------

    function handleError( data ) {
        // Field-specific errors.
        if ( data.errors && typeof data.errors === 'object' ) {
            Object.entries( data.errors ).forEach( ( [ field, msg ] ) => {
                const input = $( `[name="${ field }"]`, form )
                           || $( `[name="wcf_${ field }"]`, form );
                if ( input ) {
                    markFieldError( input, msg );
                }
            } );
        }

        showMessage( data.message || DATA.i18n.genericError, 'error' );
        msgBox?.scrollIntoView( { behavior: 'smooth', block: 'nearest' } );
    }

    // -----------------------------------------------------------------------
    // Client-side validation (UX layer — server always re-validates)
    // -----------------------------------------------------------------------

    function clientValidate() {
        let valid = true;

        $$( '[required]', form ).forEach( input => {
            if ( ! input.value.trim() ) {
                const label = form.querySelector( `label[for="${ input.id }"]` );
                const name  = label ? label.textContent.trim().replace( /\s*\*/, '' ) : input.name;
                markFieldError( input, name + ' مطلوب.' );
                valid = false;
            }
        } );

        // Phone basic check.
        const phone = $( '[name="wcf_phone"]', form );
        if ( phone && phone.value.trim() ) {
            const digits = phone.value.replace( /\D/g, '' );
            if ( digits.length < 7 || digits.length > 15 ) {
                markFieldError( phone, 'المرجو إدخال رقم هاتف صحيح.' );
                valid = false;
            }
        }

        return valid;
    }

    // -----------------------------------------------------------------------
    // UI helpers
    // -----------------------------------------------------------------------

    function markFieldError( input, message ) {
        input.classList.add( 'wcf-input-error' );
        const errorSpan = input.parentElement?.querySelector( '.wcf-field-error' );
        if ( errorSpan ) {
            errorSpan.textContent = message;
        }

        input.addEventListener( 'input', function clearErr() {
            input.classList.remove( 'wcf-input-error' );
            if ( errorSpan ) errorSpan.textContent = '';
            input.removeEventListener( 'input', clearErr );
        }, { once: true } );
    }

    function showMessage( text, type ) {
        if ( ! msgBox ) return;
        msgBox.textContent = text;
        msgBox.className   = 'wcf-form-messages wcf-msg-' + type;
        msgBox.style.display = '';
    }

    function clearMessages() {
        if ( msgBox ) {
            msgBox.textContent   = '';
            msgBox.style.display = 'none';
        }
        $$( '.wcf-input-error', form ).forEach( el => el.classList.remove( 'wcf-input-error' ) );
        $$( '.wcf-field-error', form ).forEach( el => ( el.textContent = '' ) );
    }

    function setLoading( loading ) {
        if ( ! submitBtn ) return;
        submitBtn.disabled = loading;
        const btnText    = submitBtn.querySelector( '.wcf-btn-text' );
        const btnLoading = submitBtn.querySelector( '.wcf-btn-loading' );
        if ( btnText )    btnText.style.display    = loading ? 'none' : '';
        if ( btnLoading ) btnLoading.style.display = loading ? '' : 'none';
    }

    // -----------------------------------------------------------------------
    // Countdown timer
    // -----------------------------------------------------------------------

    const timerWrap = $( '.wcf-countdown-wrap' );

    if ( timerWrap ) {
        const minutes    = parseInt( timerWrap.dataset.minutes || 15, 10 );
        const minsEl     = $( '.wcf-timer-mins', timerWrap );
        const secsEl     = $( '.wcf-timer-secs', timerWrap );
        let   remaining  = minutes * 60;

        const tick = () => {
            if ( remaining <= 0 ) {
                if ( minsEl ) minsEl.textContent = '00';
                if ( secsEl ) secsEl.textContent = '00';
                timerWrap.classList.add( 'wcf-timer-expired' );
                return;
            }

            remaining--;

            const m = String( Math.floor( remaining / 60 ) ).padStart( 2, '0' );
            const s = String( remaining % 60 ).padStart( 2, '0' );

            if ( minsEl ) minsEl.textContent = m;
            if ( secsEl ) secsEl.textContent = s;

            setTimeout( tick, 1000 );
        };

        setTimeout( tick, 1000 );
    }

    // -----------------------------------------------------------------------
    // Social proof cycling
    // -----------------------------------------------------------------------

    const socialWrap = $( '.wcf-social-proof' );

    if ( socialWrap ) {
        const template = socialWrap.dataset.template || '{name} from {city} just ordered!';
        const textEl   = $( '.wcf-social-text', socialWrap );

        let names = [];
        try {
            names = JSON.parse( socialWrap.dataset.names || '[]' );
        } catch ( _ ) {}

        if ( names.length && textEl ) {
            let idx = 0;

            const showNext = () => {
                const entry   = names[ idx % names.length ];
                const message = template
                    .replace( '{name}', entry.name || '' )
                    .replace( '{city}', entry.city || '' );

                socialWrap.classList.remove( 'wcf-social-visible' );

                setTimeout( () => {
                    textEl.textContent = message;
                    socialWrap.classList.add( 'wcf-social-visible' );
                }, 300 );

                idx++;
            };

            // Initial display after 3 seconds.
            setTimeout( () => {
                showNext();
                setInterval( showNext, 7000 );
            }, 3000 );
        }
    }

    updateTotalPrice();

} )();
