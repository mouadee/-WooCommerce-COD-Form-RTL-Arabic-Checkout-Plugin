<?php
/**
 * File: modules/woocommerce/class-product-handler.php
 *
 * Retrieves and normalises WooCommerce product / variation data
 * into a flat array safe to expose via JSON AJAX responses.
 *
 * All WC API calls are confined to this class — nothing else in the
 * plugin should call wc_get_product() or traverse product objects.
 */

namespace WCF\Modules\Woocommerce;

defined( 'ABSPATH' ) || exit;

final class Product_Handler {

    /**
     * Return product data (and optionally variation data) as a flat array.
     *
     * @param  int   $product_id    Parent product ID.
     * @param  int   $variation_id  0 = return parent data; >0 = return variation data.
     * @return array                Data array, or ['error' => string] on failure.
     */
    public static function get_data( int $product_id, int $variation_id = 0 ): array {
        $product = wc_get_product( $product_id );

        if ( ! $product instanceof \WC_Product ) {
            return [ 'error' => __( 'Product not found.', 'woo-cod-form' ) ];
        }

        // Specific variation requested.
        if ( $variation_id > 0 && $product->is_type( 'variable' ) ) {
            return self::variation_data( $variation_id, $product_id );
        }

        return self::product_data( $product );
    }

    // -----------------------------------------------------------------------
    // Internal formatters
    // -----------------------------------------------------------------------

    /**
     * Build a flat data array for a simple / non-variable product.
     */
    private static function product_data( \WC_Product $product ): array {
        return [
            'id'             => $product->get_id(),
            'name'           => $product->get_name(),
            'type'           => $product->get_type(),
            'is_variable'    => $product->is_type( 'variable' ),
            'price'          => (float) $product->get_price(),
            'regular_price'  => (float) $product->get_regular_price(),
            'sale_price'     => (float) $product->get_sale_price(),
            'price_html'     => self::format_price_html( $product ),
            'in_stock'       => $product->is_in_stock(),
            'stock_qty'      => $product->get_stock_quantity(),
            'manage_stock'   => $product->managing_stock(),
            'max_purchase'   => self::effective_max_purchase( $product ),
            'min_purchase'   => $product->get_min_purchase_quantity(),
            'variations'     => $product->is_type( 'variable' )
                                    ? self::all_variations( $product )
                                    : [],
        ];
    }

    /**
     * Build a flat data array for a specific variation.
     *
     * @return array  Variation data, or ['error' => string] on failure.
     */
    private static function variation_data( int $variation_id, int $parent_id ): array {
        $variation = wc_get_product( $variation_id );

        if ( ! $variation instanceof \WC_Product_Variation ) {
            return [ 'error' => __( 'Variation not found.', 'woo-cod-form' ) ];
        }

        // Protect against variation/product ID spoofing.
        if ( $variation->get_parent_id() !== $parent_id ) {
            return [ 'error' => __( 'Invalid product option.', 'woo-cod-form' ) ];
        }

        return [
            'id'             => $variation->get_id(),
            'parent_id'      => $parent_id,
            'name'           => $variation->get_name(),
            'price'          => (float) $variation->get_price(),
            'regular_price'  => (float) $variation->get_regular_price(),
            'sale_price'     => (float) $variation->get_sale_price(),
            'price_html'     => self::format_price_html( $variation ),
            'in_stock'       => $variation->is_in_stock(),
            'stock_qty'      => $variation->get_stock_quantity(),
            'manage_stock'   => $variation->managing_stock(),
            'max_purchase'   => self::effective_max_purchase( $variation ),
            'attributes'     => $variation->get_variation_attributes(),
        ];
    }

    private static function effective_max_purchase( \WC_Product $product ): int {
        $setting_max = max( 1, (int) get_option( 'wcf_max_quantity', 5 ) );
        $wc_max      = (int) $product->get_max_purchase_quantity();
        if ( $wc_max <= 0 || $wc_max > 9999 ) {
            return $setting_max;
        }
        return max( 1, min( $setting_max, $wc_max ) );
    }


    /**
     * Format product prices with the plugin-selected currency.
     * Note: this changes display currency symbol/code only; it does not convert values.
     */
    private static function selected_currency(): string {
        $currency = (string) get_option( 'wcf_currency_code', '' );
        return '' !== $currency ? $currency : get_woocommerce_currency();
    }

    private static function format_raw_price( float $price ): string {
        return wc_price( $price, [ 'currency' => self::selected_currency() ] );
    }

    private static function format_price_html( \WC_Product $product ): string {
        if ( $product->is_on_sale() && '' !== (string) $product->get_regular_price() ) {
            return wc_format_sale_price(
                wc_price( (float) $product->get_regular_price(), [ 'currency' => self::selected_currency() ] ),
                wc_price( (float) $product->get_price(), [ 'currency' => self::selected_currency() ] )
            );
        }

        return wc_price( (float) $product->get_price(), [ 'currency' => self::selected_currency() ] );
    }

    /**
     * Return a compact array of all available variations for a variable product.
     * Used by the frontend to build the variant selector without a second request.
     *
     * @param  \WC_Product $product  Must be a variable product.
     * @return array[]
     */
    private static function all_variations( \WC_Product $product ): array {
        $result = [];

        foreach ( $product->get_available_variations( 'array' ) as $v ) {
            $result[] = [
                'variation_id' => (int) $v['variation_id'],
                'attributes'   => $v['attributes'],
                'price'        => (float) $v['display_price'],
                'price_html'   => self::format_raw_price( (float) $v['display_price'] ),
                'in_stock'     => (bool) $v['is_in_stock'],
                'stock_qty'    => isset( $v['max_qty'] ) ? (int) $v['max_qty'] : null,
            ];
        }

        return $result;
    }
}
