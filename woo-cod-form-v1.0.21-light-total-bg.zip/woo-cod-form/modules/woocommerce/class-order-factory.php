<?php
/**
 * File: modules/woocommerce/class-order-factory.php
 *
 * Constructs a WooCommerce order exclusively through the WC OOP API.
 * No direct database access. No payment processing (COD = pay on delivery).
 *
 * Expected $data shape (output of Field_Mapper::map()):
 * [
 *   'product_id'   => int,
 *   'variation_id' => int,   // 0 when not applicable
 *   'quantity'     => int,
 *   'first_name'   => string,
 *   'last_name'    => string,
 *   'phone'        => string,
 *   'address_1'    => string,
 *   'address_2'    => string,
 *   'city'         => string,
 *   'state'        => string,
 *   'postcode'     => string,
 *   'country'      => string,
 *   'email'        => string,
 *   'notes'        => string,
 * ]
 */

namespace WCF\Modules\Woocommerce;

defined( 'ABSPATH' ) || exit;

final class Order_Factory {

    /**
     * Create and persist a new WooCommerce COD order.
     *
     * @param  array         $data  Validated and mapped form data.
     * @return int|\WP_Error        Order ID on success, WP_Error on failure.
     */
    public static function create( array $data ): int|\WP_Error {
        $product_id   = (int) $data['product_id'];
        $variation_id = (int) ( $data['variation_id'] ?? 0 );
        $quantity     = max( 1, (int) ( $data['quantity'] ?? 1 ) );
        $bundle      = self::selected_bundle( (string) ( $data['selected_bundle'] ?? '' ) );
        if ( null !== $bundle ) {
            $quantity = max( 1, (int) $bundle['quantity'] );
        }
        $max_quantity = max( 1, (int) get_option( 'wcf_max_quantity', 5 ) );

        if ( $quantity > $max_quantity ) {
            return new \WP_Error(
                'wcf_quantity_too_high',
                sprintf( __( 'Quantity must be no more than %d.', 'woo-cod-form' ), $max_quantity )
            );
        }

        // ---------------------------------------------------------------
        // 1. Resolve and verify the purchasable product / variation.
        // ---------------------------------------------------------------

        $purchasable = self::resolve_purchasable( $product_id, $variation_id );

        if ( is_wp_error( $purchasable ) ) {
            return $purchasable;
        }

        /** @var \WC_Product $purchasable */

        // ---------------------------------------------------------------
        // 2. Stock check.
        // ---------------------------------------------------------------

        if ( ! $purchasable->is_in_stock() ) {
            return new \WP_Error(
                'wcf_out_of_stock',
                __( 'Sorry, this product is currently out of stock.', 'woo-cod-form' )
            );
        }

        if ( $purchasable->managing_stock() ) {
            $available = $purchasable->get_stock_quantity();
            if ( $available !== null && $quantity > $available ) {
                return new \WP_Error(
                    'wcf_insufficient_stock',
                    sprintf(
                        /* translators: %d: available quantity */
                        __( 'Only %d unit(s) available.', 'woo-cod-form' ),
                        $available
                    )
                );
            }
        }

        // ---------------------------------------------------------------
        // 3. Create a blank WC order.
        // ---------------------------------------------------------------

        $order = wc_create_order();

        if ( $order instanceof \WC_Order ) {
            $currency = (string) get_option( 'wcf_currency_code', '' );
            if ( '' !== $currency && method_exists( $order, 'set_currency' ) ) {
                $order->set_currency( $currency );
            }
        }

        if ( $order instanceof \WC_Order && method_exists( $order, 'set_created_via' ) ) {
            $order->set_created_via( 'woo-cod-form' );
        }

        if ( is_wp_error( $order ) ) {
            return new \WP_Error(
                'wcf_order_create_failed',
                __( 'Could not create order. Please try again.', 'woo-cod-form' )
            );
        }

        // ---------------------------------------------------------------
        // 4. Add line item (variation-aware).
        // ---------------------------------------------------------------

        $add_item_args = [];

        if ( $variation_id > 0 && $purchasable->is_type( 'variation' ) ) {
            $add_item_args['variation'] = $purchasable->get_variation_attributes();
        }

        $line_item_id = $order->add_product( $purchasable, $quantity, $add_item_args );

        $discount_total = null !== $bundle ? max( 0, (float) $bundle['price'] ) : self::quantity_discount_total( $quantity );
        if ( null !== $discount_total && $line_item_id ) {
            $item = $order->get_item( $line_item_id );
            if ( $item instanceof \WC_Order_Item_Product ) {
                $item->set_subtotal( $discount_total );
                $item->set_total( $discount_total );
                if ( null !== $bundle ) {
                    $item->add_meta_data( '_wcf_bundle_offer', 'yes', true );
                    $item->add_meta_data( 'الباقة المختارة', $bundle['title'], true );
                    $item->add_meta_data( 'كمية الباقة', (string) $bundle['quantity'], true );
                    $item->add_meta_data( 'سعر الباقة', (string) $bundle['price'], true );
                    if ( ! empty( $bundle['badge'] ) ) {
                        $item->add_meta_data( 'شارة الباقة', $bundle['badge'], true );
                    }
                } else {
                    $item->add_meta_data( '_wcf_quantity_offer', 'yes', true );
                }
                $item->save();
            }
        }

        // ---------------------------------------------------------------
        // 5. Set billing address.
        // ---------------------------------------------------------------

        $country  = ! empty( $data['country'] )
            ? $data['country']
            : substr( (string) get_option( 'woocommerce_default_country', 'MA' ), 0, 2 );

        $order->set_billing_first_name( $data['first_name'] );
        $order->set_billing_last_name( $data['last_name'] ?? '' );
        $order->set_billing_phone( $data['phone'] );
        $order->set_billing_address_1( $data['address_1'] );
        $order->set_billing_address_2( $data['address_2'] ?? '' );
        $order->set_billing_city( $data['city'] );
        $order->set_billing_state( $data['state'] ?? '' );
        $order->set_billing_postcode( $data['postcode'] ?? '' );
        $order->set_billing_country( $country );

        if ( ! empty( $data['email'] ) && is_email( $data['email'] ) ) {
            $order->set_billing_email( $data['email'] );
        }

        // ---------------------------------------------------------------
        // 6. Payment method — Cash on Delivery.
        // ---------------------------------------------------------------

        $order->set_payment_method( 'cod' );
        $order->set_payment_method_title( __( 'Cash on Delivery', 'woo-cod-form' ) );

        // ---------------------------------------------------------------
        // 7. Optional customer note.
        // ---------------------------------------------------------------

        if ( ! empty( $data['notes'] ) ) {
            $order->set_customer_note( $data['notes'] );
        }

        if ( ! empty( $data['extra_fields'] ) && is_array( $data['extra_fields'] ) ) {
            foreach ( $data['extra_fields'] as $key => $value ) {
                if ( '' !== (string) $value ) {
                    $order->update_meta_data( '_wcf_' . sanitize_key( $key ), sanitize_text_field( (string) $value ) );
                }
            }
        }

        // ---------------------------------------------------------------
        // 8. Status — configured by store owner in plugin settings.
        // ---------------------------------------------------------------

        $raw_status = (string) get_option( 'wcf_order_status', 'wc-pending' );
        // WC set_status() expects the slug without the 'wc-' prefix.
        $status = preg_replace( '/^wc-/', '', $raw_status );
        $order->set_status( $status, __( 'Order submitted via COD Form.', 'woo-cod-form' ), true );

        // ---------------------------------------------------------------
        // 9. Calculate totals and persist.
        // ---------------------------------------------------------------

        $order->calculate_totals();

        // Plugin-specific meta for filtering / attribution.
        $order->update_meta_data( '_wcf_source', 'cod_form' );
        $order->update_meta_data( '_wcf_version', WCF_VERSION );
        $order->update_meta_data( '_wcf_ip', self::client_ip() );
        if ( null !== $bundle ) {
            $order->update_meta_data( '_wcf_selected_bundle', sanitize_key( (string) $bundle['id'] ) );
            $order->update_meta_data( '_wcf_bundle_title', sanitize_text_field( (string) $bundle['title'] ) );
            $order->update_meta_data( '_wcf_bundle_quantity', max( 1, (int) $bundle['quantity'] ) );
            $order->update_meta_data( '_wcf_bundle_price', max( 0, (float) $bundle['price'] ) );
            $order->update_meta_data( '_wcf_bundle_badge', sanitize_text_field( (string) $bundle['badge'] ) );
        }

        $order_id = $order->save();

        if ( ! $order_id ) {
            return new \WP_Error(
                'wcf_order_save_failed',
                __( 'Order could not be saved. Please try again.', 'woo-cod-form' )
            );
        }

        // ---------------------------------------------------------------
        // 10. Post-creation actions.
        // ---------------------------------------------------------------

        // Reduce stock levels via WC's official mechanism.
        wc_reduce_stock_levels( $order_id );

        // Fire WC's standard hook that triggers new-order admin emails
        // and any third-party integrations (CRMs, shipping plugins, etc.).
        do_action( 'woocommerce_checkout_order_created', $order );

        return $order_id;
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Return the correct \WC_Product object for the given product/variation IDs.
     *
     * @return \WC_Product|\WP_Error
     */
    private static function resolve_purchasable( int $product_id, int $variation_id ): \WC_Product|\WP_Error {
        $parent = wc_get_product( $product_id );

        if ( ! $parent instanceof \WC_Product ) {
            return new \WP_Error(
                'wcf_invalid_product',
                __( 'The selected product does not exist.', 'woo-cod-form' )
            );
        }

        // Variable product — we need a specific variation to create an order.
        if ( $parent->is_type( 'variable' ) ) {
            if ( $variation_id <= 0 ) {
                return new \WP_Error(
                    'wcf_missing_variation',
                    __( 'Please select a product option.', 'woo-cod-form' )
                );
            }

            $variation = wc_get_product( $variation_id );

            if ( ! $variation instanceof \WC_Product_Variation ) {
                return new \WP_Error(
                    'wcf_invalid_variation',
                    __( 'The selected product option is invalid.', 'woo-cod-form' )
                );
            }

            // Security: ensure variation belongs to the submitted parent.
            if ( $variation->get_parent_id() !== $product_id ) {
                return new \WP_Error(
                    'wcf_variation_mismatch',
                    __( 'The selected product option is invalid.', 'woo-cod-form' )
                );
            }

            return $variation;
        }

        // Simple / grouped / external product.
        if ( ! $parent->is_purchasable() ) {
            return new \WP_Error(
                'wcf_not_purchasable',
                __( 'This product cannot be purchased.', 'woo-cod-form' )
            );
        }

        return $parent;
    }

    /**
     * Resolve the selected bundle and trust only saved admin configuration.
     */
    private static function selected_bundle( string $bundle_id ): ?array {
        if ( ! (bool) get_option( 'wcf_bundles_enabled', false ) || ! class_exists( '\\WCF\\Modules\\Admin\\Settings_Manager' ) ) {
            return null;
        }
        $bundle_id = sanitize_key( $bundle_id );
        if ( '' === $bundle_id ) {
            $bundle_id = sanitize_key( (string) get_option( 'wcf_default_bundle', 'bundle_1' ) );
        }
        $bundle = \WCF\Modules\Admin\Settings_Manager::get_bundle_offer( $bundle_id );
        return is_array( $bundle ) ? $bundle : null;
    }

    /**
     * Return a configured quantity-offer total for exact quantity matches.
     */
    private static function quantity_discount_total( int $quantity ): ?float {
        if ( ! (bool) get_option( 'wcf_quantity_discounts_enabled', false ) || ! class_exists( '\\WCF\\Modules\\Admin\\Settings_Manager' ) ) {
            return null;
        }
        foreach ( \WCF\Modules\Admin\Settings_Manager::parse_quantity_rules() as $rule ) {
            if ( (int) $rule['qty'] === $quantity ) {
                return max( 0, (float) $rule['total'] );
            }
        }
        return null;
    }

    /**
     * Return the real client IP, respecting common proxy headers.
     * Stored as order meta for fraud-review purposes only.
     */
    private static function client_ip(): string {
        // Cloudflare.
        if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
            return sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
        }

        // Standard reverse-proxy header (first IP in the chain).
        if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ips = explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
            return sanitize_text_field( trim( $ips[0] ) );
        }

        return sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) );
    }
}
