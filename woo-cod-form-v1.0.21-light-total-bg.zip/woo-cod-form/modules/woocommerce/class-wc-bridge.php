<?php
/**
 * File: modules/woocommerce/class-wc-bridge.php
 *
 * WooCommerce integration entry point.
 *
 * Responsibilities:
 *   - Declare HPOS (Custom Order Tables) compatibility.
 *   - Provide a clean public API surface for the rest of the plugin
 *     to create orders and retrieve product data without knowing
 *     the internal WC implementation details.
 */

namespace WCF\Modules\Woocommerce;

defined( 'ABSPATH' ) || exit;

final class WC_Bridge {

    /**
     * Hook into WordPress / WooCommerce lifecycle.
     * Called once from Plugin::boot().
     */
    public static function init(): void {
        add_action( 'before_woocommerce_init', [ self::class, 'declare_hpos_compat' ] );
    }

    // -----------------------------------------------------------------------
    // WooCommerce compatibility declarations
    // -----------------------------------------------------------------------

    /**
     * Declare compatibility with WooCommerce High-Performance Order Storage.
     * Required for WooCommerce 7.1+ to suppress the incompatibility notice.
     */
    public static function declare_hpos_compat(): void {
        if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
                'custom_order_tables',
                WCF_FILE,
                true
            );
        }
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Create a WooCommerce COD order from mapped form data.
     *
     * @param  array         $data  Output of Field_Mapper::map().
     * @return int|\WP_Error        New order ID, or WP_Error on failure.
     */
    public static function create_order( array $data ): int|\WP_Error {
        return Order_Factory::create( $data );
    }

    /**
     * Return structured product data for a given product / variation.
     *
     * @param  int  $product_id    Parent product ID.
     * @param  int  $variation_id  Optional variation ID (0 = none).
     * @return array               Product data array.
     */
    public static function get_product_data( int $product_id, int $variation_id = 0 ): array {
        return Product_Handler::get_data( $product_id, $variation_id );
    }
}
