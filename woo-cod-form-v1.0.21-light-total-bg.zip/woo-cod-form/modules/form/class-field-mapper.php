<?php
/**
 * File: modules/form/class-field-mapper.php
 *
 * Transforms the sanitized + validated COD form array into the exact
 * data shape that Order_Factory::create() expects.
 *
 * Decouples the form field naming convention (wcf_* prefixed keys)
 * from the WooCommerce billing field names so either side can change
 * independently without touching the other.
 */

namespace WCF\Modules\Form;

defined( 'ABSPATH' ) || exit;

final class Field_Mapper {

    /**
     * Map sanitized form data to the WC order shape.
     *
     * @param  array $clean  Output of Form_Sanitizer::sanitize().
     * @return array         Data array ready for Order_Factory::create().
     */
    public static function map( array $clean ): array {
        $extra = [];
        foreach ( $clean as $key => $value ) {
            if ( is_string( $key ) && str_starts_with( $key, 'wcf_extra_' ) ) {
                $extra[ substr( $key, 4 ) ] = $value;
            }
        }

        return [
            // Product identifiers.
            'product_id'   => (int) $clean['product_id'],
            'variation_id' => (int) ( $clean['variation_id'] ?? 0 ),
            'quantity'     => max( 1, (int) ( $clean['quantity'] ?? 1 ) ),
            'selected_bundle' => sanitize_key( (string) ( $clean['selected_bundle'] ?? '' ) ),

            // WooCommerce billing fields (strip wcf_ prefix).
            'first_name' => $clean['wcf_first_name'] ?? '',
            'last_name'  => $clean['wcf_last_name']  ?? '',
            'phone'      => $clean['wcf_phone']      ?? '',
            'address_1'  => $clean['wcf_address_1']  ?? '',
            'address_2'  => $clean['wcf_address_2']  ?? '',
            'city'       => $clean['wcf_city']       ?? '',
            'state'      => $clean['wcf_state']      ?? '',
            'postcode'   => $clean['wcf_postcode']   ?? '',
            'country'    => $clean['wcf_country']    ?? '',
            'email'      => $clean['wcf_email']      ?? '',
            'notes'      => $clean['wcf_notes']      ?? '',
            'extra_fields'=> $extra,
        ];
    }
}
