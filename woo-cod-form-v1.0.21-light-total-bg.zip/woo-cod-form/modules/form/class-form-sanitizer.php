<?php
/**
 * File: modules/form/class-form-sanitizer.php
 *
 * Sanitizes raw $_POST data before validation or storage.
 *
 * Rules:
 *   - Every field is processed through an appropriate WP sanitizer.
 *   - wp_unslash() is applied before sanitization (WordPress magic quotes).
 *   - Unknown / extra POST keys are silently ignored (whitelist approach).
 *   - No validation occurs here — that is Form_Validator's responsibility.
 */

namespace WCF\Modules\Form;

defined( 'ABSPATH' ) || exit;

final class Form_Sanitizer {

    /**
     * Sanitize a raw POST payload and return a clean, typed array.
     *
     * @param  array $raw  Raw $_POST or equivalent.
     * @return array       Sanitized data keyed by field name.
     */
    public static function sanitize( array $raw ): array {
        $data = [
            // System / product fields.
            'product_id'   => absint( $raw['product_id']   ?? 0 ),
            'variation_id' => absint( $raw['variation_id'] ?? 0 ),
            'quantity'     => absint( $raw['quantity']      ?? 1 ),
            'selected_bundle' => sanitize_key( wp_unslash( $raw['selected_bundle'] ?? '' ) ),

            // Billing fields — all use wcf_ prefix to avoid collision.
            'wcf_first_name' => sanitize_text_field( wp_unslash( $raw['wcf_first_name'] ?? '' ) ),
            'wcf_last_name'  => sanitize_text_field( wp_unslash( $raw['wcf_last_name']  ?? '' ) ),
            'wcf_phone'      => self::phone( wp_unslash( $raw['wcf_phone'] ?? '' ) ),
            'wcf_address_1'  => sanitize_text_field( wp_unslash( $raw['wcf_address_1']  ?? '' ) ),
            'wcf_address_2'  => sanitize_text_field( wp_unslash( $raw['wcf_address_2']  ?? '' ) ),
            'wcf_city'       => sanitize_text_field( wp_unslash( $raw['wcf_city']        ?? '' ) ),
            'wcf_state'      => sanitize_text_field( wp_unslash( $raw['wcf_state']       ?? '' ) ),
            'wcf_postcode'   => sanitize_text_field( wp_unslash( $raw['wcf_postcode']    ?? '' ) ),
            'wcf_country'    => self::country_code( wp_unslash( $raw['wcf_country'] ?? '' ) ),
            'wcf_email'      => sanitize_email( wp_unslash( $raw['wcf_email'] ?? '' ) ),
            'wcf_notes'      => sanitize_textarea_field( wp_unslash( $raw['wcf_notes'] ?? '' ) ),
        ];

        foreach ( $raw as $key => $value ) {
            if ( is_string( $key ) && str_starts_with( $key, 'wcf_extra_' ) ) {
                $data[ sanitize_key( $key ) ] = sanitize_text_field( wp_unslash( $value ) );
            }
        }

        return $data;
    }

    // -----------------------------------------------------------------------
    // Custom sanitizers
    // -----------------------------------------------------------------------

    /**
     * Strip everything from a phone string except digits, +, spaces, - and ().
     * Does NOT validate format — that is Form_Validator's job.
     */
    private static function phone( string $raw ): string {
        return (string) preg_replace( '/[^\d\+\s\-\(\)]/', '', $raw );
    }

    /**
     * Ensure a country code is exactly two uppercase alpha characters.
     * Falls back to empty string if the input doesn't look like an ISO code.
     */
    private static function country_code( string $raw ): string {
        $upper = strtoupper( sanitize_text_field( $raw ) );
        return preg_match( '/^[A-Z]{2}$/', $upper ) ? $upper : '';
    }
}
