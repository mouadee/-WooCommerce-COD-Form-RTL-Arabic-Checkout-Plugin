<?php
/**
 * File: modules/form/class-form-renderer.php
 *
 * Handles all frontend form output:
 *   - Shortcode [wcf_order_form product_id="123"]
 *   - Auto-inject on single product pages (when enabled in settings)
 *   - Conditional asset enqueueing
 *   - Nonce injection
 *   - Honeypot field injection
 *   - Localized JS data (ajaxurl, nonce, product data, settings)
 *
 * FIX: Added auto-inject hook for woocommerce_single_product_summary
 *      so the form appears on product pages without a manual shortcode.
 */

namespace WCF\Modules\Form;

use WCF\Modules\Security\Honeypot;
use WCF\Modules\Security\Nonce_Manager;
use WCF\Modules\Woocommerce\WC_Bridge;

defined( 'ABSPATH' ) || exit;

final class Form_Renderer {

    /** Tracks whether assets have already been enqueued for this request. */
    private static bool $assets_enqueued = false;

    // -----------------------------------------------------------------------
    // Boot
    // -----------------------------------------------------------------------

    /**
     * Register shortcode and any frontend hooks.
     * Called once from Plugin::boot().
     */
    public static function init(): void {
        add_shortcode( 'wcf_order_form', [ self::class, 'render_shortcode' ] );

        // Optional cleanup for single product pages: hide WooCommerce native title, price,
        // and add-to-cart block so the COD form can be the only conversion UI.
        add_action( 'wp', [ self::class, 'maybe_hide_native_product_elements' ], 1 );
        add_action( 'template_redirect', [ self::class, 'maybe_hide_native_product_elements' ], 1 );
        add_action( 'woocommerce_before_single_product', [ self::class, 'maybe_hide_native_product_elements' ], 1 );
        add_filter( 'body_class', [ self::class, 'native_hide_body_classes' ] );
        add_action( 'wp_head', [ self::class, 'print_native_hide_css' ], 1 );
        add_action( 'wp_footer', [ self::class, 'print_native_hide_js' ], 99 );

        // ---------------------------------------------------------------
        // BUG FIX: Auto-inject on single product pages.
        // The form was shortcode-only — it would never appear on product
        // pages unless the store owner manually inserted the shortcode into
        // every product description. The option wcf_enable_on_product_page
        // (added in Settings_Manager) controls this behaviour.
        // Priority 35 renders after the default price (10) and excerpt (20)
        // but before the add-to-cart button (30) — customize as needed.
        // ---------------------------------------------------------------
        if ( get_option( 'wcf_enable_on_product_page', false ) ) {
            add_action(
                'woocommerce_single_product_summary',
                [ self::class, 'render_on_product_page' ],
                35
            );
        }
    }

    // -----------------------------------------------------------------------
    // Native WooCommerce element controls
    // -----------------------------------------------------------------------

    /**
     * Remove native WooCommerce product summary elements when enabled in Design settings.
     * This runs on wp before the single product template renders.
     */
    public static function maybe_hide_native_product_elements(): void {
        if ( ! self::is_product_context() ) {
            return;
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_title' ) ) {
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_price' ) ) {
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_add_to_cart' ) ) {
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 25 );
            remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 35 );
        }
    }

    /**
     * Add body classes so CSS works even with themes that print custom product markup.
     */
    public static function native_hide_body_classes( array $classes ): array {
        if ( ! self::is_product_context() ) {
            return $classes;
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_title' ) ) {
            $classes[] = 'wcf-hide-native-title';
        }
        if ( self::hide_option_enabled( 'wcf_hide_native_price' ) ) {
            $classes[] = 'wcf-hide-native-price';
        }
        if ( self::hide_option_enabled( 'wcf_hide_native_add_to_cart' ) ) {
            $classes[] = 'wcf-hide-native-cart';
        }

        return $classes;
    }

    /**
     * CSS fallback for themes/builders that print their own title, price, or add-to-cart markup.
     */
    public static function print_native_hide_css(): void {
        if ( ! self::is_product_context() ) {
            return;
        }

        $rules = [];

        if ( self::hide_option_enabled( 'wcf_hide_native_title' ) ) {
            $rules[] = 'body.single-product.wcf-hide-native-title .summary > .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title .entry-summary > .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title .summary > h1';
            $rules[] = 'body.single-product.wcf-hide-native-title .entry-summary > h1';
            $rules[] = 'body.single-product.wcf-hide-native-title .product .summary .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title .product .entry-summary .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title h1.product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title div.product h1.product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title div.product .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title div.product .wp-block-post-title';
            $rules[] = 'body.single-product.wcf-hide-native-title main .product_title';
            $rules[] = 'body.single-product.wcf-hide-native-title main h1.product_title';
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_price' ) ) {
            $rules[] = 'body.single-product.wcf-hide-native-price .summary > p.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .summary > span.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .summary > div.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .entry-summary > p.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .entry-summary > span.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .entry-summary > div.price';
            $rules[] = 'body.single-product.wcf-hide-native-price div.product .summary .price';
            $rules[] = 'body.single-product.wcf-hide-native-price div.product .entry-summary .price';
            $rules[] = 'body.single-product.wcf-hide-native-price div.product > .price';
            $rules[] = 'body.single-product.wcf-hide-native-price main p.price';
            $rules[] = 'body.single-product.wcf-hide-native-price main span.price';
            $rules[] = 'body.single-product.wcf-hide-native-price main div.price';
            $rules[] = 'body.single-product.wcf-hide-native-price .summary .woocommerce-Price-amount:not(.wcf-cod-form .woocommerce-Price-amount):not(.wcf-order-form .woocommerce-Price-amount)';
            $rules[] = 'body.single-product.wcf-hide-native-price .entry-summary .woocommerce-Price-amount:not(.wcf-cod-form .woocommerce-Price-amount):not(.wcf-order-form .woocommerce-Price-amount)';
        }

        if ( self::hide_option_enabled( 'wcf_hide_native_add_to_cart' ) ) {
            $rules[] = 'body.single-product.wcf-hide-native-cart .summary > form.cart';
            $rules[] = 'body.single-product.wcf-hide-native-cart .entry-summary > form.cart';
            $rules[] = 'body.single-product.wcf-hide-native-cart div.product form.cart:not(.wcf-cod-form):not(.wcf-order-form):not(#wcf-order-form)';
            $rules[] = 'body.single-product.wcf-hide-native-cart .single_add_to_cart_button';
            $rules[] = 'body.single-product.wcf-hide-native-cart button[name="add-to-cart"]';
            $rules[] = 'body.single-product.wcf-hide-native-cart input[name="add-to-cart"]';
            $rules[] = 'body.single-product.wcf-hide-native-cart .summary > .quantity';
            $rules[] = 'body.single-product.wcf-hide-native-cart .entry-summary > .quantity';
            $rules[] = 'body.single-product.wcf-hide-native-cart .product_meta';
        }

        if ( empty( $rules ) ) {
            return;
        }

        echo "\n<style id=\"wcf-native-hide-css\">\n";
        echo implode( ",\n", $rules ) . "{display:none!important;visibility:hidden!important;height:0!important;overflow:hidden!important;margin:0!important;padding:0!important;}\n";
        echo "</style>\n";
    }

    /**
     * Last-resort JS fallback for builders/themes that inject native elements after wp_head.
     */
    public static function print_native_hide_js(): void {
        if ( ! self::is_product_context() ) {
            return;
        }

        $title = self::hide_option_enabled( 'wcf_hide_native_title' ) ? 'true' : 'false';
        $price = self::hide_option_enabled( 'wcf_hide_native_price' ) ? 'true' : 'false';
        $cart  = self::hide_option_enabled( 'wcf_hide_native_add_to_cart' ) ? 'true' : 'false';

        if ( 'false' === $title && 'false' === $price && 'false' === $cart ) {
            return;
        }
        ?>
<script id="wcf-native-hide-js">
(function(){
  var hideTitle = <?php echo $title; ?>;
  var hidePrice = <?php echo $price; ?>;
  var hideCart = <?php echo $cart; ?>;
  function isInsideCod(el){
    return !!(el && el.closest && (el.closest('.wcf-form-wrap') || el.closest('.wcf-cod-form') || el.closest('.wcf-order-form') || el.closest('#wcf-order-form')));
  }
  function isThemeChrome(el){
    return !!(el && el.closest && (el.closest('header') || el.closest('nav') || el.closest('footer') || el.closest('.site-header') || el.closest('.site-footer') || el.closest('.woocommerce-breadcrumb')));
  }
  function hardHide(el){
    if (!el || isInsideCod(el) || isThemeChrome(el)) return;
    el.style.setProperty('display','none','important');
    el.style.setProperty('visibility','hidden','important');
    el.style.setProperty('height','0','important');
    el.style.setProperty('overflow','hidden','important');
    el.style.setProperty('margin','0','important');
    el.style.setProperty('padding','0','important');
    el.setAttribute('data-wcf-hidden-native','1');
  }
  function getProductRoot(){
    return document.querySelector('div.product') || document.querySelector('.single-product .site-main') || document.querySelector('main') || document.body;
  }
  function hideNativeProductElements(){
    var body = document.body;
    if (!body || !body.classList.contains('single-product')) return;
    var root = getProductRoot();
    if (!root) return;

    // Broad theme-safe pass. Excludes the COD form and header/footer/navigation.
    if (hideTitle) {
      root.querySelectorAll('h1.product_title, .product_title, h1.entry-title, .entry-title.product_title, .wp-block-post-title, .woocommerce-product-title').forEach(hardHide);
      root.querySelectorAll('h1').forEach(function(el){
        if (isInsideCod(el) || isThemeChrome(el)) return;
        if (el.closest('.summary') || el.closest('.entry-summary') || el.closest('div.product') || el.closest('main')) hardHide(el);
      });
    }
    if (hidePrice) {
      root.querySelectorAll('p.price, span.price, div.price, .price, .woocommerce-Price-amount, .wc-block-components-product-price, .wp-block-woocommerce-product-price').forEach(hardHide);
      // Some themes print the price as plain text in a simple paragraph near the product title.
      root.querySelectorAll('.summary p, .entry-summary p, div.product > p').forEach(function(el){
        if (isInsideCod(el) || isThemeChrome(el)) return;
        var txt = (el.textContent || '').trim();
        if (/^(\$|€|£|د\.م|DH|MAD|USD|EUR)\s*\d|\d+[\.,]?\d*\s*(د\.م|DH|MAD|USD|EUR|\$|€|£)$/i.test(txt)) hardHide(el);
      });
    }
    if (hideCart) {
      root.querySelectorAll('form.cart, .cart:not(.wcf-cod-form):not(.wcf-order-form), .single_add_to_cart_button, button[name="add-to-cart"], input[name="add-to-cart"], .summary > .quantity, .entry-summary > .quantity, .product_meta').forEach(hardHide);
    }
  }
  hideNativeProductElements();
  document.addEventListener('DOMContentLoaded', hideNativeProductElements);
  window.addEventListener('load', hideNativeProductElements);
  [50,250,750,1500,3000].forEach(function(t){ setTimeout(hideNativeProductElements, t); });
  if ('MutationObserver' in window) {
    var mo = new MutationObserver(hideNativeProductElements);
    document.addEventListener('DOMContentLoaded', function(){ mo.observe(document.body, {childList:true, subtree:true}); });
  }
})();
</script>
        <?php
    }

    private static function hide_option_enabled( string $option ): bool {
        $value = get_option( $option, false );
        return true === $value || '1' === $value || 1 === $value || 'yes' === $value || 'on' === $value;
    }

    private static function is_product_context(): bool {
        if ( function_exists( 'is_product' ) && is_product() ) {
            return true;
        }

        global $post;
        return $post instanceof \WP_Post && 'product' === $post->post_type;
    }

    // -----------------------------------------------------------------------
    // Product page auto-inject
    // -----------------------------------------------------------------------

    /**
     * Render the COD form directly on a WooCommerce single product page.
     * Reads the global $product object injected by WooCommerce.
     */
    public static function render_on_product_page(): void {
        global $product;

        if ( ! $product instanceof \WC_Product ) {
            return;
        }

        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo self::render_shortcode( [ 'product_id' => $product->get_id() ] );
    }

    // -----------------------------------------------------------------------
    // Shortcode
    // -----------------------------------------------------------------------

    /**
     * [wcf_order_form product_id="123" variation_id="456"]
     *
     * Returns the form HTML as a string (shortcodes must not echo).
     *
     * @param  array|string $atts  Shortcode attributes.
     * @return string              Form HTML.
     */
    public static function render_shortcode( array|string $atts ): string {
        $atts = shortcode_atts(
            [
                'product_id'   => 0,
                'variation_id' => 0,
            ],
            $atts,
            'wcf_order_form'
        );

        $product_id   = absint( $atts['product_id'] );
        $variation_id = absint( $atts['variation_id'] );

        if ( $product_id <= 0 ) {
            if ( current_user_can( 'manage_woocommerce' ) ) {
                return '<p class="wcf-error">' .
                       esc_html__( '[wcf_order_form] requires a product_id attribute.', 'woo-cod-form' ) .
                       '</p>';
            }
            return '';
        }

        // Validate product exists.
        $product_data = WC_Bridge::get_product_data( $product_id, $variation_id );

        if ( isset( $product_data['error'] ) ) {
            if ( current_user_can( 'manage_woocommerce' ) ) {
                return '<p class="wcf-error">' . esc_html( $product_data['error'] ) . '</p>';
            }
            return '';
        }

        // Enqueue assets (idempotent).
        self::enqueue_assets( $product_id, $product_data );

        // Render form via template.
        return self::get_template_html( 'form-main.php', [
            'product_id'   => $product_id,
            'variation_id' => $variation_id,
            'product'      => $product_data,
        ] );
    }

    // -----------------------------------------------------------------------
    // Asset loading
    // -----------------------------------------------------------------------

    /**
     * Enqueue frontend CSS/JS and pass required data to JavaScript.
     * Only runs once per request, even with multiple shortcodes.
     *
     * @param int   $product_id    Active product ID.
     * @param array $product_data  Formatted product data for JS.
     */
    private static function enqueue_assets( int $product_id, array $product_data ): void {
        if ( self::$assets_enqueued ) {
            return;
        }

        self::$assets_enqueued = true;

        wp_enqueue_style(
            'wcf-cairo-font',
            'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'wcf-form',
            WCF_ASSETS_URL . 'css/cod-form.css',
            [],
            WCF_VERSION
        );

        if ( is_rtl() ) {
            wp_enqueue_style(
                'wcf-form-rtl',
                WCF_ASSETS_URL . 'css/cod-form-rtl.css',
                [ 'wcf-form' ],
                WCF_VERSION
            );
        }

        $radius = max( 0, (int) get_option( 'wcf_border_radius', 18 ) );
        $width  = max( 320, (int) get_option( 'wcf_form_width', 720 ) );
        $color  = sanitize_hex_color( (string) get_option( 'wcf_button_color', '#111827' ) ) ?: '#111827';
        $input_raw = get_option( 'wcf_input_size', 52 );
        if ( in_array( $input_raw, [ 'compact', 'normal', 'large' ], true ) ) {
            $input_raw = 'compact' === $input_raw ? 44 : ( 'normal' === $input_raw ? 48 : 56 );
        }
        $input_height = min( 90, max( 34, absint( $input_raw ) ) );
        $input_pad_y  = max( 6, (int) floor( ( $input_height - 22 ) / 2 ) );
        wp_add_inline_style( 'wcf-form', sprintf( '.wcf-order-form-shell{--wcf-radius:%1$dpx;--wcf-button:%2$s;max-width:%3$dpx;--wcf-input-height:%4$dpx;--wcf-input-pad-y:%5$dpx}.wcf-input,.wcf-select{min-height:%4$dpx;height:%4$dpx;padding:%5$dpx 14px}.wcf-textarea{height:auto;min-height:%6$dpx}.wcf-btn-primary{background:%2$s}.wcf-design-compact .wcf-form-row{margin-bottom:10px}.wcf-design-minimal .wcf-order-form-shell{box-shadow:none;border:1px solid #e5e7eb}', $radius, $color, $width, $input_height, $input_pad_y, max( 86, $input_height * 2 ) ) );

        wp_enqueue_script(
            'wcf-form',
            WCF_ASSETS_URL . 'js/cod-form.js',
            [],
            WCF_VERSION,
            true // Load in footer.
        );

        $pixel_boot = '';
        $fb_pixel = preg_replace( '/[^0-9]/', '', (string) get_option( 'wcf_facebook_pixel_id', '' ) );
        if ( '' !== $fb_pixel ) {
            $pixel_boot .= "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" . esc_js( $fb_pixel ) . "');fbq('track','PageView');";
        }
        $tt_pixel = sanitize_text_field( (string) get_option( 'wcf_tiktok_pixel_id', '' ) );
        if ( '' !== $tt_pixel ) {
            $pixel_boot .= "!function(w,d,t){w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=['page','track','identify','instances','debug','on','off','once','ready','alias','group','enableCookie','disableCookie'];ttq.setAndDefer=function(t,e){t[e]=function(){t.push([e].concat(Array.prototype.slice.call(arguments,0)))}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.load=function(e){var i='https://analytics.tiktok.com/i18n/pixel/events.js';ttq._i=ttq._i||{};ttq._i[e]=[];ttq._i[e]._u=i;ttq._t=ttq._t||{};ttq._t[e]=+new Date;var o=d.createElement('script');o.type='text/javascript';o.async=!0;o.src=i+'?sdkid='+e+'&lib='+t;var a=d.getElementsByTagName('script')[0];a.parentNode.insertBefore(o,a)};ttq.load('" . esc_js( $tt_pixel ) . "');ttq.page();}(window,document,'ttq');";
        }
        if ( '' !== $pixel_boot ) {
            wp_add_inline_script( 'wcf-form', $pixel_boot, 'before' );
        }

        // Pass server-side data to the JS bundle.
        wp_localize_script(
            'wcf-form',
            'wcfData',
            [
                'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
                'nonce'      => Nonce_Manager::create(),
                'product'    => $product_data,
                'productId'  => $product_id,
                'currency'   => self::currency_symbol(),
                'currencyCode' => self::currency_code(),
                'maxQuantity'  => max( 1, (int) get_option( 'wcf_max_quantity', 5 ) ),
                'thankyouUrl'=> self::get_thankyou_url(),
                'quantityDiscounts' => (bool) get_option( 'wcf_quantity_discounts_enabled', false ) && class_exists( '\\WCF\\Modules\\Admin\\Settings_Manager' ) ? \WCF\Modules\Admin\Settings_Manager::parse_quantity_rules() : [],
                'tracking' => [
                    'facebookPixelId' => (string) get_option( 'wcf_facebook_pixel_id', '' ),
                    'tiktokPixelId'   => (string) get_option( 'wcf_tiktok_pixel_id', '' ),
                    'gtmId'           => (string) get_option( 'wcf_gtm_id', '' ),
                    'purchaseEvent'   => (bool) get_option( 'wcf_tracking_purchase_event', true ),
                ],
                'i18n'       => [
                    'submitting'    => __( 'جاري إرسال الطلب…',              'woo-cod-form' ),
                    'success'       => __( 'تم إرسال الطلب بنجاح!',   'woo-cod-form' ),
                    'genericError'  => __( 'حدث خطأ. حاول مرة أخرى.', 'woo-cod-form' ),
                    'outOfStock'    => __( 'غير متوفر.',                'woo-cod-form' ),
                ],
            ]
        );
    }

    // -----------------------------------------------------------------------
    // Template loader
    // -----------------------------------------------------------------------

    /**
     * Resolve the thank-you page URL from the stored page ID.
     */
    private static function currency_code(): string {
        $override = (string) get_option( 'wcf_currency_code', '' );
        return '' !== $override ? $override : get_woocommerce_currency();
    }

    private static function currency_symbol(): string {
        return get_woocommerce_currency_symbol( self::currency_code() );
    }

    private static function get_thankyou_url(): string {
        $page_id = (int) get_option( 'wcf_thankyou_page', 0 );

        if ( $page_id > 0 ) {
            $permalink = get_permalink( $page_id );
            return $permalink ? (string) $permalink : '';
        }

        return '';
    }

    /**
     * Load a template file and return its output as a string.
     *
     * Theme override path:
     *   wp-content/themes/active-theme/woo-cod-form/{template}
     *
     * Plugin default path:
     *   wp-content/plugins/woo-cod-form/templates/{template}
     *
     * @param  string  $template  Template filename (e.g. 'form-main.php').
     * @param  array   $data      Variables extracted into template scope.
     * @return string             Rendered HTML.
     */
    public static function get_template_html( string $template, array $data = [] ): string {
        $template = sanitize_file_name( $template );

        // Allow theme overrides.
        $theme_path  = get_stylesheet_directory() . '/woo-cod-form/' . $template;
        $plugin_path = WCF_TEMPLATES . $template;

        $file = file_exists( $theme_path ) ? $theme_path : $plugin_path;

        if ( ! file_exists( $file ) ) {
            return '<!-- wcf: template ' . esc_html( $template ) . ' not found -->';
        }

        // Extract data into local scope for the template.
        // phpcs:ignore WordPress.PHP.DontExtract.extract_extract
        extract( $data, EXTR_SKIP );

        ob_start();
        include $file;
        return (string) ob_get_clean();
    }
}
