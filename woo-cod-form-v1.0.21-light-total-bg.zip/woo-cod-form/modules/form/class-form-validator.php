<?php
/**
 * File: modules/form/class-form-validator.php
 *
 * Server-side validation for sanitized COD form data.
 *
 * Design:
 *   - Rule definitions live in get_rules() — easy to extend.
 *   - Each field accumulates at most ONE error (first rule that fails wins).
 *   - A cross-field product/variation check runs after per-field rules.
 *   - All WC API calls (product existence, stock) happen only when
 *     the basic field rules pass, minimising unnecessary DB hits.
 *   - Returns [] on success; ['field' => 'translated error'] on failure.
 */

namespace WCF\Modules\Form;

defined( 'ABSPATH' ) || exit;

final class Form_Validator {

    /**
     * Validate a sanitized data array from Form_Sanitizer::sanitize().
     *
     * @param  array  $data  Clean form data.
     * @return array         Associative array of field → error message.
     *                       Empty array means all fields are valid.
     */
    public static function validate( array $data ): array {
        $errors = [];

        // Per-field rules.
        foreach ( self::get_rules( $data ) as $field => $rules ) {
            $value = $data[ $field ] ?? '';
            $error = self::apply_rules( $field, (string) $value, $rules, $data );
            if ( $error !== null ) {
                $errors[ $field ] = $error;
            }
        }

        // Cross-field: product existence + variation consistency + stock.
        if ( empty( $errors['product_id'] ) && empty( $errors['variation_id'] ) ) {
            $product_error = self::validate_product( $data );
            if ( $product_error !== null ) {
                $errors['product_id'] = $product_error;
            }
        }

        return $errors;
    }

    // -----------------------------------------------------------------------
    // Rule definitions
    // -----------------------------------------------------------------------

    /**
     * Build the rule map, merging the static schema with store-owner settings.
     *
     * Rule format: [ 'rule_name' => $parameter ]
     *   required   bool    Field must be non-empty.
     *   numeric    bool    Value must be numeric.
     *   positive   bool    Value must be > 0.
     *   min        int     Numeric minimum.
     *   max        int     Numeric maximum.
     *   min_len    int     String minimum length (mb_strlen).
     *   max_len    int     String maximum length (mb_strlen).
     *   phone      bool    Must match phone format regex.
     *   email      bool    Must pass is_email() when non-empty.
     *
     * @param  array  $data  Sanitized data (used to determine context-sensitive rules).
     * @return array[]
     */
    private static function get_rules( array $data ): array {
        // Fetch which billing fields the store owner has marked required.
        $field_settings = class_exists( '\\WCF\\Modules\\Admin\\Settings_Manager' )
            ? \WCF\Modules\Admin\Settings_Manager::get_form_fields()
            : (array) get_option( 'wcf_form_fields', [] );

        $is_enabled = static function ( string $suffix ) use ( $field_settings ): bool {
            return ! isset( $field_settings[ $suffix ] ) || ! empty( $field_settings[ $suffix ]['enabled'] );
        };

        $is_required = static function ( string $suffix ) use ( $field_settings, $is_enabled ): bool {
            return $is_enabled( $suffix ) && ! empty( $field_settings[ $suffix ]['required'] );
        };

        $rules = [
            'product_id' => [
                'required' => true,
                'numeric'  => true,
                'positive' => true,
            ],
            'variation_id' => [
                'numeric' => true,
            ],
            'quantity' => [
                'required' => true,
                'numeric'  => true,
                'min'      => 1,
                'max'      => max( 1, (int) get_option( 'wcf_max_quantity', 5 ) ),
            ],
            'wcf_first_name' => [
                'required' => $is_enabled( 'first_name' ), // Locked on in Form Builder.
                'min_len'  => 2,
                'max_len'  => 50,
            ],
            'wcf_last_name' => [
                'required' => $is_required( 'last_name' ),
                'max_len'  => 50,
            ],
            'wcf_phone' => [
                'required' => $is_enabled( 'phone' ), // Locked on in Form Builder.
                'phone'    => true,
            ],
            'wcf_address_1' => [
                'required' => $is_required( 'address_1' ),
                'max_len'  => 200,
            ],
            'wcf_city' => [
                'required' => $is_required( 'city' ),
                'max_len'  => 100,
            ],
            'wcf_state' => [
                'max_len' => 100,
            ],
            'wcf_postcode' => [
                'max_len' => 20,
            ],
            'wcf_email' => [
                'email'   => true,
                'max_len' => 254,
            ],
            'wcf_notes' => [
                'max_len' => 500,
            ],
        ];

        if ( class_exists( '\WCF\Modules\Admin\Settings_Manager' ) ) {
            foreach ( \WCF\Modules\Admin\Settings_Manager::get_product_extra_fields( (int) ( $data['product_id'] ?? 0 ) ) as $extra ) {
                $key = 'wcf_extra_' . sanitize_key( $extra['key'] );
                $rules[ $key ] = [
                    'required' => ! empty( $extra['required'] ),
                    'max_len'  => 120,
                ];
            }
        }

        return $rules;
    }

    // -----------------------------------------------------------------------
    // Rule engine
    // -----------------------------------------------------------------------

    /**
     * Apply a set of rules to a single field value.
     *
     * Stops on the first failing rule and returns the error message.
     * Returns null when all rules pass.
     *
     * @param  string  $field  Field key (used for error context).
     * @param  string  $value  Sanitized string value.
     * @param  array   $rules  Rule map for this field.
     * @param  array   $data   Full sanitized data (for cross-field rules).
     * @return string|null
     */
    private static function apply_rules(
        string $field,
        string $value,
        array  $rules,
        array  $data
    ): ?string {
        foreach ( $rules as $rule => $param ) {
            // Empty values pass all non-required rules — nothing to violate.
            if ( 'required' !== $rule && '' === $value ) {
                continue;
            }

            $error = self::check( $rule, $param, $value, $field );
            if ( $error !== null ) {
                return $error;
            }
        }

        return null;
    }

    /**
     * Evaluate a single rule against a value.
     *
     * @return string|null  Error message, or null on pass.
     */
    private static function check(
        string $rule,
        mixed  $param,
        string $value,
        string $field
    ): ?string {
        switch ( $rule ) {
            case 'required':
                if ( $param && '' === $value ) {
                    return sprintf(
                        /* translators: %s: field name */
                        __( '%s is required.', 'woo-cod-form' ),
                        self::label( $field )
                    );
                }
                break;

            case 'numeric':
                if ( $param && ! is_numeric( $value ) ) {
                    return sprintf(
                        __( '%s must be a number.', 'woo-cod-form' ),
                        self::label( $field )
                    );
                }
                break;

            case 'positive':
                if ( $param && (int) $value <= 0 ) {
                    return sprintf(
                        __( '%s must be greater than zero.', 'woo-cod-form' ),
                        self::label( $field )
                    );
                }
                break;

            case 'min':
                if ( (int) $value < (int) $param ) {
                    return sprintf(
                        /* translators: 1: field name, 2: minimum value */
                        __( '%1$s must be at least %2$d.', 'woo-cod-form' ),
                        self::label( $field ),
                        (int) $param
                    );
                }
                break;

            case 'max':
                if ( (int) $value > (int) $param ) {
                    return sprintf(
                        __( '%1$s must be no more than %2$d.', 'woo-cod-form' ),
                        self::label( $field ),
                        (int) $param
                    );
                }
                break;

            case 'min_len':
                if ( mb_strlen( $value ) < (int) $param ) {
                    return sprintf(
                        /* translators: 1: field name, 2: minimum character count */
                        __( '%1$s must be at least %2$d characters.', 'woo-cod-form' ),
                        self::label( $field ),
                        (int) $param
                    );
                }
                break;

            case 'max_len':
                if ( mb_strlen( $value ) > (int) $param ) {
                    return sprintf(
                        __( '%1$s must not exceed %2$d characters.', 'woo-cod-form' ),
                        self::label( $field ),
                        (int) $param
                    );
                }
                break;

            case 'phone':
                if ( $param && ! self::is_valid_phone( $value ) ) {
                    return __( 'Please enter a valid phone number.', 'woo-cod-form' );
                }
                break;

            case 'email':
                if ( $param && '' !== $value && ! is_email( $value ) ) {
                    return __( 'Please enter a valid email address.', 'woo-cod-form' );
                }
                break;
        }

        return null;
    }

    // -----------------------------------------------------------------------
    // Cross-field: product / variation / stock
    // -----------------------------------------------------------------------

    /**
     * Validate product_id, variation_id consistency, and current stock level.
     *
     * Called only when per-field rules for product_id and variation_id pass.
     *
     * @param  array       $data  Sanitized data.
     * @return string|null        Error message or null.
     */
    private static function validate_product( array $data ): ?string {
        $product_id   = (int) $data['product_id'];
        $variation_id = (int) ( $data['variation_id'] ?? 0 );
        $quantity     = (int) ( $data['quantity'] ?? 1 );

        $parent = wc_get_product( $product_id );

        if ( ! $parent instanceof \WC_Product ) {
            return __( 'The selected product does not exist.', 'woo-cod-form' );
        }

        // Variable product must have a valid variation selected.
        if ( $parent->is_type( 'variable' ) ) {
            if ( $variation_id <= 0 ) {
                return __( 'Please select a product option.', 'woo-cod-form' );
            }

            $variation = wc_get_product( $variation_id );

            if ( ! $variation instanceof \WC_Product_Variation ) {
                return __( 'The selected product option is invalid.', 'woo-cod-form' );
            }

            if ( $variation->get_parent_id() !== $product_id ) {
                return __( 'The selected product option does not match this product.', 'woo-cod-form' );
            }

            $purchasable = $variation;
        } else {
            $purchasable = $parent;
        }

        // Stock check.
        if ( ! $purchasable->is_in_stock() ) {
            return __( 'Sorry, this product is currently out of stock.', 'woo-cod-form' );
        }

        if ( $purchasable->managing_stock() ) {
            $available = $purchasable->get_stock_quantity();
            if ( $available !== null && $quantity > $available ) {
                return sprintf(
                    /* translators: %d: available stock quantity */
                    __( 'Only %d unit(s) available. Please reduce the quantity.', 'woo-cod-form' ),
                    $available
                );
            }
        }

        return null;
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /**
     * Return a human-readable label for error messages.
     * Falls back to the raw field key, cleaned up.
     */
    private static function label( string $field ): string {
        $labels = [
            'product_id'     => __( 'Product', 'woo-cod-form' ),
            'variation_id'   => __( 'Product option', 'woo-cod-form' ),
            'quantity'       => __( 'Quantity', 'woo-cod-form' ),
            'wcf_first_name' => __( 'First name', 'woo-cod-form' ),
            'wcf_last_name'  => __( 'Last name', 'woo-cod-form' ),
            'wcf_phone'      => __( 'Phone number', 'woo-cod-form' ),
            'wcf_address_1'  => __( 'Address', 'woo-cod-form' ),
            'wcf_city'       => __( 'City', 'woo-cod-form' ),
            'wcf_state'      => __( 'State', 'woo-cod-form' ),
            'wcf_postcode'   => __( 'Postcode', 'woo-cod-form' ),
            'wcf_email'      => __( 'Email address', 'woo-cod-form' ),
            'wcf_notes'      => __( 'Order notes', 'woo-cod-form' ),
        ];

        return $labels[ $field ] ?? ucwords( str_replace( [ 'wcf_', '_' ], [ '', ' ' ], $field ) );
    }

    /**
     * Validate a phone number string.
     *
     * Accepts:
     *   + optional leading +
     *   + digits, spaces, hyphens, parentheses
     *   + total digits: 7–15 (ITU-T E.164 range)
     */
    private static function is_valid_phone( string $phone ): bool {
        // Strip formatting characters to count digits.
        $digits_only = (string) preg_replace( '/[^\d]/', '', $phone );
        $digit_count = strlen( $digits_only );

        if ( $digit_count < 7 || $digit_count > 15 ) {
            return false;
        }

        // Full format check.
        return (bool) preg_match( '/^\+?[\d\s\-\(\)]{7,20}$/', $phone );
    }
}
