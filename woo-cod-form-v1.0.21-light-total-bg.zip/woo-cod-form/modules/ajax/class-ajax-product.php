<?php
/**
 * File: modules/ajax/class-ajax-product.php
 *
 * Handles product data AJAX actions:
 *   wcf_get_product   → full product data (price, stock, all variations)
 *   wcf_get_variation → single variation data (price, stock, attributes)
 *
 * Both endpoints require a valid nonce.
 * Product data is public, but nonce prevents unauthenticated scraping/abuse.
 */

namespace WCF\Modules\Ajax;

use WCF\Modules\Security\Nonce_Manager;
use WCF\Modules\Woocommerce\WC_Bridge;

defined( 'ABSPATH' ) || exit;

final class Ajax_Product {

    /**
     * wcf_get_product — return full product data.
     *
     * Required POST params:
     *   wcf_nonce   string  Valid nonce.
     *   product_id  int     WooCommerce product ID.
     */
    public static function handle_product(): void {
        self::verify_nonce();

        $product_id = absint( $_POST['product_id'] ?? 0 );

        if ( $product_id <= 0 ) {
            wp_send_json_error(
                [ 'message' => __( 'A valid product ID is required.', 'woo-cod-form' ) ],
                400
            );
        }

        $data = WC_Bridge::get_product_data( $product_id );

        if ( isset( $data['error'] ) ) {
            wp_send_json_error( [ 'message' => $data['error'] ], 404 );
        }

        wp_send_json_success( $data );
    }

    /**
     * wcf_get_variation — return a single variation's data.
     *
     * Required POST params:
     *   wcf_nonce     string  Valid nonce.
     *   product_id    int     Parent product ID.
     *   variation_id  int     Variation ID.
     */
    public static function handle_variation(): void {
        self::verify_nonce();

        $product_id   = absint( $_POST['product_id']   ?? 0 );
        $variation_id = absint( $_POST['variation_id'] ?? 0 );

        if ( $product_id <= 0 || $variation_id <= 0 ) {
            wp_send_json_error(
                [ 'message' => __( 'Invalid product or variation ID.', 'woo-cod-form' ) ],
                400
            );
        }

        $data = WC_Bridge::get_product_data( $product_id, $variation_id );

        if ( isset( $data['error'] ) ) {
            wp_send_json_error( [ 'message' => $data['error'] ], 404 );
        }

        wp_send_json_success( $data );
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Verify nonce; send 403 and exit if invalid.
     */
    private static function verify_nonce(): void {
        if ( ! Nonce_Manager::verify() ) {
            wp_send_json_error(
                [ 'message' => __( 'Security check failed.', 'woo-cod-form' ) ],
                403
            );
        }
    }
}
