<?php
/**
 * File: modules/ajax/class-ajax-order.php
 */

namespace WCF\Modules\Ajax;

use WCF\Modules\Form\Field_Mapper;
use WCF\Modules\Form\Form_Sanitizer;
use WCF\Modules\Form\Form_Validator;
use WCF\Modules\Security\Honeypot;
use WCF\Modules\Security\Nonce_Manager;
use WCF\Modules\Security\Rate_Limiter;
use WCF\Modules\Woocommerce\WC_Bridge;

defined( 'ABSPATH' ) || exit;

final class Ajax_Order {

    public static function handle(): void {
        if ( ! Nonce_Manager::verify() ) {
            wp_send_json_error(
                [ 'message' => __( 'فشل التحقق الأمني. المرجو تحديث الصفحة والمحاولة مرة أخرى.', 'woo-cod-form' ) ],
                403
            );
        }

        if ( (bool) get_option( 'wcf_enable_honeypot', true ) && ! Honeypot::passes() ) {
            wp_send_json_success( [ 'message' => __( 'تم إرسال الطلب بنجاح!', 'woo-cod-form' ) ] );
        }

        if ( ! Rate_Limiter::allow() ) {
            wp_send_json_error(
                [ 'message' => __( 'تم إرسال طلبات كثيرة. المرجو الانتظار قليلاً ثم المحاولة مرة أخرى.', 'woo-cod-form' ) ],
                429
            );
        }

        // phpcs:ignore WordPress.Security.NonceVerification — already verified above.
        $clean = Form_Sanitizer::sanitize( $_POST );

        $errors = Form_Validator::validate( $clean );

        if ( ! empty( $errors ) ) {
            wp_send_json_error(
                [
                    'message' => __( 'المرجو تصحيح الأخطاء أسفله.', 'woo-cod-form' ),
                    'errors'  => $errors,
                ],
                422
            );
        }

        if ( self::is_duplicate_order( $clean ) ) {
            wp_send_json_error(
                [ 'message' => __( 'لقد أرسلت نفس الطلب مؤخراً. المرجو الانتظار قبل إعادة المحاولة.', 'woo-cod-form' ) ],
                409
            );
        }

        $mapped = Field_Mapper::map( $clean );
        $result = WC_Bridge::create_order( $mapped );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ], 500 );
        }

        do_action( 'wcf_order_created', $result );

        $order = wc_get_order( $result );

        wp_send_json_success( [
            'order_id'  => $result,
            'order_key' => $order ? $order->get_order_key() : '',
            'message'   => __( 'تم استلام طلبك بنجاح!', 'woo-cod-form' ),
        ] );
    }

    /**
     * Block duplicate orders from the same phone/product during a short window.
     */
    private static function is_duplicate_order( array $clean ): bool {
        if ( ! (bool) get_option( 'wcf_block_duplicate_orders', true ) ) {
            return false;
        }

        $phone      = (string) ( $clean['wcf_phone'] ?? '' );
        $product_id = (int) ( $clean['product_id'] ?? 0 );

        if ( '' === $phone || $product_id <= 0 || ! function_exists( 'wc_get_orders' ) ) {
            return false;
        }

        $window_minutes = max( 1, (int) get_option( 'wcf_duplicate_window', 30 ) );
        $after          = gmdate( 'Y-m-d H:i:s', time() - ( $window_minutes * 60 ) );

        $orders = wc_get_orders( [
            'limit'         => 3,
            'status'        => [ 'pending', 'processing', 'on-hold', 'completed' ],
            'billing_phone' => $phone,
            'date_created'  => '>' . $after,
            'meta_key'      => '_wcf_source',
            'meta_value'    => 'cod_form',
            'return'        => 'objects',
        ] );

        foreach ( $orders as $order ) {
            if ( ! $order instanceof \WC_Order ) {
                continue;
            }

            foreach ( $order->get_items() as $item ) {
                if ( (int) $item->get_product_id() === $product_id || (int) $item->get_variation_id() === $product_id ) {
                    return true;
                }
            }
        }

        return false;
    }
}
