<?php
/**
 * File: modules/ajax/class-ajax-router.php
 *
 * Central AJAX registration hub.
 *
 * All wp_ajax_* / wp_ajax_nopriv_* actions are declared here.
 * Handlers live in dedicated handler classes (Ajax_Order, Ajax_Product).
 *
 * Convention:
 *   Action name           →  Handler class   →  Method
 *   wcf_submit_order      →  Ajax_Order       →  handle()
 *   wcf_get_product       →  Ajax_Product     →  handle_product()
 *   wcf_get_variation     →  Ajax_Product     →  handle_variation()
 */

namespace WCF\Modules\Ajax;

defined( 'ABSPATH' ) || exit;

final class Ajax_Router {

    /**
     * Register all AJAX actions.
     * Called once from Plugin::boot().
     */
    public static function init(): void {
        $routes = [
            'wcf_submit_order'  => [ Ajax_Order::class,   'handle' ],
            'wcf_get_product'   => [ Ajax_Product::class, 'handle_product' ],
            'wcf_get_variation' => [ Ajax_Product::class, 'handle_variation' ],
        ];

        foreach ( $routes as $action => $callback ) {
            // Both authenticated and guest users can submit COD forms.
            add_action( 'wp_ajax_'        . $action, $callback );
            add_action( 'wp_ajax_nopriv_' . $action, $callback );
        }
    }
}
