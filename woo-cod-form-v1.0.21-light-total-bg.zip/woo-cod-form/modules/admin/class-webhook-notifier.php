<?php
/**
 * File: modules/admin/class-webhook-notifier.php
 *
 * Fires a non-blocking HTTP POST to a store-owner-configured URL
 * whenever the COD Form creates a new order.
 *
 * Use cases: Zapier, Make (Integromat), custom CRM webhooks, n8n, etc.
 *
 * Hook: wcf_order_created (fired by Ajax_Order after successful creation).
 * Payload: JSON body with order summary data.
 *
 * Failure is silent — the order has already been created.
 * wp_remote_post() is called with blocking=false so it never delays
 * the AJAX response back to the customer.
 */

namespace WCF\Modules\Admin;

defined( 'ABSPATH' ) || exit;

final class Webhook_Notifier {

    // -----------------------------------------------------------------------
    // Boot
    // -----------------------------------------------------------------------

    /**
     * Register the hook listener.
     * Called from Plugin::boot().
     */
    public static function init(): void {
        add_action( 'wcf_order_created', [ self::class, 'dispatch' ],        10, 1 );
        add_action( 'wcf_order_created', [ self::class, 'send_admin_email' ], 20, 1 );
    }

    // -----------------------------------------------------------------------
    // Admin email notification
    // -----------------------------------------------------------------------

    /**
     * Send a plain-text notification email to the configured admin address
     * whenever a COD Form order is successfully placed.
     *
     * Fires at priority 20 on wcf_order_created (after the webhook dispatch).
     * Skipped silently when wcf_admin_email is blank or not a valid address.
     *
     * @param int $order_id  Newly created WC order ID.
     */
    public static function send_admin_email( int $order_id ): void {
        $email = (string) get_option( 'wcf_admin_email', '' );

        if ( '' === $email || ! is_email( $email ) ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if ( ! $order instanceof \WC_Order ) {
            return;
        }

        /* translators: 1: order ID, 2: site name */
        $subject = sprintf( __( 'New COD Order #%1$d — %2$s', 'woo-cod-form' ), $order_id, get_bloginfo( 'name' ) );

        $lines = [
            __( 'A new Cash on Delivery order has been placed via COD Form.', 'woo-cod-form' ),
            '',
            /* translators: %d: order ID */
            sprintf( __( 'Order:    #%d',        'woo-cod-form' ), $order_id ),
            /* translators: 1: first name, 2: last name */
            sprintf( __( 'Customer: %1$s %2$s',  'woo-cod-form' ), $order->get_billing_first_name(), $order->get_billing_last_name() ),
            /* translators: %s: phone number */
            sprintf( __( 'Phone:    %s',          'woo-cod-form' ), $order->get_billing_phone() ),
            /* translators: %s: city */
            sprintf( __( 'City:     %s',          'woo-cod-form' ), $order->get_billing_city() ),
            /* translators: 1: total amount, 2: currency code */
            sprintf( __( 'Total:    %1$s %2$s',   'woo-cod-form' ), $order->get_total(), $order->get_currency() ),
            '',
            /* translators: %s: admin URL */
            sprintf( __( 'View order: %s', 'woo-cod-form' ),
                admin_url( 'post.php?post=' . $order_id . '&action=edit' ) ),
        ];

        wp_mail( $email, $subject, implode( "\n", $lines ) );
    }

    // -----------------------------------------------------------------------
    // Dispatch
    // -----------------------------------------------------------------------

    /**
     * Send the webhook payload.
     *
     * @param int $order_id  The newly created WC order ID.
     */
    public static function dispatch( int $order_id ): void {
        $url = (string) get_option( 'wcf_webhook_url', '' );

        if ( '' === $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
            return;
        }

        $order = wc_get_order( $order_id );

        if ( ! $order instanceof \WC_Order ) {
            return;
        }

        $payload = self::build_payload( $order );

        // Non-blocking: fires and forgets — does not wait for a response.
        wp_remote_post( $url, [
            'method'      => 'POST',
            'timeout'     => 5,
            'redirection' => 3,
            'blocking'    => false,
            'headers'     => [
                'Content-Type' => 'application/json',
                'X-WCF-Event'  => 'order.created',
                'X-WCF-Site'   => get_bloginfo( 'url' ),
            ],
            'body'        => wp_json_encode( $payload ),
        ] );
    }

    // -----------------------------------------------------------------------
    // Payload builder
    // -----------------------------------------------------------------------

    /**
     * Build a clean, serialisable payload array from the WC order.
     *
     * @param  \WC_Order $order
     * @return array
     */
    private static function build_payload( \WC_Order $order ): array {
        $items = [];

        foreach ( $order->get_items() as $item ) {
            /** @var \WC_Order_Item_Product $item */
            $items[] = [
                'product_id'   => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'name'         => $item->get_name(),
                'quantity'     => $item->get_quantity(),
                'total'        => $item->get_total(),
            ];
        }

        return [
            'event'     => 'order.created',
            'source'    => 'wcf_cod_form',
            'site_url'  => get_bloginfo( 'url' ),
            'order'     => [
                'id'         => $order->get_id(),
                'status'     => $order->get_status(),
                'total'      => $order->get_total(),
                'currency'   => $order->get_currency(),
                'created_at' => $order->get_date_created()?->format( \DateTimeInterface::ATOM ),
            ],
            'customer'  => [
                'first_name' => $order->get_billing_first_name(),
                'last_name'  => $order->get_billing_last_name(),
                'phone'      => $order->get_billing_phone(),
                'city'       => $order->get_billing_city(),
                'country'    => $order->get_billing_country(),
                'email'      => $order->get_billing_email(),
            ],
            'items'     => $items,
        ];
    }
}
