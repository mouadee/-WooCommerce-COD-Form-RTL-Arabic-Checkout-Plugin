<?php
/**
 * File: modules/admin/class-settings-manager.php
 */

namespace WCF\Modules\Admin;

defined( 'ABSPATH' ) || exit;

final class Settings_Manager {

    public static function register_settings(): void {
        self::register_general();
        self::register_form();
        self::register_product();
        self::register_offers();
        self::register_design();
        self::register_tracking();
        self::register_templates();
        self::register_conversion();
        self::register_notify();
    }

    private static function register_general(): void {
        $group   = 'wcf_settings_general';
        $section = 'wcf_general_section';
        $page    = Admin_Panel::MENU_SLUG . '_general';

        $settings = [
            'wcf_order_status'           => [ self::class, 'sanitize_order_status' ],
            'wcf_thankyou_page'          => 'absint',
            'wcf_inline_confirm'         => [ self::class, 'sanitize_bool' ],
            'wcf_default_country'        => [ self::class, 'sanitize_country' ],
            'wcf_currency_code'          => [ self::class, 'sanitize_currency' ],
            'wcf_max_quantity'           => [ self::class, 'sanitize_max_quantity' ],
            'wcf_enable_on_product_page' => [ self::class, 'sanitize_bool' ],
            'wcf_rate_limit'             => [ self::class, 'sanitize_rate_limit' ],
            'wcf_rate_window'            => [ self::class, 'sanitize_rate_window' ],
            'wcf_enable_honeypot'        => [ self::class, 'sanitize_bool' ],
            'wcf_block_duplicate_orders' => [ self::class, 'sanitize_bool' ],
            'wcf_duplicate_window'       => [ self::class, 'sanitize_duplicate_window' ],
        ];

        foreach ( $settings as $option => $callback ) {
            register_setting( $group, $option, [ 'sanitize_callback' => $callback ] );
        }

        add_settings_section( $section, __( 'الإعدادات العامة', 'woo-cod-form' ), '__return_false', $page );

        $fields = [
            'wcf_order_status'           => [ __( 'حالة الطلب الافتراضية', 'woo-cod-form' ), 'field_order_status' ],
            'wcf_thankyou_page'          => [ __( 'صفحة الشكر', 'woo-cod-form' ), 'field_thankyou_page' ],
            'wcf_inline_confirm'         => [ __( 'تأكيد داخل نفس الصفحة', 'woo-cod-form' ), 'field_inline_confirm' ],
            'wcf_default_country'        => [ __( 'الدولة الافتراضية', 'woo-cod-form' ), 'field_default_country' ],
            'wcf_currency_code'          => [ __( 'العملة', 'woo-cod-form' ), 'field_currency_code' ],
            'wcf_max_quantity'           => [ __( 'الحد الأقصى للكمية', 'woo-cod-form' ), 'field_max_quantity' ],
            'wcf_enable_on_product_page' => [ __( 'إظهار الفورم في صفحة المنتج', 'woo-cod-form' ), 'field_enable_on_product_page' ],
            'wcf_rate_limit'             => [ __( 'حد الطلبات لكل IP', 'woo-cod-form' ), 'field_rate_limit' ],
            'wcf_rate_window'            => [ __( 'نافذة الحماية', 'woo-cod-form' ), 'field_rate_window' ],
            'wcf_enable_honeypot'        => [ __( 'حقل حماية مخفي', 'woo-cod-form' ), 'field_enable_honeypot' ],
            'wcf_block_duplicate_orders' => [ __( 'منع الطلبات المكررة', 'woo-cod-form' ), 'field_block_duplicate_orders' ],
            'wcf_duplicate_window'       => [ __( 'مدة منع التكرار', 'woo-cod-form' ), 'field_duplicate_window' ],
        ];

        foreach ( $fields as $id => [ $label, $callback ] ) {
            add_settings_field( $id, $label, [ self::class, $callback ], $page, $section );
        }
    }

    private static function register_form(): void {
        $group   = 'wcf_settings_form';
        $section = 'wcf_form_section';
        $page    = Admin_Panel::MENU_SLUG . '_form';
        register_setting( $group, 'wcf_form_fields', [ 'sanitize_callback' => [ self::class, 'sanitize_form_fields' ] ] );
        add_settings_section( $section, __( 'بناء نموذج الطلب', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_form_fields', __( 'الحقول', 'woo-cod-form' ), [ self::class, 'field_form_fields' ], $page, $section );
    }

    private static function register_product(): void {
        $group = 'wcf_settings_product'; $section = 'wcf_product_section'; $page = Admin_Panel::MENU_SLUG . '_product';
        register_setting( $group, 'wcf_product_overrides_enabled', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_product_extra_fields', [ 'sanitize_callback' => [ self::class, 'sanitize_textarea_lines' ] ] );
        add_settings_section( $section, __( 'إعدادات حسب المنتج', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_product_overrides_enabled', __( 'تفعيل حقول خاصة لكل منتج', 'woo-cod-form' ), [ self::class, 'field_product_overrides_enabled' ], $page, $section );
        add_settings_field( 'wcf_product_extra_fields', __( 'حقول المنتج المخصصة', 'woo-cod-form' ), [ self::class, 'field_product_extra_fields' ], $page, $section );
    }

    private static function register_offers(): void {
        $group = 'wcf_settings_offers'; $section = 'wcf_offers_section'; $page = Admin_Panel::MENU_SLUG . '_offers';
        register_setting( $group, 'wcf_bundles_enabled', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_bundle_offers', [ 'sanitize_callback' => [ self::class, 'sanitize_bundle_offers' ] ] );
        register_setting( $group, 'wcf_default_bundle', [ 'sanitize_callback' => [ self::class, 'sanitize_default_bundle' ] ] );
        register_setting( $group, 'wcf_free_delivery_text', [ 'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( $group, 'wcf_urgency_text', [ 'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( $group, 'wcf_quantity_discounts_enabled', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_quantity_discount_rules', [ 'sanitize_callback' => [ self::class, 'sanitize_textarea_lines' ] ] );
        register_setting( $group, 'wcf_offer_badge_text', [ 'sanitize_callback' => 'sanitize_text_field' ] );
        add_settings_section( $section, __( 'العروض والباقات', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_bundles_enabled', __( 'تفعيل بطاقات الباقات', 'woo-cod-form' ), [ self::class, 'field_bundles_enabled' ], $page, $section );
        add_settings_field( 'wcf_bundle_offers', __( 'الباقات الثلاث', 'woo-cod-form' ), [ self::class, 'field_bundle_offers' ], $page, $section );
        add_settings_field( 'wcf_default_bundle', __( 'الباقة الافتراضية', 'woo-cod-form' ), [ self::class, 'field_default_bundle' ], $page, $section );
        add_settings_field( 'wcf_free_delivery_text', __( 'نص التوصيل المجاني', 'woo-cod-form' ), [ self::class, 'field_free_delivery_text' ], $page, $section );
        add_settings_field( 'wcf_urgency_text', __( 'نص الاستعجال', 'woo-cod-form' ), [ self::class, 'field_urgency_text' ], $page, $section );
        add_settings_field( 'wcf_quantity_discounts_enabled', __( 'تفعيل قواعد الكمية القديمة', 'woo-cod-form' ), [ self::class, 'field_quantity_discounts_enabled' ], $page, $section );
        add_settings_field( 'wcf_quantity_discount_rules', __( 'قواعد الكمية القديمة', 'woo-cod-form' ), [ self::class, 'field_quantity_discount_rules' ], $page, $section );
        add_settings_field( 'wcf_offer_badge_text', __( 'شارة العرض القديمة', 'woo-cod-form' ), [ self::class, 'field_offer_badge_text' ], $page, $section );
    }

    private static function register_design(): void {
        $group = 'wcf_settings_design'; $section = 'wcf_design_section'; $page = Admin_Panel::MENU_SLUG . '_design';
        foreach ( [
            'wcf_design_mode' => [ self::class, 'sanitize_design_mode' ],
            'wcf_form_width' => [ self::class, 'sanitize_width' ],
            'wcf_button_color' => [ self::class, 'sanitize_color' ],
            'wcf_border_radius' => [ self::class, 'sanitize_radius' ],
            'wcf_input_size' => [ self::class, 'sanitize_input_size' ],
            'wcf_show_product_image' => [ self::class, 'sanitize_bool' ],
            'wcf_sticky_summary' => [ self::class, 'sanitize_bool' ],
            'wcf_show_trust_badges' => [ self::class, 'sanitize_bool' ],
            'wcf_hide_native_title' => [ self::class, 'sanitize_bool' ],
            'wcf_hide_native_price' => [ self::class, 'sanitize_bool' ],
            'wcf_hide_native_add_to_cart' => [ self::class, 'sanitize_bool' ],
            'wcf_trust_badges_text' => [ self::class, 'sanitize_textarea_lines' ],
        ] as $option => $callback ) { register_setting( $group, $option, [ 'sanitize_callback' => $callback ] ); }
        add_settings_section( $section, __( 'تصميم الواجهة الأمامية', 'woo-cod-form' ), '__return_false', $page );
        foreach ( [
            'wcf_design_mode' => [ __( 'ستايل الفورم', 'woo-cod-form' ), 'field_design_mode' ],
            'wcf_form_width' => [ __( 'عرض الفورم', 'woo-cod-form' ), 'field_form_width' ],
            'wcf_button_color' => [ __( 'لون الزر', 'woo-cod-form' ), 'field_button_color' ],
            'wcf_border_radius' => [ __( 'استدارة الحواف', 'woo-cod-form' ), 'field_border_radius' ],
            'wcf_input_size' => [ __( 'حجم الحقول', 'woo-cod-form' ), 'field_input_size' ],
            'wcf_show_product_image' => [ __( 'إظهار صورة المنتج', 'woo-cod-form' ), 'field_show_product_image' ],
            'wcf_sticky_summary' => [ __( 'ملخص الطلب ثابت', 'woo-cod-form' ), 'field_sticky_summary' ],
            'wcf_show_trust_badges' => [ __( 'إظهار شارات الثقة', 'woo-cod-form' ), 'field_show_trust_badges' ],
            'wcf_hide_native_title' => [ __( 'إخفاء عنوان المنتج الأصلي', 'woo-cod-form' ), 'field_hide_native_title' ],
            'wcf_hide_native_price' => [ __( 'إخفاء السعر الأصلي', 'woo-cod-form' ), 'field_hide_native_price' ],
            'wcf_hide_native_add_to_cart' => [ __( 'إخفاء زر Add to cart الأصلي', 'woo-cod-form' ), 'field_hide_native_add_to_cart' ],
            'wcf_trust_badges_text' => [ __( 'نصوص شارات الثقة', 'woo-cod-form' ), 'field_trust_badges_text' ],
        ] as $id => [ $label, $callback ] ) { add_settings_field( $id, $label, [ self::class, $callback ], $page, $section ); }
    }

    private static function register_tracking(): void {
        $group = 'wcf_settings_tracking'; $section = 'wcf_tracking_section'; $page = Admin_Panel::MENU_SLUG . '_tracking';
        foreach ( [ 'wcf_facebook_pixel_id', 'wcf_tiktok_pixel_id', 'wcf_gtm_id' ] as $option ) { register_setting( $group, $option, [ 'sanitize_callback' => 'sanitize_text_field' ] ); }
        register_setting( $group, 'wcf_tracking_purchase_event', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        add_settings_section( $section, __( 'Pixels والتتبع', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_facebook_pixel_id', __( 'Facebook Pixel ID', 'woo-cod-form' ), [ self::class, 'field_generic' ], $page, $section, [ 'option' => 'wcf_facebook_pixel_id' ] );
        add_settings_field( 'wcf_tiktok_pixel_id', __( 'TikTok Pixel ID', 'woo-cod-form' ), [ self::class, 'field_generic' ], $page, $section, [ 'option' => 'wcf_tiktok_pixel_id' ] );
        add_settings_field( 'wcf_gtm_id', __( 'Google Tag Manager ID', 'woo-cod-form' ), [ self::class, 'field_generic' ], $page, $section, [ 'option' => 'wcf_gtm_id' ] );
        add_settings_field( 'wcf_tracking_purchase_event', __( 'إرسال حدث COD_Submitted', 'woo-cod-form' ), [ self::class, 'field_tracking_purchase_event' ], $page, $section );
    }

    private static function register_templates(): void {
        $group = 'wcf_settings_templates'; $section = 'wcf_templates_section'; $page = Admin_Panel::MENU_SLUG . '_templates';
        register_setting( $group, 'wcf_form_template', [ 'sanitize_callback' => [ self::class, 'sanitize_form_template' ] ] );
        add_settings_section( $section, __( 'قوالب جاهزة', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_form_template', __( 'اختيار قالب الفورم', 'woo-cod-form' ), [ self::class, 'field_form_template' ], $page, $section );
    }

    private static function register_conversion(): void {
        $group   = 'wcf_settings_conversion'; $section = 'wcf_conversion_section'; $page = Admin_Panel::MENU_SLUG . '_conversion';
        register_setting( $group, 'wcf_timer_enabled',  [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_timer_minutes',  [ 'sanitize_callback' => 'absint' ] );
        register_setting( $group, 'wcf_timer_message',  [ 'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( $group, 'wcf_badges_enabled', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_social_enabled', [ 'sanitize_callback' => [ self::class, 'sanitize_bool' ] ] );
        register_setting( $group, 'wcf_social_message', [ 'sanitize_callback' => 'sanitize_text_field' ] );
        add_settings_section( $section, __( 'أدوات تحسين التحويل', 'woo-cod-form' ), '__return_false', $page );
        foreach ( [ 'wcf_timer_enabled' => __( 'تفعيل العداد', 'woo-cod-form' ), 'wcf_badges_enabled' => __( 'تفعيل شارات الثقة', 'woo-cod-form' ), 'wcf_social_enabled' => __( 'تفعيل الدليل الاجتماعي', 'woo-cod-form' ) ] as $id => $label ) { add_settings_field( $id, $label, [ self::class, 'field_checkbox' ], $page, $section, [ 'option' => $id ] ); }
        foreach ( [ 'wcf_timer_minutes' => __( 'مدة العداد بالدقائق', 'woo-cod-form' ), 'wcf_timer_message' => __( 'رسالة العداد', 'woo-cod-form' ), 'wcf_social_message' => __( 'رسالة الدليل الاجتماعي', 'woo-cod-form' ) ] as $id => $label ) { add_settings_field( $id, $label, [ self::class, 'field_generic' ], $page, $section, [ 'option' => $id ] ); }
    }

    private static function register_notify(): void {
        $group = 'wcf_settings_notify'; $section = 'wcf_notify_section'; $page = Admin_Panel::MENU_SLUG . '_notify';
        register_setting( $group, 'wcf_admin_email', [ 'sanitize_callback' => 'sanitize_email' ] );
        register_setting( $group, 'wcf_confirm_message', [ 'sanitize_callback' => 'sanitize_textarea_field' ] );
        register_setting( $group, 'wcf_webhook_url', [ 'sanitize_callback' => 'esc_url_raw' ] );
        add_settings_section( $section, __( 'الإشعارات', 'woo-cod-form' ), '__return_false', $page );
        add_settings_field( 'wcf_admin_email', __( 'بريد المدير', 'woo-cod-form' ), [ self::class, 'field_generic' ], $page, $section, [ 'option' => 'wcf_admin_email' ] );
        add_settings_field( 'wcf_confirm_message', __( 'رسالة تأكيد الطلب', 'woo-cod-form' ), [ self::class, 'field_textarea' ], $page, $section, [ 'option' => 'wcf_confirm_message' ] );
        add_settings_field( 'wcf_webhook_url', __( 'Webhook عند إنشاء طلب', 'woo-cod-form' ), [ self::class, 'field_generic' ], $page, $section, [ 'option' => 'wcf_webhook_url' ] );
    }

    public static function field_order_status(): void { $value = get_option( 'wcf_order_status', 'wc-pending' ); echo '<select name="wcf_order_status" class="wcf-control">'; foreach ( wc_get_order_statuses() as $slug => $label ) { printf( '<option value="%s" %s>%s</option>', esc_attr( $slug ), selected( $slug, $value, false ), esc_html( $label ) ); } echo '</select><p class="description">' . esc_html__( 'الحالة التي ستطبق مباشرة بعد إرسال الطلب.', 'woo-cod-form' ) . '</p>'; }
    public static function field_thankyou_page(): void { wp_dropdown_pages( [ 'name' => 'wcf_thankyou_page', 'show_option_none' => __( '— تأكيد داخل الصفحة بدون تحويل —', 'woo-cod-form' ), 'option_none_value' => 0, 'selected' => (int) get_option( 'wcf_thankyou_page', 0 ) ] ); }
    public static function field_inline_confirm(): void { self::toggle( 'wcf_inline_confirm', true, __( 'إظهار رسالة النجاح داخل نفس الصفحة.', 'woo-cod-form' ) ); }
    public static function field_enable_on_product_page(): void { self::toggle( 'wcf_enable_on_product_page', false, __( 'إضافة نموذج الطلب تلقائياً داخل صفحة المنتج.', 'woo-cod-form' ) ); }
    public static function field_enable_honeypot(): void { self::toggle( 'wcf_enable_honeypot', true, __( 'يضيف حقلاً مخفياً لاصطياد البوتات.', 'woo-cod-form' ) ); }
    public static function field_block_duplicate_orders(): void { self::toggle( 'wcf_block_duplicate_orders', true, __( 'يمنع نفس الهاتف من إنشاء طلب مكرر لنفس المنتج خلال مدة قصيرة.', 'woo-cod-form' ) ); }
    public static function field_product_overrides_enabled(): void { self::toggle( 'wcf_product_overrides_enabled', false, __( 'استعمل حقولاً إضافية حسب كل منتج مثل المقاس، اللون، النكهة، الضمان.', 'woo-cod-form' ) ); }
    public static function field_quantity_discounts_enabled(): void { self::toggle( 'wcf_quantity_discounts_enabled', false, __( 'تغيير السعر حسب الكمية المختارة ورفع متوسط قيمة الطلب.', 'woo-cod-form' ) ); }

    public static function field_bundles_enabled(): void { self::toggle( 'wcf_bundles_enabled', false, __( 'يعرض بطاقات باقات قابلة للنقر بدل الاعتماد على أزرار + و - فقط.', 'woo-cod-form' ) ); }
    public static function field_free_delivery_text(): void { printf( '<input type="text" name="wcf_free_delivery_text" value="%s" class="regular-text" dir="rtl" placeholder="توصيل مجاني" />', esc_attr( (string) get_option( 'wcf_free_delivery_text', 'توصيل مجاني' ) ) ); }
    public static function field_urgency_text(): void { printf( '<input type="text" name="wcf_urgency_text" value="%s" class="regular-text" dir="rtl" placeholder="العرض صالح اليوم فقط" />', esc_attr( (string) get_option( 'wcf_urgency_text', 'العرض صالح اليوم فقط' ) ) ); }

    public static function field_default_bundle(): void {
        $value = (string) get_option( 'wcf_default_bundle', 'bundle_2' );
        echo '<select name="wcf_default_bundle" class="wcf-control">';
        foreach ( self::get_bundle_offers( true ) as $id => $bundle ) {
            printf( '<option value="%s" %s>%s</option>', esc_attr( $id ), selected( $value, $id, false ), esc_html( $bundle['title'] . ' — ' . $bundle['quantity'] . ' قطعة' ) );
        }
        echo '</select><p class="description">' . esc_html__( 'هذه الباقة تكون مختارة تلقائياً عند فتح الفورم.', 'woo-cod-form' ) . '</p>';
    }

    public static function field_bundle_offers(): void {
        $bundles = self::get_bundle_offers( true );
        echo '<div class="wcf-bundle-admin-grid" dir="rtl">';
        foreach ( $bundles as $id => $bundle ) {
            echo '<div class="wcf-bundle-admin-card">';
            printf( '<div class="wcf-bundle-admin-head"><strong>%s</strong><span>%s</span></div>', esc_html( $bundle['title'] ), esc_html( $id ) );
            printf( '<label>%s<input type="text" name="wcf_bundle_offers[%s][title]" value="%s" dir="rtl"></label>', esc_html__( 'العنوان', 'woo-cod-form' ), esc_attr( $id ), esc_attr( $bundle['title'] ) );
            printf( '<label>%s<input type="number" min="1" max="999" name="wcf_bundle_offers[%s][quantity]" value="%d"></label>', esc_html__( 'الكمية', 'woo-cod-form' ), esc_attr( $id ), (int) $bundle['quantity'] );
            printf( '<label>%s<input type="number" min="0" step="0.01" name="wcf_bundle_offers[%s][price]" value="%s"></label>', esc_html__( 'سعر الباقة الكامل', 'woo-cod-form' ), esc_attr( $id ), esc_attr( (string) $bundle['price'] ) );
            printf( '<label>%s<input type="text" name="wcf_bundle_offers[%s][badge]" value="%s" dir="rtl" placeholder="الأكثر طلباً / وفر 20 د.م"></label>', esc_html__( 'شارة الباقة', 'woo-cod-form' ), esc_attr( $id ), esc_attr( $bundle['badge'] ) );
            printf( '<label class="wcf-bundle-check"><span>%s</span><span class="wcf-toggle mini"><input type="checkbox" name="wcf_bundle_offers[%s][popular]" value="1" %s><span></span></span></label>', esc_html__( 'الأكثر طلباً', 'woo-cod-form' ), esc_attr( $id ), checked( ! empty( $bundle['popular'] ), true, false ) );
            echo '</div>';
        }
        echo '</div><p class="description">' . esc_html__( 'كل سعر هو المجموع النهائي للباقة. سيتم تطبيقه في الطلب من السيرفر وليس JavaScript فقط.', 'woo-cod-form' ) . '</p>';
    }
    public static function field_tracking_purchase_event(): void { self::toggle( 'wcf_tracking_purchase_event', true, __( 'يرسل Lead و COD_Submitted بعد إرسال الطلب بنجاح.', 'woo-cod-form' ) ); }
    public static function field_show_product_image(): void { self::toggle( 'wcf_show_product_image', true ); }
    public static function field_sticky_summary(): void { self::toggle( 'wcf_sticky_summary', false ); }
    public static function field_show_trust_badges(): void { self::toggle( 'wcf_show_trust_badges', true ); }
    public static function field_hide_native_title(): void { self::toggle( 'wcf_hide_native_title', false, __( 'يخفي عنوان WooCommerce الأصلي حتى يظهر فورم COD فقط بشكل أنظف.', 'woo-cod-form' ) ); }
    public static function field_hide_native_price(): void { self::toggle( 'wcf_hide_native_price', false, __( 'يخفي سعر WooCommerce الأصلي لتجنب تكرار السعر بجانب فورم الطلب.', 'woo-cod-form' ) ); }
    public static function field_hide_native_add_to_cart(): void { self::toggle( 'wcf_hide_native_add_to_cart', false, __( 'يخفي الكمية وزر Add to cart الافتراضيين ويترك زر طلب COD فقط.', 'woo-cod-form' ) ); }

    private static function toggle( string $option, bool $default, string $help = '' ): void { $value = (bool) get_option( $option, $default ); printf('<label class="wcf-toggle"><input type="checkbox" id="%1$s" name="%1$s" value="1" %2$s><span></span></label>', esc_attr($option), checked($value, true, false)); if ( $help ) { echo '<p class="description">' . esc_html( $help ) . '</p>'; } }

    public static function field_default_country(): void { $value = (string) get_option( 'wcf_default_country', 'MA' ); $countries = WC()->countries->get_countries(); echo '<select name="wcf_default_country" class="wcf-control">'; foreach ( $countries as $code => $name ) { printf( '<option value="%s" %s>%s</option>', esc_attr( $code ), selected( $code, $value, false ), esc_html( $name ) ); } echo '</select>'; }
    public static function field_currency_code(): void { $value = (string) get_option( 'wcf_currency_code', '' ); $currencies = function_exists( 'get_woocommerce_currencies' ) ? get_woocommerce_currencies() : []; echo '<select name="wcf_currency_code" class="wcf-control">'; printf( '<option value="" %s>%s</option>', selected( '', $value, false ), esc_html__( 'استخدام عملة WooCommerce الافتراضية', 'woo-cod-form' ) ); foreach ( $currencies as $code => $name ) { printf( '<option value="%s" %s>%s — %s</option>', esc_attr( $code ), selected( $code, $value, false ), esc_html( $code ), esc_html( $name ) ); } echo '</select><p class="description">' . esc_html__( 'يغير عملة العرض والطلب بدون تحويل السعر.', 'woo-cod-form' ) . '</p>'; }
    public static function field_max_quantity(): void { printf( '<input type="number" name="wcf_max_quantity" value="%d" min="1" max="999" class="small-text" />', max( 1, (int) get_option( 'wcf_max_quantity', 5 ) ) ); echo '<p class="description">' . esc_html__( 'مثلاً 5 أو 6.', 'woo-cod-form' ) . '</p>'; }
    public static function field_rate_limit(): void { printf( '<input type="number" name="wcf_rate_limit" value="%d" min="1" max="100" class="small-text" />', max( 1, (int) get_option( 'wcf_rate_limit', 5 ) ) ); }
    public static function field_rate_window(): void { printf( '<input type="number" name="wcf_rate_window" value="%d" min="60" max="86400" class="regular-text" /> <span class="description">%s</span>', max( 60, (int) get_option( 'wcf_rate_window', 3600 ) ), esc_html__( 'بالثواني', 'woo-cod-form' ) ); }
    public static function field_duplicate_window(): void { printf( '<input type="number" name="wcf_duplicate_window" value="%d" min="1" max="1440" class="small-text" /> <span class="description">%s</span>', max( 1, (int) get_option( 'wcf_duplicate_window', 30 ) ), esc_html__( 'بالدقائق', 'woo-cod-form' ) ); }

    public static function field_product_extra_fields(): void { $v = (string) get_option( 'wcf_product_extra_fields', '' ); printf( '<textarea name="wcf_product_extra_fields" rows="8" class="large-text code" dir="ltr" placeholder="123|المقاس|select:S,M,L,XL|required&#10;123|اللون|text|optional&#10;456|النكهة|select:Vanilla,Chocolate|required">%s</textarea>', esc_textarea( $v ) ); echo '<p class="description">' . esc_html__( 'كل سطر: product_id|label|type|required. النوع: text أو select:option1,option2.', 'woo-cod-form' ) . '</p>'; }
    public static function field_quantity_discount_rules(): void { $v = (string) get_option( 'wcf_quantity_discount_rules', '' ); printf( '<textarea name="wcf_quantity_discount_rules" rows="6" class="large-text code" dir="ltr" placeholder="2|349|وفر 49 DH&#10;3|499|الأكثر طلباً">%s</textarea>', esc_textarea( $v ) ); echo '<p class="description">' . esc_html__( 'كل سطر: quantity|total_price|badge. السعر هو مجموع الكمية وليس سعر القطعة.', 'woo-cod-form' ) . '</p>'; }
    public static function field_offer_badge_text(): void { printf( '<input type="text" name="wcf_offer_badge_text" value="%s" class="regular-text" dir="rtl" placeholder="الأكثر طلباً" />', esc_attr( (string) get_option( 'wcf_offer_badge_text', 'الأكثر طلباً' ) ) ); }
    public static function field_design_mode(): void { self::select( 'wcf_design_mode', [ 'premium' => 'Premium', 'compact' => 'Compact', 'minimal' => 'Minimal' ], 'premium' ); }
    public static function field_input_size(): void {
        $raw = get_option( 'wcf_input_size', 52 );
        if ( in_array( $raw, [ 'compact', 'normal', 'large' ], true ) ) {
            $raw = 'compact' === $raw ? 44 : ( 'normal' === $raw ? 48 : 56 );
        }
        $value = min( 90, max( 34, absint( $raw ) ) );
        printf(
            '<div class="wcf-px-control" dir="rtl"><input type="number" name="wcf_input_size" value="%1$d" min="34" max="90" step="1" class="small-text" /> <strong>px</strong></div><p class="description">%2$s</p>',
            $value,
            esc_html__( 'اكتب ارتفاع حقول الفورم بالبكسل مباشرة. مثال: 44، 52، 60.', 'woo-cod-form' )
        );
    }
    public static function field_form_width(): void { printf( '<input type="number" name="wcf_form_width" value="%d" min="320" max="1200" class="small-text" /> px', max( 320, (int) get_option( 'wcf_form_width', 720 ) ) ); }
    public static function field_button_color(): void { printf( '<input type="color" name="wcf_button_color" value="%s" />', esc_attr( (string) get_option( 'wcf_button_color', '#111827' ) ) ); }
    public static function field_border_radius(): void { printf( '<input type="number" name="wcf_border_radius" value="%d" min="0" max="40" class="small-text" /> px', max( 0, (int) get_option( 'wcf_border_radius', 18 ) ) ); }
    public static function field_trust_badges_text(): void { $v = (string) get_option( 'wcf_trust_badges_text', "الدفع عند الاستلام\nتوصيل سريع\nضمان الجودة" ); printf( '<textarea name="wcf_trust_badges_text" rows="4" class="large-text" dir="rtl">%s</textarea>', esc_textarea( $v ) ); }
    public static function field_form_template(): void {
        $value = (string) get_option( 'wcf_form_template', 'moroccan' );
        $templates = [
            'moroccan' => [
                'emoji' => '🇲🇦',
                'name'  => __( 'قالب مغربي سريع', 'woo-cod-form' ),
                'tag'   => __( 'الأفضل للطلبات اليومية', 'woo-cod-form' ),
                'desc'  => __( 'اسم، هاتف، مدينة، عنوان وملاحظات. واضح وسريع لزبناء المغرب.', 'woo-cod-form' ),
                'meta'  => __( 'COD · RTL · Mobile', 'woo-cod-form' ),
            ],
            'minimal' => [
                'emoji' => '⚡',
                'name'  => __( 'قالب مختصر', 'woo-cod-form' ),
                'tag'   => __( 'أقل حقول، تحويل أسرع', 'woo-cod-form' ),
                'desc'  => __( 'يركز فقط على الضروري: الاسم، الهاتف، المدينة والعنوان.', 'woo-cod-form' ),
                'meta'  => __( 'Fast checkout', 'woo-cod-form' ),
            ],
            'fashion' => [
                'emoji' => '👗',
                'name'  => __( 'قالب الموضة', 'woo-cod-form' ),
                'tag'   => __( 'للملابس والإكسسوارات', 'woo-cod-form' ),
                'desc'  => __( 'مناسب للمقاس، اللون، الموديل وملاحظات الزبون قبل التأكيد.', 'woo-cod-form' ),
                'meta'  => __( 'Size · Color', 'woo-cod-form' ),
            ],
            'electronics' => [
                'emoji' => '📱',
                'name'  => __( 'قالب الإلكترونيات', 'woo-cod-form' ),
                'tag'   => __( 'للمنتجات التقنية', 'woo-cod-form' ),
                'desc'  => __( 'يدعم البريد والملاحظات الخاصة بالضمان أو نسخة المنتج.', 'woo-cod-form' ),
                'meta'  => __( 'Warranty · Email', 'woo-cod-form' ),
            ],
        ];

        echo '<div class="wcf-template-picker" dir="rtl">';
        echo '<div class="wcf-template-head"><div><strong>' . esc_html__( 'اختيار قالب الفورم', 'woo-cod-form' ) . '</strong><p>' . esc_html__( 'اختر واحداً من 4 قوالب مصممة بشكل مختلف حسب نوع المنتج. عند الحفظ سيتم تحديث حقول الفورم الأساسية.', 'woo-cod-form' ) . '</p></div><span>✨ 4 Templates</span></div>';
        echo '<div class="wcf-template-grid">';

        foreach ( $templates as $key => $template ) {
            $checked = checked( $value, $key, false );
            printf(
                '<label class="wcf-template-card wcf-template-%1$s"><input type="radio" name="wcf_form_template" value="%1$s" %2$s><span class="wcf-template-radio" aria-hidden="true"></span><span class="wcf-template-emoji">%3$s</span><strong>%4$s</strong><em>%5$s</em><span class="wcf-template-desc">%6$s</span><small>%7$s</small></label>',
                esc_attr( $key ),
                $checked,
                esc_html( $template['emoji'] ),
                esc_html( $template['name'] ),
                esc_html( $template['tag'] ),
                esc_html( $template['desc'] ),
                esc_html( $template['meta'] )
            );
        }

        echo '</div></div>';
    }
    private static function select( string $option, array $items, string $default ): void { $value = (string) get_option( $option, $default ); echo '<select name="' . esc_attr( $option ) . '" class="wcf-control">'; foreach ( $items as $k => $label ) { printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $value, $k, false ), esc_html( $label ) ); } echo '</select>'; }

    public static function default_form_fields(): array { return self::template_fields( 'moroccan' ); }
    public static function template_fields( string $template ): array {
        $base = [
            'first_name' => [ 'enabled' => true, 'required' => true, 'label' => 'الاسم الشخصي' ],
            'last_name'  => [ 'enabled' => true, 'required' => false, 'label' => 'الاسم العائلي' ],
            'phone'      => [ 'enabled' => true, 'required' => true, 'label' => 'رقم الهاتف' ],
            'address_1'  => [ 'enabled' => true, 'required' => true, 'label' => 'العنوان' ],
            'address_2'  => [ 'enabled' => false, 'required' => false, 'label' => 'العنوان الإضافي' ],
            'city'       => [ 'enabled' => true, 'required' => true, 'label' => 'المدينة' ],
            'state'      => [ 'enabled' => false, 'required' => false, 'label' => 'الجهة / الولاية' ],
            'postcode'   => [ 'enabled' => false, 'required' => false, 'label' => 'الرمز البريدي' ],
            'email'      => [ 'enabled' => false, 'required' => false, 'label' => 'البريد الإلكتروني' ],
            'notes'      => [ 'enabled' => true, 'required' => false, 'label' => 'ملاحظات الطلب' ],
        ];

        if ( 'minimal' === $template ) {
            $base['last_name']['enabled'] = false;
            $base['address_2']['enabled'] = false;
            $base['notes']['enabled']     = false;
        }

        if ( 'fashion' === $template ) {
            $base['last_name']['enabled'] = false;
            $base['notes']['label']       = 'المقاس / اللون / الموديل';
            $base['notes']['required']    = false;
        }

        if ( 'electronics' === $template ) {
            $base['email']['enabled'] = true;
            $base['notes']['label']   = 'ملاحظات الضمان أو نسخة المنتج';
        }

        return $base;
    }
    public static function get_form_fields(): array { $defaults = self::default_form_fields(); $saved = get_option( 'wcf_form_fields', [] ); if ( ! is_array( $saved ) || empty( $saved ) ) { return $defaults; } foreach ( $defaults as $key => $config ) { if ( isset( $saved[$key] ) && is_array( $saved[$key] ) ) { $defaults[$key] = array_merge( $config, $saved[$key] ); } } return $defaults; }

    public static function field_form_fields(): void { $fields = self::get_form_fields(); $locked = [ 'first_name', 'phone' ]; echo '<div class="wcf-builder-shell" dir="rtl"><div class="wcf-builder-intro"><strong>' . esc_html__( 'منشئ فورم الطلب', 'woo-cod-form' ) . '</strong><span>' . esc_html__( 'غيّر التسميات وحدد الحقول المطلوبة. الاسم ورقم الهاتف مقفلان لأنهما أساسيان.', 'woo-cod-form' ) . '</span></div><div class="wcf-field-cards">'; foreach ( $fields as $key => $config ) { $label = esc_attr( $config['label'] ?? '' ); $enabled = ! empty( $config['enabled'] ); $required = ! empty( $config['required'] ); $is_locked = in_array( $key, $locked, true ); echo '<div class="wcf-field-card"><div class="wcf-field-card-head"><code>' . esc_html( $key ) . '</code>' . ( $is_locked ? '<span class="wcf-required-pill">' . esc_html__( 'مقفل', 'woo-cod-form' ) . '</span>' : '' ) . '</div><label class="wcf-field-label-text">' . esc_html__( 'التسمية', 'woo-cod-form' ) . '</label>'; printf( '<input type="text" name="wcf_form_fields[%1$s][label]" value="%2$s" class="wcf-label-input" dir="rtl" />', esc_attr( $key ), $label ); echo '<div class="wcf-field-switches">'; printf( '<label><span>%s</span><span class="wcf-toggle mini"><input type="checkbox" name="wcf_form_fields[%s][enabled]" value="1" %s %s><span></span></span></label>', esc_html__( 'إظهار', 'woo-cod-form' ), esc_attr($key), checked($enabled, true, false), disabled($is_locked, true, false) ); printf( '<label><span>%s</span><span class="wcf-toggle mini"><input type="checkbox" name="wcf_form_fields[%s][required]" value="1" %s %s><span></span></span></label>', esc_html__( 'إجباري', 'woo-cod-form' ), esc_attr($key), checked($required, true, false), disabled($is_locked, true, false) ); echo '</div>'; if ( $is_locked ) { printf( '<input type="hidden" name="wcf_form_fields[%1$s][enabled]" value="1" /><input type="hidden" name="wcf_form_fields[%1$s][required]" value="1" />', esc_attr( $key ) ); } echo '</div>'; } echo '</div></div>'; }

    public static function field_generic( array $args ): void { $option = $args['option'] ?? ''; printf( '<input type="text" name="%s" value="%s" class="regular-text" dir="auto" />', esc_attr( $option ), esc_attr( (string) get_option( $option, '' ) ) ); }
    public static function field_textarea( array $args ): void { $option = $args['option'] ?? ''; printf( '<textarea name="%s" rows="4" class="large-text" dir="auto">%s</textarea>', esc_attr( $option ), esc_textarea( (string) get_option( $option, '' ) ) ); }
    public static function field_checkbox( array $args ): void { self::toggle( $args['option'] ?? '', false ); }

    public static function default_bundle_offers(): array {
        return [
            'bundle_1' => [ 'title' => '1 قطعة', 'quantity' => 1, 'price' => 43, 'badge' => '', 'popular' => false ],
            'bundle_2' => [ 'title' => '2 قطع', 'quantity' => 2, 'price' => 79, 'badge' => 'الأكثر طلباً', 'popular' => true ],
            'bundle_3' => [ 'title' => '3 قطع', 'quantity' => 3, 'price' => 109, 'badge' => 'وفر 20 د.م', 'popular' => false ],
        ];
    }

    public static function get_bundle_offers( bool $include_disabled = false ): array {
        $defaults = self::default_bundle_offers();
        $saved = get_option( 'wcf_bundle_offers', [] );
        if ( is_array( $saved ) ) {
            foreach ( $defaults as $id => $bundle ) {
                if ( isset( $saved[ $id ] ) && is_array( $saved[ $id ] ) ) {
                    $defaults[ $id ] = array_merge( $bundle, $saved[ $id ] );
                }
            }
        }
        foreach ( $defaults as $id => $bundle ) {
            $defaults[ $id ]['id']       = $id;
            $defaults[ $id ]['title']    = sanitize_text_field( (string) ( $bundle['title'] ?? '' ) );
            $defaults[ $id ]['quantity'] = max( 1, absint( $bundle['quantity'] ?? 1 ) );
            $defaults[ $id ]['price']    = max( 0, (float) ( $bundle['price'] ?? 0 ) );
            $defaults[ $id ]['badge']    = sanitize_text_field( (string) ( $bundle['badge'] ?? '' ) );
            $defaults[ $id ]['popular']  = ! empty( $bundle['popular'] );
        }
        return $defaults;
    }

    public static function get_bundle_offer( string $id ): ?array {
        $bundles = self::get_bundle_offers();
        return $bundles[ $id ] ?? null;
    }

    public static function parse_quantity_rules(): array { $lines = preg_split( '/\R/', (string) get_option( 'wcf_quantity_discount_rules', '' ) ); $out = []; foreach ( $lines as $line ) { $parts = array_map( 'trim', explode( '|', $line ) ); if ( count( $parts ) >= 2 && absint( $parts[0] ) > 0 && is_numeric( $parts[1] ) ) { $out[] = [ 'qty' => absint( $parts[0] ), 'total' => (float) $parts[1], 'badge' => sanitize_text_field( $parts[2] ?? '' ) ]; } } usort( $out, fn($a,$b) => $a['qty'] <=> $b['qty'] ); return $out; }
    public static function get_product_extra_fields( int $product_id ): array { if ( ! (bool) get_option( 'wcf_product_overrides_enabled', false ) ) { return []; } $lines = preg_split( '/\R/', (string) get_option( 'wcf_product_extra_fields', '' ) ); $fields = []; foreach ( $lines as $line ) { $parts = array_map( 'trim', explode( '|', $line ) ); if ( count( $parts ) < 3 || absint( $parts[0] ) !== $product_id ) { continue; } $label = sanitize_text_field( $parts[1] ); $type = sanitize_text_field( $parts[2] ); $required = isset( $parts[3] ) && 'required' === strtolower( $parts[3] ); $fields[] = [ 'key' => sanitize_title( $label ), 'label' => $label, 'type' => $type, 'required' => $required ]; } return $fields; }

    public static function sanitize_bundle_offers( mixed $value ): array {
        $defaults = self::default_bundle_offers();
        $clean = [];
        if ( ! is_array( $value ) ) {
            return $defaults;
        }
        foreach ( $defaults as $id => $default ) {
            $row = isset( $value[ $id ] ) && is_array( $value[ $id ] ) ? $value[ $id ] : [];
            $clean[ $id ] = [
                'title'    => sanitize_text_field( $row['title'] ?? $default['title'] ),
                'quantity' => max( 1, min( 999, absint( $row['quantity'] ?? $default['quantity'] ) ) ),
                'price'    => max( 0, (float) wc_format_decimal( $row['price'] ?? $default['price'], wc_get_price_decimals() ) ),
                'badge'    => sanitize_text_field( $row['badge'] ?? '' ),
                'popular'  => ! empty( $row['popular'] ),
            ];
        }
        return $clean;
    }

    public static function sanitize_default_bundle( mixed $value ): string {
        $key = sanitize_key( (string) $value );
        return array_key_exists( $key, self::default_bundle_offers() ) ? $key : 'bundle_1';
    }

    public static function sanitize_bool( mixed $value ): bool { return (bool) $value; }
    public static function sanitize_order_status( mixed $value ): string { $slug = sanitize_key( (string) $value ); return in_array( $slug, array_keys( wc_get_order_statuses() ), true ) ? $slug : 'wc-pending'; }
    public static function sanitize_country( mixed $value ): string { $upper = strtoupper( sanitize_text_field( (string) $value ) ); return preg_match( '/^[A-Z]{2}$/', $upper ) ? $upper : 'MA'; }
    public static function sanitize_currency( mixed $value ): string { $code = strtoupper( sanitize_text_field( (string) $value ) ); if ( '' === $code ) { return ''; } $currencies = function_exists( 'get_woocommerce_currencies' ) ? get_woocommerce_currencies() : []; return isset( $currencies[$code] ) ? $code : ''; }
    public static function sanitize_max_quantity( mixed $value ): int { return min( 999, max( 1, absint( $value ) ) ); }
    public static function sanitize_rate_limit( mixed $value ): int { return min( 100, max( 1, absint( $value ) ) ); }
    public static function sanitize_rate_window( mixed $value ): int { return min( 86400, max( 60, absint( $value ) ) ); }
    public static function sanitize_duplicate_window( mixed $value ): int { return min( 1440, max( 1, absint( $value ) ) ); }
    public static function sanitize_textarea_lines( mixed $value ): string { return implode( "\n", array_filter( array_map( 'sanitize_text_field', preg_split( '/\R/', (string) $value ) ) ) ); }
    public static function sanitize_design_mode( mixed $value ): string { return in_array( $value, [ 'premium', 'compact', 'minimal' ], true ) ? $value : 'premium'; }
    public static function sanitize_input_size( mixed $value ): int {
        if ( in_array( $value, [ 'compact', 'normal', 'large' ], true ) ) {
            return 'compact' === $value ? 44 : ( 'normal' === $value ? 48 : 56 );
        }
        return min( 90, max( 34, absint( $value ) ) );
    }
    public static function sanitize_width( mixed $value ): int { return min( 1200, max( 320, absint( $value ) ) ); }
    public static function sanitize_radius( mixed $value ): int { return min( 40, max( 0, absint( $value ) ) ); }
    public static function sanitize_color( mixed $value ): string { $value = sanitize_hex_color( (string) $value ); return $value ?: '#111827'; }
    public static function sanitize_form_template( mixed $value ): string { $template = sanitize_key( (string) $value ); if ( ! in_array( $template, [ 'moroccan', 'minimal', 'fashion', 'electronics' ], true ) ) { $template = 'moroccan'; } update_option( 'wcf_form_fields', self::template_fields( $template ), false ); return $template; }
    public static function sanitize_form_fields( mixed $value ): array { $defaults = self::default_form_fields(); if ( ! is_array( $value ) ) { return $defaults; } $clean = []; foreach ( $defaults as $key => $default ) { $config = isset( $value[$key] ) && is_array( $value[$key] ) ? $value[$key] : []; $locked = in_array( $key, [ 'first_name', 'phone' ], true ); $clean[$key] = [ 'enabled' => $locked ? true : ! empty( $config['enabled'] ), 'label' => sanitize_text_field( $config['label'] ?? $default['label'] ), 'required' => $locked ? true : ! empty( $config['required'] ) ]; } return $clean; }
}
