<?php
/**
 * File: modules/admin/class-admin-panel.php
 *
 * Registers the plugin's admin menu, settings pages, and tab navigation.
 * Delegates actual settings registration to Settings_Manager.
 * Delegates analytics output to Analytics_Dashboard.
 *
 * Menu location: WooCommerce → COD Form
 * Capability:    manage_woocommerce
 */

namespace WCF\Modules\Admin;

defined( 'ABSPATH' ) || exit;

final class Admin_Panel {

    /** Slug used for all plugin admin pages. */
    public const MENU_SLUG = 'wcf-settings';

    /** Available tab slugs and their labels. */
    private const TABS = [
        'general'    => 'الإعدادات العامة',
        'form'       => 'منشئ الفورم',
        'product'    => 'حسب المنتج',
        'offers'     => 'العروض والباقات',
        'design'     => 'التصميم',
        'tracking'   => 'Pixels',
        'templates'  => 'القوالب',
        'export'     => 'تصدير الطلبات',
        'conversion' => 'تحسين التحويل',
        'notify'     => 'الإشعارات',
        'analytics'  => 'الإحصائيات',
    ];

    // -----------------------------------------------------------------------
    // Boot
    // -----------------------------------------------------------------------

    /**
     * Hook into WordPress admin lifecycle.
     * Called once from Plugin::boot() — admin_init guard is applied here.
     */
    public static function init(): void {
        if ( ! is_admin() ) {
            return;
        }

        add_action( 'admin_menu',  [ self::class, 'register_menu' ] );
        add_action( 'admin_init',  [ Settings_Manager::class, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_assets' ] );
        add_action( 'admin_post_wcf_export_orders', [ self::class, 'export_orders_csv' ] );

        // Plugin action links (Settings shortcut on Plugins page).
        add_filter(
            'plugin_action_links_' . WCF_BASENAME,
            [ self::class, 'add_action_links' ]
        );
    }

    // -----------------------------------------------------------------------
    // Menu registration
    // -----------------------------------------------------------------------

    /**
     * Add plugin pages under the WooCommerce menu.
     */
    public static function register_menu(): void {
        add_submenu_page(
            'woocommerce',                                     // Parent slug.
            __( 'إعدادات نموذج الدفع عند الاستلام', 'woo-cod-form' ),         // Page <title>.
            __( 'نموذج COD', 'woo-cod-form' ),                  // Menu label.
            'manage_woocommerce',                              // Required capability.
            self::MENU_SLUG,                                   // Menu slug.
            [ self::class, 'render_page' ]                     // Render callback.
        );
    }

    // -----------------------------------------------------------------------
    // Page renderer
    // -----------------------------------------------------------------------

    /**
     * Output the tabbed settings page.
     */
    public static function render_page(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'woo-cod-form' ) );
        }

        $current_tab = self::current_tab();

        ?>
        <div class="wrap wcf-admin-wrap" dir="rtl">
            <div class="wcf-admin-hero">
                <div>
                    <span class="wcf-admin-kicker">WooCommerce COD</span>
                    <h1><?php esc_html_e( 'نموذج الدفع عند الاستلام', 'woo-cod-form' ); ?></h1>
                    <p><?php esc_html_e( 'إدارة الفورم، الحماية، التصميم، العروض، والتحليلات من لوحة عربية منظمة.', 'woo-cod-form' ); ?></p>
                </div>
                <div class="wcf-admin-hero-badge">
                    <span>✓</span>
                    <?php esc_html_e( 'جاهز للمتاجر المغربية', 'woo-cod-form' ); ?>
                </div>
            </div>

            <nav class="nav-tab-wrapper woo-nav-tab-wrapper">
                <?php foreach ( self::TABS as $slug => $label ) : ?>
                    <a href="<?php echo esc_url( self::tab_url( $slug ) ); ?>"
                       class="nav-tab <?php echo $slug === $current_tab ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html( __( $label, 'woo-cod-form' ) ); // phpcs:ignore ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <div class="wcf-tab-content">
                <?php
                if ( 'analytics' === $current_tab ) {
                    Analytics_Dashboard::render();
                } elseif ( 'export' === $current_tab ) {
                    self::render_export_tab();
                } else {
                    self::render_settings_tab( $current_tab );
                }
                ?>
            </div>
        </div>
        <?php
    }

    // -----------------------------------------------------------------------
    // Settings tab renderer
    // -----------------------------------------------------------------------

    /**
     * Wrap Settings_Manager fields in a standard WP settings form.
     *
     * @param string $tab  Active tab slug.
     */
    private static function render_settings_tab( string $tab ): void {
        $view = WCF_PATH . 'admin/views/settings-' . $tab . '.php';

        if ( ! file_exists( $view ) ) {
            echo '<p>' . esc_html__( 'Settings view not found.', 'woo-cod-form' ) . '</p>';
            return;
        }

        ?>
        <form method="post" action="options.php">
            <?php
            settings_fields( 'wcf_settings_' . $tab );
            include $view;
            submit_button( __( 'حفظ التغييرات', 'woo-cod-form' ), 'primary', 'submit', true );
            ?>
        </form>
        <?php
    }


    private static function render_export_tab(): void {
        $url = wp_nonce_url( admin_url( 'admin-post.php?action=wcf_export_orders' ), 'wcf_export_orders' );
        ?>
        <div class="wcf-export-panel" dir="rtl">
            <h2><?php esc_html_e( 'تصدير طلبات COD', 'woo-cod-form' ); ?></h2>
            <p><?php esc_html_e( 'حمّل ملف CSV يحتوي على الطلبات التي تم إنشاؤها عبر الفورم: الاسم، الهاتف، المدينة، المنتج، الكمية، المجموع، الحالة، والتاريخ.', 'woo-cod-form' ); ?></p>
            <a class="button button-primary button-hero" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'تصدير CSV', 'woo-cod-form' ); ?></a>
            <p class="description"><?php esc_html_e( 'يمكن فتح الملف في Excel أو Google Sheets.', 'woo-cod-form' ); ?></p>
        </div>
        <?php
    }

    public static function export_orders_csv(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) || ! check_admin_referer( 'wcf_export_orders' ) ) {
            wp_die( esc_html__( 'ليست لديك صلاحية تنفيذ هذا الإجراء.', 'woo-cod-form' ) );
        }

        $orders = wc_get_orders( [
            'limit'      => -1,
            'return'     => 'objects',
            'meta_query' => [ // phpcs:ignore WordPress.DB.SlowDBQuery
                'relation' => 'OR',
                [ 'key' => '_wcf_source', 'value' => 'cod_form', 'compare' => '=' ],
                [ 'key' => '_created_via', 'value' => 'woo-cod-form', 'compare' => '=' ],
            ],
        ] );

        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=wcf-orders-' . gmdate( 'Y-m-d' ) . '.csv' );
        $out = fopen( 'php://output', 'w' );
        fputcsv( $out, [ 'Order ID', 'Date', 'Status', 'Name', 'Phone', 'City', 'Product', 'Quantity', 'Total', 'Currency', 'Notes' ] );
        foreach ( $orders as $order ) {
            if ( ! $order instanceof \WC_Order ) { continue; }
            $products = [];
            $qty = 0;
            foreach ( $order->get_items() as $item ) {
                $products[] = $item->get_name();
                $qty += (int) $item->get_quantity();
            }
            fputcsv( $out, [
                $order->get_id(),
                $order->get_date_created() ? $order->get_date_created()->date_i18n( 'Y-m-d H:i' ) : '',
                $order->get_status(),
                trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
                $order->get_billing_phone(),
                $order->get_billing_city(),
                implode( ' / ', $products ),
                $qty,
                $order->get_total(),
                $order->get_currency(),
                $order->get_customer_note(),
            ] );
        }
        fclose( $out );
        exit;
    }

    // -----------------------------------------------------------------------
    // Asset loading
    // -----------------------------------------------------------------------

    /**
     * Load admin CSS/JS only on plugin pages.
     *
     * @param string $hook  Current admin page hook suffix.
     */
    public static function enqueue_assets( string $hook ): void {
        if ( false === strpos( $hook, self::MENU_SLUG ) ) {
            return;
        }

        wp_enqueue_style(
            'wcf-cairo-font',
            'https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'wcf-admin',
            WCF_URL . 'admin/css/admin-panel.css',
            [],
            WCF_VERSION
        );

        wp_enqueue_script(
            'wcf-admin',
            WCF_URL . 'admin/js/admin-panel.js',
            [ 'jquery' ],
            WCF_VERSION,
            true
        );
    }

    // -----------------------------------------------------------------------
    // Plugin action links
    // -----------------------------------------------------------------------

    /**
     * Add a "Settings" link to the plugin row on the Plugins page.
     *
     * @param  array $links  Existing plugin action links.
     * @return array
     */
    public static function add_action_links( array $links ): array {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG ) ),
            esc_html__( 'الإعدادات', 'woo-cod-form' )
        );

        array_unshift( $links, $settings_link );

        return $links;
    }

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /**
     * Return the slug of the currently active tab.
     * Defaults to 'general' when no tab is specified or tab is invalid.
     */
    private static function current_tab(): string {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $tab = sanitize_key( $_GET['tab'] ?? 'general' );

        return array_key_exists( $tab, self::TABS ) ? $tab : 'general';
    }

    /**
     * Build a URL for a specific settings tab.
     *
     * @param  string $tab  Tab slug.
     * @return string
     */
    private static function tab_url( string $tab ): string {
        return admin_url(
            add_query_arg(
                [ 'page' => self::MENU_SLUG, 'tab' => $tab ],
                'admin.php'
            )
        );
    }
}
