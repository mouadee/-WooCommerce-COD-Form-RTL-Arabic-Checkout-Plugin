<?php
/**
 * File: modules/admin/class-analytics-dashboard.php
 */

namespace WCF\Modules\Admin;

defined( 'ABSPATH' ) || exit;

final class Analytics_Dashboard {

    public static function render(): void {
        $stats = self::get_stats();
        ?>
        <div class="wcf-analytics" dir="rtl">
            <div class="wcf-analytics-head"><div><h2><?php esc_html_e( 'لوحة تحليلات COD', 'woo-cod-form' ); ?></h2><p><?php esc_html_e( 'أرقام عملية للطلبات التي تم إنشاؤها عبر الفورم فقط.', 'woo-cod-form' ); ?></p></div></div>

            <div class="wcf-stats-grid wcf-stats-grid-wide">
                <?php self::card( 'إجمالي الطلبات', number_format_i18n( $stats['total'] ) ); ?>
                <?php self::card( 'طلبات اليوم', number_format_i18n( $stats['today'] ) ); ?>
                <?php self::card( 'طلبات آخر 30 يوماً', number_format_i18n( $stats['last_30_days'] ) ); ?>
                <?php self::card( 'طلبات قيد الانتظار', number_format_i18n( $stats['pending'] ) ); ?>
                <?php self::card( 'طلبات مكتملة', number_format_i18n( $stats['completed'] ) ); ?>
                <?php self::card( 'طلبات ملغاة', number_format_i18n( $stats['cancelled'] ) ); ?>
                <?php self::card( 'الأرباح المكتملة', wc_price( $stats['revenue'], [ 'currency' => self::selected_currency() ] ), true ); ?>
                <?php self::card( 'متوسط الطلب', wc_price( $stats['avg_order'], [ 'currency' => self::selected_currency() ] ), true ); ?>
            </div>

            <div class="wcf-analytics-grid">
                <?php self::table( 'الطلبات حسب الحالة', [ 'الحالة', 'العدد' ], $stats['by_status'] ); ?>
                <?php self::table( 'أفضل المنتجات', [ 'المنتج', 'الكمية' ], $stats['top_products'] ); ?>
                <?php self::table( 'الطلبات حسب المدينة', [ 'المدينة', 'العدد' ], $stats['by_city'] ); ?>
                <?php self::table( 'آخر الطلبات', [ 'الطلب', 'المعلومات' ], $stats['recent_orders'] ); ?>
            </div>

            <p class="description"><?php esc_html_e( 'المصدر: WooCommerce Orders API. الطلبات القديمة التي لا تحتوي على وسم المصدر قد لا تظهر هنا.', 'woo-cod-form' ); ?></p>
        </div>
        <?php
    }

    private static function card( string $label, string $value, bool $html = false ): void {
        echo '<div class="wcf-stat-box"><span class="wcf-stat-value">';
        echo $html ? wp_kses_post( $value ) : esc_html( $value );
        echo '</span><span class="wcf-stat-label">' . esc_html( $label ) . '</span></div>';
    }

    private static function table( string $title, array $heads, array $rows ): void {
        echo '<div class="wcf-analytics-card"><h3>' . esc_html( $title ) . '</h3><table class="widefat fixed striped"><thead><tr>';
        foreach ( $heads as $head ) { echo '<th>' . esc_html( $head ) . '</th>'; }
        echo '</tr></thead><tbody>';
        if ( empty( $rows ) ) { echo '<tr><td colspan="2">' . esc_html__( 'لا توجد بيانات بعد.', 'woo-cod-form' ) . '</td></tr>'; }
        foreach ( $rows as $key => $value ) {
            echo '<tr><td>' . esc_html( (string) $key ) . '</td><td>' . esc_html( (string) $value ) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    private static function selected_currency(): string {
        $currency = (string) get_option( 'wcf_currency_code', '' );
        return '' !== $currency ? $currency : get_woocommerce_currency();
    }

    private static function get_stats(): array {
        $statuses = wc_get_order_statuses();
        $wc_statuses = array_keys( $statuses );
        $by_status = [];
        $total = 0;
        foreach ( $wc_statuses as $slug ) {
            $count = self::count_orders( [ 'status' => $slug ] );
            if ( $count > 0 ) { $by_status[ $statuses[$slug] ?? $slug ] = $count; $total += $count; }
        }

        $today_start = gmdate( 'Y-m-d 00:00:00' );
        $thirty_days_ago = gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
        $today = self::count_orders( [ 'status' => $wc_statuses, 'date_after' => $today_start ] );
        $last_30_days = self::count_orders( [ 'status' => $wc_statuses, 'date_after' => $thirty_days_ago ] );
        $pending = self::count_orders( [ 'status' => [ 'wc-pending', 'pending', 'wc-on-hold', 'on-hold' ] ] );
        $completed = self::count_orders( [ 'status' => [ 'wc-completed', 'completed' ] ] );
        $cancelled = self::count_orders( [ 'status' => [ 'wc-cancelled', 'cancelled', 'wc-failed', 'failed' ] ] );
        $revenue = self::sum_revenue();
        $avg_order = $completed > 0 ? $revenue / $completed : 0;
        $orders = self::all_orders();
        $top_products = self::top_products( $orders );
        $by_city = self::by_city( $orders );
        $recent_orders = self::recent_orders( $orders );
        return compact( 'total', 'today', 'last_30_days', 'pending', 'completed', 'cancelled', 'revenue', 'avg_order', 'by_status', 'top_products', 'by_city', 'recent_orders' );
    }

    private static function count_orders( array $args ): int {
        $orders = wc_get_orders( array_merge( [ 'limit' => -1, 'return' => 'ids', 'meta_query' => self::source_meta_query() ], $args ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
        return is_array( $orders ) ? count( array_unique( array_map( 'absint', $orders ) ) ) : 0;
    }

    private static function all_orders(): array { return wc_get_orders( [ 'limit' => 200, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'objects', 'meta_query' => self::source_meta_query() ] ); } // phpcs:ignore WordPress.DB.SlowDBQuery

    private static function sum_revenue(): float {
        $orders = wc_get_orders( [ 'limit' => -1, 'status' => [ 'wc-completed', 'completed' ], 'return' => 'objects', 'meta_query' => self::source_meta_query() ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
        $total = 0.0; foreach ( $orders as $order ) { if ( $order instanceof \WC_Order ) { $total += (float) $order->get_total(); } } return $total;
    }

    private static function top_products( array $orders ): array { $out = []; foreach ( $orders as $order ) { if ( ! $order instanceof \WC_Order ) { continue; } foreach ( $order->get_items() as $item ) { $out[ $item->get_name() ] = ( $out[ $item->get_name() ] ?? 0 ) + (int) $item->get_quantity(); } } arsort( $out ); return array_slice( $out, 0, 8, true ); }
    private static function by_city( array $orders ): array { $out = []; foreach ( $orders as $order ) { if ( ! $order instanceof \WC_Order ) { continue; } $city = trim( $order->get_billing_city() ) ?: 'غير محدد'; $out[$city] = ( $out[$city] ?? 0 ) + 1; } arsort( $out ); return array_slice( $out, 0, 8, true ); }
    private static function recent_orders( array $orders ): array { $out = []; foreach ( array_slice( $orders, 0, 8 ) as $order ) { if ( ! $order instanceof \WC_Order ) { continue; } $out[ '#' . $order->get_id() ] = trim( $order->get_billing_first_name() . ' — ' . $order->get_billing_phone() . ' — ' . wc_price( $order->get_total(), [ 'currency' => $order->get_currency() ] ) ); } return $out; }
    private static function source_meta_query(): array { return [ 'relation' => 'OR', [ 'key' => '_wcf_source', 'value' => 'cod_form', 'compare' => '=' ], [ 'key' => '_created_via', 'value' => 'woo-cod-form', 'compare' => '=' ] ]; }
}
