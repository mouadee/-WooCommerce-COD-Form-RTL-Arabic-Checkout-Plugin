<?php
/**
 * File: modules/conversion/class-conversion-hooks.php
 *
 * Registers all frontend conversion element hooks.
 *
 * Attaches trust badges, countdown timer, and social proof to the
 * wcf_before_form / wcf_after_form action hooks that fire inside
 * the form template.
 *
 * Each element checks its own option before rendering — no output
 * is produced when a feature is disabled.
 */

namespace WCF\Modules\Conversion;

use WCF\Modules\Form\Form_Renderer;

defined( 'ABSPATH' ) || exit;

final class Conversion_Hooks {

    // -----------------------------------------------------------------------
    // Boot
    // -----------------------------------------------------------------------

    /**
     * Register all hooks.
     * Called once from Plugin::boot().
     */
    public static function init(): void {
        // Trust badges — rendered above the form.
        add_action( 'wcf_before_form', [ self::class, 'render_trust_badges' ], 10, 2 );

        // Countdown timer — rendered above the form, after badges.
        add_action( 'wcf_before_form', [ self::class, 'render_countdown_timer' ], 20, 2 );

        // Social proof — rendered above the form, last.
        add_action( 'wcf_before_form', [ self::class, 'render_social_proof' ], 30, 2 );

        // Order confirmation template — rendered inside the form wrap, hidden.
        add_action( 'wcf_after_form', [ self::class, 'render_confirmation_block' ], 10, 2 );
    }

    // -----------------------------------------------------------------------
    // Render callbacks
    // -----------------------------------------------------------------------

    /**
     * Render trust badges strip.
     *
     * @param int   $product_id    Active product ID.
     * @param array $product_data  Product data array.
     */
    public static function render_trust_badges( int $product_id, array $product_data ): void {
        if ( ! get_option( 'wcf_badges_enabled', false ) ) {
            return;
        }

        echo Form_Renderer::get_template_html( 'trust-badges.php', [
            'product_id'   => $product_id,
            'product_data' => $product_data,
        ] );
    }

    /**
     * Render the countdown timer HTML container.
     * The JS bundle handles the actual countdown logic and visibility.
     *
     * @param int   $product_id
     * @param array $product_data
     */
    public static function render_countdown_timer( int $product_id, array $product_data ): void {
        if ( ! get_option( 'wcf_timer_enabled', false ) ) {
            return;
        }

        $minutes = max( 1, (int) get_option( 'wcf_timer_minutes', 15 ) );
        $message = sanitize_text_field(
            (string) get_option( 'wcf_timer_message', __( 'Offer expires in:', 'woo-cod-form' ) )
        );
        ?>
        <div class="wcf-countdown-wrap"
             data-minutes="<?php echo esc_attr( $minutes ); ?>"
             aria-live="polite">
            <span class="wcf-countdown-message"><?php echo esc_html( $message ); ?></span>
            <span class="wcf-countdown-display" id="wcf-timer">
                <span class="wcf-timer-mins">--</span>:<span class="wcf-timer-secs">--</span>
            </span>
        </div>
        <?php
    }

    /**
     * Render social proof notification container.
     * Populated and cycled by the JS bundle.
     *
     * @param int   $product_id
     * @param array $product_data
     */
    public static function render_social_proof( int $product_id, array $product_data ): void {
        if ( ! get_option( 'wcf_social_enabled', false ) ) {
            return;
        }

        $template = sanitize_text_field(
            (string) get_option(
                'wcf_social_message',
                /* translators: placeholder used in social proof template string */
                __( '{name} from {city} just ordered!', 'woo-cod-form' )
            )
        );

        /**
         * Filter: wcf_social_proof_names
         * Allow developers to supply real or randomised name/city pairs.
         *
         * @param array $names  Array of ['name' => string, 'city' => string].
         */
        $names = apply_filters( 'wcf_social_proof_names', [
            [ 'name' => 'Ahmed',   'city' => 'Casablanca' ],
            [ 'name' => 'Fatima',  'city' => 'Marrakech'  ],
            [ 'name' => 'Youssef', 'city' => 'Rabat'      ],
            [ 'name' => 'Salma',   'city' => 'Agadir'     ],
            [ 'name' => 'Karim',   'city' => 'Fès'        ],
        ] );
        ?>
        <div class="wcf-social-proof"
             aria-live="polite"
             data-template="<?php echo esc_attr( $template ); ?>"
             data-names="<?php echo esc_attr( (string) wp_json_encode( $names ) ); ?>">
            <span class="wcf-social-icon" aria-hidden="true">&#128105;</span>
            <span class="wcf-social-text"></span>
        </div>
        <?php
    }

    /**
     * Render the hidden confirmation block — revealed by JS after success.
     *
     * @param int   $product_id
     * @param array $product_data
     */
    public static function render_confirmation_block( int $product_id, array $product_data ): void {
        echo Form_Renderer::get_template_html( 'order-confirmation.php', [
            'product_id'   => $product_id,
            'product_data' => $product_data,
        ] );
    }
}
