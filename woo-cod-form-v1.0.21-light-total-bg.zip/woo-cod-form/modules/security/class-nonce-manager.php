<?php
/**
 * File: modules/security/class-nonce-manager.php
 *
 * Centralises all nonce operations for the plugin.
 *
 * A single action string ('wcf_form_action') is used for all form requests.
 * This is intentional: it keeps the nonce API surface small and ensures
 * every AJAX request goes through the same verification path.
 *
 * Usage:
 *   // In template (render phase):
 *   $nonce_value = Nonce_Manager::create();
 *
 *   // In AJAX handler (request phase):
 *   if ( ! Nonce_Manager::verify() ) { wp_die(); }
 */

namespace WCF\Modules\Security;

defined( 'ABSPATH' ) || exit;

final class Nonce_Manager {

    /** Action string shared across creation and verification. */
    private const ACTION = 'wcf_form_action';

    /** POST / GET field name that carries the nonce value. */
    public const FIELD = 'wcf_nonce';

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Generate and return a nonce value for embedding in the form.
     *
     * @return string  Raw nonce string.
     */
    public static function create(): string {
        return wp_create_nonce( self::ACTION );
    }

    /**
     * Output a hidden <input> field containing the nonce.
     * Safe to call inside template files.
     */
    public static function field(): void {
        wp_nonce_field( self::ACTION, self::FIELD );
    }

    /**
     * Verify the nonce from the current request.
     *
     * Checks both POST and GET superglobals (POST takes priority).
     * Does NOT die on failure — callers decide the response.
     *
     * @return bool  True when the nonce is valid.
     */
    public static function verify(): bool {
        $nonce = '';

        if ( isset( $_POST[ self::FIELD ] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            $nonce = sanitize_text_field( wp_unslash( $_POST[ self::FIELD ] ) );
        } elseif ( isset( $_GET[ self::FIELD ] ) ) {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $nonce = sanitize_text_field( wp_unslash( $_GET[ self::FIELD ] ) );
        }

        if ( '' === $nonce ) {
            return false;
        }

        return (bool) wp_verify_nonce( $nonce, self::ACTION );
    }
}
