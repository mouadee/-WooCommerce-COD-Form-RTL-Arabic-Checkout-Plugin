<?php
/**
 * File: modules/security/class-rate-limiter.php
 *
 * IP-based rate limiting for COD form submissions.
 *
 * Storage: WordPress transients (no custom tables required).
 * Transient key: wcf_rl_{hashed_ip}
 *
 * Config (stored in wp_options, set by Activator::set_defaults()):
 *   wcf_rate_limit   — max allowed submissions per window (default: 5)
 *   wcf_rate_window  — window duration in seconds        (default: 3600)
 *
 * Security note:
 *   The IP is hashed (SHA-256 + site salt) before being used as a cache key.
 *   This means raw IPs are never stored in the database.
 */

namespace WCF\Modules\Security;

defined( 'ABSPATH' ) || exit;

final class Rate_Limiter {

    /** Transient key prefix. */
    private const PREFIX = 'wcf_rl_';

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Check whether the current IP is within the allowed submission rate.
     *
     * Increments the counter on each call.
     * Returns false when the limit is exceeded (caller should block the request).
     *
     * @return bool  True = allowed, False = blocked.
     */
    public static function allow(): bool {
        $limit  = max( 1, (int) get_option( 'wcf_rate_limit', 5 ) );
        $window = max( 60, (int) get_option( 'wcf_rate_window', 3600 ) );
        $key    = self::transient_key();

        $current = (int) get_transient( $key );

        if ( $current >= $limit ) {
            return false;
        }

        if ( 0 === $current ) {
            // First hit — create the transient with the configured TTL.
            set_transient( $key, 1, $window );
        } else {
            // Increment while preserving the original expiry.
            // get_option/_transient_timeout gives us the remaining TTL.
            $remaining_ttl = self::remaining_ttl( $key, $window );
            set_transient( $key, $current + 1, $remaining_ttl );
        }

        return true;
    }

    /**
     * Return the current submission count for the requesting IP.
     * Useful for admin diagnostics / testing.
     *
     * @return int
     */
    public static function current_count(): int {
        return (int) get_transient( self::transient_key() );
    }

    /**
     * Manually reset the counter for the requesting IP.
     * Can be used by admin tools or test helpers.
     */
    public static function reset(): void {
        delete_transient( self::transient_key() );
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Build a hashed, salted transient key for the current client IP.
     *
     * @return string  e.g. "wcf_rl_a3f9..."  (max 172 chars, well within WP limit).
     */
    private static function transient_key(): string {
        $ip   = self::client_ip();
        $salt = (string) wp_salt( 'auth' );
        $hash = hash( 'sha256', $salt . $ip );

        return self::PREFIX . $hash;
    }

    /**
     * Return the approximate remaining TTL for an existing transient.
     *
     * WordPress stores the expiry timestamp in _transient_timeout_{key}.
     * We read it directly to avoid resetting the window on every submission.
     *
     * Falls back to the full window if the timeout row is missing.
     *
     * @param  string  $key           Transient key (without _transient_ prefix).
     * @param  int     $default_ttl   Window in seconds (fallback).
     * @return int                    Seconds until expiry (minimum 1).
     */
    private static function remaining_ttl( string $key, int $default_ttl ): int {
        global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $expires = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT option_value
                   FROM {$wpdb->options}
                  WHERE option_name = %s
                  LIMIT 1",
                '_transient_timeout_' . $key
            )
        );

        if ( null === $expires ) {
            return $default_ttl;
        }

        $remaining = (int) $expires - time();

        return max( 1, $remaining );
    }

    /**
     * Return the best available client IP address.
     * Supports Cloudflare, standard reverse proxies, and direct connections.
     *
     * @return string  Raw IP string (not sanitized for storage — hashed instead).
     */
    private static function client_ip(): string {
        if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
            return trim( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
        }

        if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $ips = explode( ',', wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
            return trim( $ips[0] );
        }

        return trim( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' ) );
    }
}
