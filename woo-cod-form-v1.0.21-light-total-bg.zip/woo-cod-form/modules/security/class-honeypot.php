<?php
/**
 * File: modules/security/class-honeypot.php
 *
 * Honeypot spam protection for the COD order form.
 *
 * Strategy:
 *   A hidden input field (wcf_hp_field) is rendered in the form.
 *   Legitimate users never see or fill it (CSS hides it + tabindex=-1).
 *   Bots that blindly fill all inputs will populate it, failing the check.
 *
 * Important UX rule:
 *   When a honeypot is triggered, return a FAKE success response.
 *   Never reveal to the bot that it was caught — this prevents them
 *   from adapting their strategy.
 *
 * Config:
 *   wcf_enable_honeypot (bool, default: true) — can be toggled in admin.
 */

namespace WCF\Modules\Security;

defined( 'ABSPATH' ) || exit;

final class Honeypot {

    /** The POST field name for the honeypot input. */
    public const FIELD = 'wcf_hp_field';

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    /**
     * Check whether the current submission passes the honeypot test.
     *
     * @return bool  True = legitimate submission, False = suspected bot.
     */
    public static function passes(): bool {
        // Feature disabled — always pass.
        if ( ! self::is_enabled() ) {
            return true;
        }

        // The honeypot field must be present in the request (form was submitted normally).
        if ( ! isset( $_POST[ self::FIELD ] ) ) {
            return false;
        }

        // The field must be completely empty.
        $value = sanitize_text_field( wp_unslash( $_POST[ self::FIELD ] ) );

        return '' === $value;
    }

    /**
     * Output the hidden honeypot input field.
     * Call this from within the COD form template.
     *
     * The field is visually hidden via inline style AND positioned off-screen.
     * This dual approach catches bots that strip CSS.
     */
    public static function render_field(): void {
        if ( ! self::is_enabled() ) {
            return;
        }

        printf(
            '<div aria-hidden="true" style="position:absolute;left:-9999px;top:-9999px;overflow:hidden;height:1px;width:1px;">' .
            '<label for="%1$s">%2$s</label>' .
            '<input type="text" id="%1$s" name="%1$s" value="" autocomplete="off" tabindex="-1" />' .
            '</div>',
            esc_attr( self::FIELD ),
            esc_html__( 'Leave this field empty', 'woo-cod-form' )
        );
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Return whether honeypot protection is currently enabled.
     */
    private static function is_enabled(): bool {
        return (bool) get_option( 'wcf_enable_honeypot', true );
    }
}
