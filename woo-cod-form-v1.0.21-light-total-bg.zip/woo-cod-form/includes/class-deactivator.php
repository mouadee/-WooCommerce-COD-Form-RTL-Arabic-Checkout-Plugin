<?php
/**
 * File: includes/class-deactivator.php
 *
 * Handles plugin deactivation.
 * Options and data are intentionally retained so they survive reactivation.
 * Only scheduled events and rewrite rules are cleaned up.
 */

namespace WCF\Core;

defined( 'ABSPATH' ) || exit;

final class Deactivator {

    /**
     * Run on register_deactivation_hook().
     */
    public static function run(): void {
        // Clear any future cron events registered by the plugin.
        wp_clear_scheduled_hook( 'wcf_cleanup_transients' );

        flush_rewrite_rules();
    }
}
