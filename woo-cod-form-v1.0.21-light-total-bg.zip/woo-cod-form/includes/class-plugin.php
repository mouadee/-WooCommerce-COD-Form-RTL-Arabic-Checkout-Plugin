<?php
/**
 * File: includes/class-plugin.php
 *
 * Main plugin controller — singleton.
 *
 * Boot order:
 *   1. WC integration  — HPOS compat declaration.
 *   2. AJAX routes     — order submit + product data endpoints.
 *   3. Form renderer   — [wcf_order_form] shortcode.
 *   4. Conversion      — trust badges, timer, social proof hooks.
 *   5. Admin panel     — settings pages (self-guards on is_admin()).
 *   6. Webhook notifier— outbound HTTP on new order.
 */

namespace WCF\Core;

use WCF\Modules\Admin\Admin_Panel;
use WCF\Modules\Admin\Webhook_Notifier;
use WCF\Modules\Ajax\Ajax_Router;
use WCF\Modules\Conversion\Conversion_Hooks;
use WCF\Modules\Form\Form_Renderer;
use WCF\Modules\Woocommerce\WC_Bridge;

defined( 'ABSPATH' ) || exit;

final class Plugin {

    /** @var self|null */
    private static ?self $instance = null;

    private function __construct() {
        $this->boot();
    }

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // -----------------------------------------------------------------------
    // Boot sequence
    // -----------------------------------------------------------------------

    private function boot(): void {
        WC_Bridge::init();
        Ajax_Router::init();
        Form_Renderer::init();
        Conversion_Hooks::init();
        Admin_Panel::init();
        Webhook_Notifier::init();
    }
}
