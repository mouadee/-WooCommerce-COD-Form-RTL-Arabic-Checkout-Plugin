<?php
/**
 * File: includes/class-autoloader.php
 *
 * Namespace → filesystem resolver.
 *
 * Mapping rules:
 *   WCF\Core\*                   → includes/class-*.php
 *   WCF\Modules\<Module>\<Class> → modules/<module>/class-<class>.php
 *
 * Class-name → filename conversion:
 *   PascalCase humps → kebab  (OrderFactory  → order-factory)
 *   Underscores      → hyphens (Order_Factory → order-factory)
 *   Prefix           → class-  (order-factory → class-order-factory)
 */

namespace WCF\Core;

defined( 'ABSPATH' ) || exit;

final class Autoloader {

    /**
     * Register this autoloader with PHP's SPL stack.
     */
    public static function register(): void {
        spl_autoload_register( [ new self(), 'load' ] );
    }

    /**
     * Attempt to locate and require a WCF class file.
     */
    public function load( string $class ): void {
        $prefix = 'WCF\\';

        if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
            return;
        }

        $file = $this->resolve( substr( $class, strlen( $prefix ) ) );

        if ( $file !== null && file_exists( $file ) ) {
            require_once $file;
        }
    }

    // -----------------------------------------------------------------------
    // Internal helpers
    // -----------------------------------------------------------------------

    /**
     * Resolve relative namespace string to an absolute file path.
     *
     * @param  string      $relative  e.g. "Core\Plugin" or "Modules\Ajax\Ajax_Order"
     * @return string|null            Absolute path, or null if unmapped.
     */
    private function resolve( string $relative ): ?string {
        $parts     = explode( '\\', $relative );
        $class_raw = (string) array_pop( $parts );
        $file_name = 'class-' . $this->to_kebab( $class_raw ) . '.php';
        $top       = strtolower( $parts[0] ?? '' );

        if ( 'core' === $top ) {
            return WCF_PATH . 'includes/' . $file_name;
        }

        if ( 'modules' === $top && isset( $parts[1] ) ) {
            $module = strtolower( $parts[1] );
            return WCF_MODULES . $module . '/' . $file_name;
        }

        return null;
    }

    /**
     * Convert a PascalCase / Snake_Case class name to kebab-case.
     *
     * Examples:
     *   Plugin         → plugin
     *   OrderFactory   → order-factory
     *   WC_Bridge      → wc-bridge
     *   Rate_Limiter   → rate-limiter
     *   Ajax_Router    → ajax-router
     */
    private function to_kebab( string $name ): string {
        // Insert hyphen between a lowercase letter and an uppercase letter.
        $name = (string) preg_replace( '/([a-z])([A-Z])/', '$1-$2', $name );
        // Replace underscores with hyphens and lowercase everything.
        return strtolower( str_replace( '_', '-', $name ) );
    }
}
