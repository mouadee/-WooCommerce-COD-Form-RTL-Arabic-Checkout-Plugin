<?php
/**
 * File: includes/class-activator.php
 *
 * Handles plugin activation:
 *   - Writes default option values (only when not already present).
 *   - Stores plugin version for future upgrade migrations.
 *   - Flushes rewrite rules.
 *
 * FIX: Added wcf_enable_on_product_page default (false).
 */

namespace WCF\Core;

defined( 'ABSPATH' ) || exit;

final class Activator {

    /**
     * Run on register_activation_hook().
     */
    public static function run(): void {
        self::set_defaults();
        update_option( 'wcf_version', WCF_VERSION );
        flush_rewrite_rules();
    }

    private static function set_defaults(): void {
        $defaults = [

            // Form field schema.
            'wcf_form_fields' => [
                'first_name' => [ 'enabled' => true,  'required' => true,  'label' => 'الاسم الشخصي' ],
                'last_name'  => [ 'enabled' => true,  'required' => false, 'label' => 'الاسم العائلي' ],
                'phone'      => [ 'enabled' => true,  'required' => true,  'label' => 'رقم الهاتف' ],
                'address_1'  => [ 'enabled' => true,  'required' => true,  'label' => 'العنوان' ],
                'address_2'  => [ 'enabled' => false, 'required' => false, 'label' => 'العنوان الإضافي' ],
                'city'       => [ 'enabled' => true,  'required' => true,  'label' => 'المدينة' ],
                'state'      => [ 'enabled' => false, 'required' => false, 'label' => 'الجهة / الولاية' ],
                'postcode'   => [ 'enabled' => false, 'required' => false, 'label' => 'الرمز البريدي' ],
                'email'      => [ 'enabled' => false, 'required' => false, 'label' => 'البريد الإلكتروني' ],
                'notes'      => [ 'enabled' => true,  'required' => false, 'label' => 'ملاحظات الطلب' ],
            ],

            // General.
            'wcf_order_status'           => 'wc-pending',
            'wcf_thankyou_page'          => 0,
            'wcf_inline_confirm'         => true,
            'wcf_default_country'        => 'MA',
            'wcf_currency_code'          => '',
            'wcf_max_quantity'           => 5,

            // BUG FIX: New option — auto-inject form on single product pages.
            'wcf_enable_on_product_page' => false,

            // Security / rate limiting.
            'wcf_rate_limit'     => 5,
            'wcf_rate_window'    => 3600,
            'wcf_enable_honeypot'=> true,
            'wcf_block_duplicate_orders' => true,
            'wcf_duplicate_window'       => 30,

            // Product-specific fields.
            'wcf_product_overrides_enabled' => false,
            'wcf_product_extra_fields' => '',

            // Quantity offers.
            'wcf_quantity_discounts_enabled' => false,
            'wcf_quantity_discount_rules' => '',
            'wcf_offer_badge_text' => 'الأكثر طلباً',

            // Frontend design.
            'wcf_design_mode' => 'premium',
            'wcf_form_width' => 720,
            'wcf_button_color' => '#111827',
            'wcf_border_radius' => 18,
            'wcf_input_size' => 52,
            'wcf_show_product_image' => true,
            'wcf_sticky_summary' => false,
            'wcf_show_trust_badges' => true,
            'wcf_trust_badges_text' => "الدفع عند الاستلام\nتوصيل سريع\nضمان الجودة",

            // Tracking.
            'wcf_facebook_pixel_id' => '',
            'wcf_tiktok_pixel_id' => '',
            'wcf_gtm_id' => '',
            'wcf_tracking_purchase_event' => true,
            'wcf_form_template' => 'moroccan',

            // Conversion tools (all off by default).
            'wcf_timer_enabled'  => false,
            'wcf_timer_minutes'  => 15,
            'wcf_timer_message'  => 'ينتهي العرض خلال:',
            'wcf_badges_enabled' => false,
            'wcf_social_enabled' => false,
            'wcf_social_message' => '{name} من {city} قام بالطلب الآن!',

            // Notifications.
            'wcf_confirm_message'=> 'شكراً لك! تم استلام طلبك وسيتواصل معك فريقنا لتأكيد التوصيل.',
            'wcf_webhook_url'    => '',
        ];

        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $value, '', 'no' );
            }
        }

        if ( false === get_option( 'wcf_admin_email' ) ) {
            add_option( 'wcf_admin_email', get_option( 'admin_email', '' ), '', 'no' );
        }
    }
}
