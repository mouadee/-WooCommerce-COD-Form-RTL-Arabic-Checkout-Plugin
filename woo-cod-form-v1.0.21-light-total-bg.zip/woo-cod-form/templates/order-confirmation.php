<?php
/**
 * Template: order-confirmation.php
 *
 * Displayed inline after a successful COD order submission.
 * Injected into the DOM by cod-form.js — not rendered on page load.
 *
 * This file is only used when the store owner has NOT configured a
 * redirect thank-you page (wcf_thankyou_page = 0).
 *
 * Available variables (passed from JS via wcfData.i18n / order response):
 *   Rendered server-side as a static HTML block, then cloned into the DOM
 *   by cod-form.js after a successful AJAX response.
 *
 * Override: your-theme/woo-cod-form/order-confirmation.php
 */

defined( 'ABSPATH' ) || exit;

$message = (string) get_option(
    'wcf_confirm_message',
    __( 'شكراً لك! تم استلام طلبك وسيتواصل معك فريقنا لتأكيد التوصيل.', 'woo-cod-form' )
);
?>
<div id="wcf-confirmation" class="wcf-confirmation" style="display:none;" aria-live="polite" role="status">

    <div class="wcf-confirmation-icon" aria-hidden="true">&#10003;</div>

    <h2 class="wcf-confirmation-title">
        <?php esc_html_e( 'تم إرسال الطلب!', 'woo-cod-form' ); ?>
    </h2>

    <p class="wcf-confirmation-message">
        <?php echo esc_html( $message ); ?>
    </p>

    <p class="wcf-confirmation-order-id">
        <?php esc_html_e( 'رقم الطلب #', 'woo-cod-form' ); ?>
        <strong class="wcf-order-id-value">—</strong>
    </p>

    <?php do_action( 'wcf_after_confirmation' ); ?>

</div>
