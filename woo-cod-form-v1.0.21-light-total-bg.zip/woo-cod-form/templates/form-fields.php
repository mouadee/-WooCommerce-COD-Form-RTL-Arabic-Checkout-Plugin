<?php
/**
 * Template: form-fields.php
 *
 * Renders billing fields driven by the wcf_form_fields option.
 *
 * Available variables:
 *   $product      array  Product data.
 *   $product_id   int
 *   $variation_id int
 *
 * Override: copy to your-theme/woo-cod-form/form-fields.php
 *
 * FIX: Added fallback field schema so the form never renders with zero
 *      billing fields (which caused silent submit failures at validation).
 */

defined( 'ABSPATH' ) || exit;

$field_schema = class_exists( '\WCF\Modules\Admin\Settings_Manager' )
    ? \WCF\Modules\Admin\Settings_Manager::get_form_fields()
    : (array) get_option( 'wcf_form_fields', [] );

if ( empty( $field_schema ) ) {
    $field_schema = [
        'first_name' => [ 'enabled' => true,  'required' => true,  'label' => __( 'First Name', 'woo-cod-form' ) ],
        'last_name'  => [ 'enabled' => true,  'required' => false, 'label' => __( 'Last Name',  'woo-cod-form' ) ],
        'phone'      => [ 'enabled' => true,  'required' => true,  'label' => __( 'Phone',      'woo-cod-form' ) ],
        'address_1'  => [ 'enabled' => true,  'required' => true,  'label' => __( 'Address',    'woo-cod-form' ) ],
        'city'       => [ 'enabled' => true,  'required' => true,  'label' => __( 'City',       'woo-cod-form' ) ],
        'notes'      => [ 'enabled' => true,  'required' => false, 'label' => __( 'Order Notes','woo-cod-form' ) ],
    ];
}

// -----------------------------------------------------------------------
// Variation selector (always shown for variable products)
// -----------------------------------------------------------------------
?>

<?php if ( ! empty( $product['is_variable'] ) && ! empty( $product['variations'] ) ) : ?>
<div class="wcf-form-row">
    <label for="wcf-variation" class="wcf-label">
        <?php esc_html_e( 'Select Option', 'woo-cod-form' ); ?>
        <span class="wcf-required" aria-hidden="true">*</span>
    </label>
    <select id="wcf-variation" name="variation_id" class="wcf-select" required>
        <option value=""><?php esc_html_e( '— Choose an option —', 'woo-cod-form' ); ?></option>
        <?php foreach ( $product['variations'] as $v ) : ?>
            <?php
            $label_parts = [];
            foreach ( $v['attributes'] as $attr_value ) {
                $label_parts[] = esc_html( $attr_value );
            }
            $option_label = implode( ' / ', $label_parts );
            ?>
            <option value="<?php echo esc_attr( $v['variation_id'] ); ?>"
                    data-price="<?php echo esc_attr( $v['price'] ); ?>"
                    data-price-html="<?php echo esc_attr( $v['price_html'] ); ?>"
                    data-in-stock="<?php echo esc_attr( $v['in_stock'] ? '1' : '0' ); ?>"
                    <?php selected( (int) $variation_id, (int) $v['variation_id'] ); ?>
                    <?php disabled( ! $v['in_stock'] ); ?>>
                <?php echo esc_html( $option_label ); ?>
                <?php if ( ! $v['in_stock'] ) : ?>
                    &mdash; <?php esc_html_e( 'Out of stock', 'woo-cod-form' ); ?>
                <?php endif; ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>
<?php endif; ?>

<?php
$bundles_enabled = (bool) get_option( 'wcf_bundles_enabled', false ) && class_exists( '\WCF\Modules\Admin\Settings_Manager' );
$bundle_offers   = $bundles_enabled ? \WCF\Modules\Admin\Settings_Manager::get_bundle_offers() : [];
$default_bundle  = sanitize_key( (string) get_option( 'wcf_default_bundle', 'bundle_1' ) );
if ( empty( $bundle_offers[ $default_bundle ] ) && ! empty( $bundle_offers ) ) {
    $default_bundle = (string) array_key_first( $bundle_offers );
}
$currency_code = ( (string) get_option( 'wcf_currency_code', '' ) ?: get_woocommerce_currency() );
$free_delivery_text = trim( (string) get_option( 'wcf_free_delivery_text', 'توصيل مجاني' ) );
$urgency_text = trim( (string) get_option( 'wcf_urgency_text', 'العرض صالح اليوم فقط' ) );
?>

<?php ob_start(); ?>
<?php if ( $bundles_enabled && ! empty( $bundle_offers ) ) : ?>
    <div class="wcf-bundle-section" aria-label="<?php esc_attr_e( 'العروض والباقات', 'woo-cod-form' ); ?>">
        <div class="wcf-bundle-section-head">
            <div>
                <span class="wcf-mini-kicker"><?php esc_html_e( 'اختر العرض المناسب', 'woo-cod-form' ); ?></span>
                <strong><?php esc_html_e( 'العروض والباقات', 'woo-cod-form' ); ?></strong>
            </div>
            <?php if ( '' !== $urgency_text ) : ?>
                <span class="wcf-urgency-chip"><?php echo esc_html( $urgency_text ); ?></span>
            <?php endif; ?>
        </div>

        <input type="hidden" id="wcf-selected-bundle" name="selected_bundle" value="<?php echo esc_attr( $default_bundle ); ?>" />
        <input type="hidden" id="wcf-quantity" name="quantity" class="wcf-qty-input" value="<?php echo esc_attr( (int) ( $bundle_offers[ $default_bundle ]['quantity'] ?? 1 ) ); ?>" min="1" max="<?php echo esc_attr( max( 1, (int) ( $product['max_purchase'] ?? get_option( 'wcf_max_quantity', 5 ) ) ) ); ?>" />

        <div class="wcf-bundle-grid">
            <?php foreach ( $bundle_offers as $id => $bundle ) : ?>
                <?php $active = $id === $default_bundle; ?>
                <button type="button"
                        class="wcf-bundle-card <?php echo $active ? 'active' : ''; ?> <?php echo ! empty( $bundle['popular'] ) ? 'is-popular' : ''; ?>"
                        data-bundle-id="<?php echo esc_attr( $id ); ?>"
                        data-qty="<?php echo esc_attr( (int) $bundle['quantity'] ); ?>"
                        data-total="<?php echo esc_attr( (float) $bundle['price'] ); ?>">
                    <?php if ( ! empty( $bundle['popular'] ) || ! empty( $bundle['badge'] ) ) : ?>
                        <span class="wcf-bundle-badge"><?php echo esc_html( ! empty( $bundle['badge'] ) ? $bundle['badge'] : __( 'الأكثر طلباً', 'woo-cod-form' ) ); ?></span>
                    <?php endif; ?>
                    <span class="wcf-bundle-title"><?php echo esc_html( $bundle['title'] ); ?></span>
                    <span class="wcf-bundle-price"><?php echo wp_kses_post( wc_price( (float) $bundle['price'], [ 'currency' => $currency_code ] ) ); ?></span>
                    <span class="wcf-bundle-qty"><?php echo esc_html( sprintf( _n( '%d قطعة', '%d قطع', (int) $bundle['quantity'], 'woo-cod-form' ), (int) $bundle['quantity'] ) ); ?></span>
                </button>
            <?php endforeach; ?>
        </div>

        <?php if ( '' !== $free_delivery_text ) : ?>
            <div class="wcf-free-delivery-note">🚚 <?php echo esc_html( $free_delivery_text ); ?></div>
        <?php endif; ?>
    </div>

    <div class="wcf-price-row wcf-bundle-total-row" id="wcf-price-display">
        <span class="wcf-price-label"><?php esc_html_e( 'المجموع', 'woo-cod-form' ); ?></span>
        <span class="wcf-price-value" id="wcf-price-value">
            <?php echo wp_kses_post( wc_price( (float) ( $bundle_offers[ $default_bundle ]['price'] ?? ( $product['price'] ?? 0 ) ), [ 'currency' => $currency_code ] ) ); ?>
        </span>
    </div>
<?php else : ?>
    <?php /* ── Quantity + Price row ────────────────────────────────────────── */ ?>
    <div class="wcf-qty-price-row">
        <div class="wcf-form-row wcf-quantity-row">
            <label for="wcf-quantity" class="wcf-label">
                <?php esc_html_e( 'الكمية', 'woo-cod-form' ); ?>
                <span class="wcf-required" aria-hidden="true">*</span>
            </label>
            <div class="wcf-quantity-wrap">
                <button type="button" class="wcf-qty-btn wcf-qty-minus"
                        aria-label="<?php esc_attr_e( 'نقص الكمية', 'woo-cod-form' ); ?>">&#8722;</button>
                <input type="number" id="wcf-quantity" name="quantity"
                       class="wcf-input wcf-qty-input"
                       value="1" min="1"
                       max="<?php echo esc_attr( max( 1, (int) ( $product['max_purchase'] ?? get_option( 'wcf_max_quantity', 5 ) ) ) ); ?>"
                       required
                       inputmode="numeric" />
                <button type="button" class="wcf-qty-btn wcf-qty-plus"
                        aria-label="<?php esc_attr_e( 'زد الكمية', 'woo-cod-form' ); ?>">&#43;</button>
            </div>
        </div>

        <div class="wcf-price-row" id="wcf-price-display">
            <span class="wcf-price-label"><?php esc_html_e( 'المجموع', 'woo-cod-form' ); ?></span>
            <span class="wcf-price-value" id="wcf-price-value">
                <?php echo wp_kses_post( $product['price_html'] ?? '' ); ?>
            </span>
        </div>
    </div>

    <?php if ( (bool) get_option( 'wcf_quantity_discounts_enabled', false ) && class_exists( '\WCF\Modules\Admin\Settings_Manager' ) ) : ?>
        <?php $rules = \WCF\Modules\Admin\Settings_Manager::parse_quantity_rules(); ?>
        <?php if ( ! empty( $rules ) ) : ?>
            <div class="wcf-qty-offers" aria-label="<?php esc_attr_e( 'عروض الكمية', 'woo-cod-form' ); ?>">
                <?php foreach ( $rules as $rule ) : ?>
                    <button type="button" class="wcf-offer-pill" data-qty="<?php echo esc_attr( $rule['qty'] ); ?>">
                        <strong><?php echo esc_html( $rule['qty'] ); ?>×</strong>
                        <span><?php echo wp_kses_post( wc_price( $rule['total'], [ 'currency' => $currency_code ] ) ); ?></span>
                        <?php if ( ! empty( $rule['badge'] ) ) : ?><em><?php echo esc_html( $rule['badge'] ); ?></em><?php endif; ?>
                    </button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php $purchase_controls_html = trim( (string) ob_get_clean() ); ?>

<?php /* ── Billing fields ───────────────────────────────────────────────── */ ?>
<div class="wcf-fields-grid <?php echo ( ! empty( $field_schema['first_name']['enabled'] ) && ! empty( $field_schema['last_name']['enabled'] ) ) ? 'has-two-name-columns' : ''; ?>">
<?php
foreach ( $field_schema as $field_key => $config ) :
    if ( empty( $config['enabled'] ) ) {
        continue;
    }
    $required = ! empty( $config['required'] );
    $label    = $config['label'] ?? ucfirst( str_replace( '_', ' ', $field_key ) );
    $input_id = 'wcf-field-' . sanitize_html_class( $field_key );
    $name     = 'wcf_' . $field_key;
    $type     = 'phone' === $field_key ? 'tel' : 'text';

    // Use two columns only when both first_name and last_name are enabled.
    // If one of them is disabled, keep the remaining field full width.
    $row_class = 'wcf-form-row wcf-field-' . sanitize_html_class( $field_key );
    $two_name_columns = ! empty( $field_schema['first_name']['enabled'] ) && ! empty( $field_schema['last_name']['enabled'] );
    if ( $two_name_columns && in_array( $field_key, [ 'first_name', 'last_name' ], true ) ) {
        $row_class .= ' wcf-col-half';
    }

    if ( 'notes' === $field_key ) :
?>
    <div class="<?php echo esc_attr( $row_class ); ?>">
        <label for="<?php echo esc_attr( $input_id ); ?>" class="wcf-label">
            <?php echo esc_html( $label ); ?>
            <?php if ( $required ) : ?><span class="wcf-required" aria-hidden="true">*</span><?php endif; ?>
        </label>
        <textarea id="<?php echo esc_attr( $input_id ); ?>"
                  name="<?php echo esc_attr( $name ); ?>"
                  class="wcf-input wcf-textarea"
                  rows="3"
                  <?php echo $required ? 'required' : ''; ?>
                  placeholder="<?php echo esc_attr( $label ); ?>"></textarea>
        <span class="wcf-field-error" role="alert" aria-live="polite"></span>
    </div>
<?php
    else :
?>
    <div class="<?php echo esc_attr( $row_class ); ?>">
        <label for="<?php echo esc_attr( $input_id ); ?>" class="wcf-label">
            <?php echo esc_html( $label ); ?>
            <?php if ( $required ) : ?><span class="wcf-required" aria-hidden="true">*</span><?php endif; ?>
        </label>
        <input type="<?php echo esc_attr( $type ); ?>"
               id="<?php echo esc_attr( $input_id ); ?>"
               name="<?php echo esc_attr( $name ); ?>"
               class="wcf-input"
               <?php echo $required ? 'required' : ''; ?>
               placeholder="<?php echo esc_attr( $label ); ?>"
               autocomplete="billing-<?php echo esc_attr( str_replace( '_', '-', $field_key ) ); ?>" />
        <span class="wcf-field-error" role="alert" aria-live="polite"></span>
    </div>
<?php
    endif;
endforeach;

if ( class_exists( '\WCF\Modules\Admin\Settings_Manager' ) ) :
    $extra_fields = \WCF\Modules\Admin\Settings_Manager::get_product_extra_fields( (int) $product_id );
    foreach ( $extra_fields as $extra ) :
        $field_key = 'extra_' . sanitize_key( $extra['key'] );
        $required  = ! empty( $extra['required'] );
        $input_id  = 'wcf-field-' . sanitize_html_class( $field_key );
?>
    <div class="wcf-form-row wcf-field-extra">
        <label for="<?php echo esc_attr( $input_id ); ?>" class="wcf-label">
            <?php echo esc_html( $extra['label'] ); ?>
            <?php if ( $required ) : ?><span class="wcf-required" aria-hidden="true">*</span><?php endif; ?>
        </label>
        <?php if ( str_starts_with( (string) $extra['type'], 'select:' ) ) : ?>
            <?php $options = array_filter( array_map( 'trim', explode( ',', substr( (string) $extra['type'], 7 ) ) ) ); ?>
            <select id="<?php echo esc_attr( $input_id ); ?>" name="wcf_<?php echo esc_attr( $field_key ); ?>" class="wcf-select" <?php echo $required ? 'required' : ''; ?>>
                <option value=""><?php esc_html_e( 'اختر', 'woo-cod-form' ); ?></option>
                <?php foreach ( $options as $option ) : ?><option value="<?php echo esc_attr( $option ); ?>"><?php echo esc_html( $option ); ?></option><?php endforeach; ?>
            </select>
        <?php else : ?>
            <input type="text" id="<?php echo esc_attr( $input_id ); ?>" name="wcf_<?php echo esc_attr( $field_key ); ?>" class="wcf-input" <?php echo $required ? 'required' : ''; ?> placeholder="<?php echo esc_attr( $extra['label'] ); ?>" />
        <?php endif; ?>
        <span class="wcf-field-error" role="alert" aria-live="polite"></span>
    </div>
<?php
    endforeach;
endif;
?>
</div><!-- /.wcf-fields-grid -->

<?php if ( '' !== $purchase_controls_html ) : ?>
<div class="wcf-purchase-controls">
    <?php echo $purchase_controls_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
<?php endif; ?>
