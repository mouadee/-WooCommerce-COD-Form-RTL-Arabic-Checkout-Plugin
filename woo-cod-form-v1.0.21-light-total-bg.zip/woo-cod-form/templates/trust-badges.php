<?php
/**
 * Template: trust-badges.php
 *
 * Renders the trust badge strip below/above the form.
 * Hooked to wcf_before_form via Conversion module when enabled.
 *
 * Override: your-theme/woo-cod-form/trust-badges.php
 */

defined( 'ABSPATH' ) || exit;

if ( ! get_option( 'wcf_badges_enabled', false ) ) {
    return;
}

$badges = [
    [
        'icon'  => '🛡️',
        'label' => __( 'Secure Order', 'woo-cod-form' ),
    ],
    [
        'icon'  => '🚚',
        'label' => __( 'Fast Delivery', 'woo-cod-form' ),
    ],
    [
        'icon'  => '💵',
        'label' => __( 'Cash on Delivery', 'woo-cod-form' ),
    ],
    [
        'icon'  => '↩️',
        'label' => __( 'Easy Returns', 'woo-cod-form' ),
    ],
];

/**
 * Filter: wcf_trust_badges
 * Allows developers to modify the badge array.
 *
 * @param array $badges  Array of ['icon' => string, 'label' => string].
 */
$badges = apply_filters( 'wcf_trust_badges', $badges );

if ( empty( $badges ) ) {
    return;
}
?>
<div class="wcf-trust-badges" aria-label="<?php esc_attr_e( 'Trust indicators', 'woo-cod-form' ); ?>">
    <?php foreach ( $badges as $badge ) : ?>
        <div class="wcf-badge">
            <span class="wcf-badge-icon" aria-hidden="true">
                <?php echo esc_html( $badge['icon'] ?? '' ); ?>
            </span>
            <span class="wcf-badge-label">
                <?php echo esc_html( $badge['label'] ?? '' ); ?>
            </span>
        </div>
    <?php endforeach; ?>
</div>
