<?php
/**
 * Template: form-main.php
 *
 * Main COD order form template.
 *
 * Available variables (extracted by Form_Renderer::get_template_html()):
 *   $product_id   int    WooCommerce product ID.
 *   $variation_id int    Active variation ID (0 if none).
 *   $product      array  Formatted product data from Product_Handler.
 *
 * Override: copy to wp-content/themes/your-theme/woo-cod-form/form-main.php
 *
 * FIX: Added product header (thumbnail + name + price) so users know
 *      what they're ordering. Previously the form had zero product context.
 */

use WCF\Modules\Security\Honeypot;
use WCF\Modules\Security\Nonce_Manager;

defined( 'ABSPATH' ) || exit;

// Resolve product thumbnail — uses WordPress's native attachment system.
$thumb_html = get_the_post_thumbnail(
    $product_id,
    'woocommerce_thumbnail',
    [ 'class' => 'wcf-product-img', 'loading' => 'lazy' ]
);
?>
<?php
$design_mode   = (string) get_option( 'wcf_design_mode', 'premium' );
$form_template = sanitize_key( (string) get_option( 'wcf_form_template', 'moroccan' ) );
if ( ! in_array( $form_template, [ 'moroccan', 'minimal', 'fashion', 'electronics' ], true ) ) {
    $form_template = 'moroccan';
}
?>
<div id="wcf-form-wrap" class="wcf-form-wrap wcf-design-<?php echo esc_attr( $design_mode ); ?> wcf-template-<?php echo esc_attr( $form_template ); ?>" dir="rtl" data-product-id="<?php echo esc_attr( $product_id ); ?>" data-form-template="<?php echo esc_attr( $form_template ); ?>">

    <?php
    /**
     * Hook: wcf_before_form
     * Inject trust badges, timer, social proof above the form.
     */
    do_action( 'wcf_before_form', $product_id, $product );
    ?>

    <div class="wcf-order-form-shell">

        <?php /* ── Product header ────────────────────────────────────────────── */ ?>
        <div class="wcf-product-header">
            <?php if ( $thumb_html && (bool) get_option( 'wcf_show_product_image', true ) ) : ?>
                <div class="wcf-product-thumb-wrap">
                    <?php echo $thumb_html; // WP-produced, safe to output. ?>
                </div>
            <?php endif; ?>
            <div class="wcf-product-meta">
                <p class="wcf-product-label"><?php esc_html_e( 'أنت تطلب', 'woo-cod-form' ); ?></p>
                <h3 class="wcf-product-name"><?php echo esc_html( $product['name'] ?? '' ); ?></h3>
                <div class="wcf-product-price-wrap">
                    <?php echo wp_kses_post( $product['price_html'] ?? '' ); ?>
                </div>
            </div>
            <div class="wcf-cod-badge">
                <span class="wcf-cod-badge-icon">💵</span>
                <span><?php esc_html_e( 'الدفع عند الاستلام', 'woo-cod-form' ); ?></span>
            </div>
        </div>


        <?php if ( (bool) get_option( 'wcf_show_trust_badges', true ) ) : ?>
            <div class="wcf-custom-trust-badges">
                <?php foreach ( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_option( 'wcf_trust_badges_text', "الدفع عند الاستلام
توصيل سريع
ضمان الجودة" ) ) ) ) as $badge_text ) : ?>
                    <span class="wcf-custom-badge">✓ <?php echo esc_html( $badge_text ); ?></span>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php /* ── Order form ──────────────────────────────────────────────────── */ ?>
        <form id="wcf-order-form" class="wcf-order-form" novalidate>

            <?php Nonce_Manager::field(); ?>
            <?php Honeypot::render_field(); ?>

            <input type="hidden" name="action"     value="wcf_submit_order" />
            <input type="hidden" name="product_id" value="<?php echo esc_attr( $product_id ); ?>" />
            <input type="hidden" name="variation_id" id="wcf-variation-id"
                   value="<?php echo esc_attr( $variation_id ); ?>" />

            <?php do_action( 'wcf_form_before_fields', $product_id ); ?>

            <div class="wcf-section-label"><?php esc_html_e( 'معلومات التوصيل', 'woo-cod-form' ); ?></div>

            <?php echo \WCF\Modules\Form\Form_Renderer::get_template_html( 'form-fields.php', [
                'product'      => $product,
                'product_id'   => $product_id,
                'variation_id' => $variation_id,
            ] ); ?>

            <?php do_action( 'wcf_form_after_fields', $product_id ); ?>

            <div class="wcf-form-row wcf-submit-row">
                <button type="submit" id="wcf-submit-btn" class="wcf-btn wcf-btn-primary">
                    <span class="wcf-btn-text">
                        <span class="wcf-btn-icon" aria-hidden="true">🛒</span>
                        <?php esc_html_e( 'اطلب الآن — الدفع عند الاستلام', 'woo-cod-form' ); ?>
                    </span>
                    <span class="wcf-btn-loading" aria-hidden="true" style="display:none;">
                        <span class="wcf-spinner"></span>
                        <?php esc_html_e( 'جاري إرسال الطلب…', 'woo-cod-form' ); ?>
                    </span>
                </button>
            </div>

            <div id="wcf-form-messages" class="wcf-form-messages" role="alert" aria-live="polite"></div>

        </form>

    </div><!-- /.wcf-order-form-shell -->

    <?php do_action( 'wcf_after_form', $product_id, $product ); ?>

</div>
