<?php
/**
 * Plugin Name:       WooCommerce COD Form
 * Plugin URI:        https://github.com/your-repo/woo-cod-form
 * Description:       High-conversion one-page Cash On Delivery order form for WooCommerce.
 * Version:           1.0.21
 * Author:            Your Name
 * Author URI:        https://yourwebsite.com
 * License:           GPL-2.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       woo-cod-form
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * WC requires at least: 7.0
 * WC tested up to:   9.0
 */

defined( 'ABSPATH' ) || exit;

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

define( 'WCF_VERSION',    '1.0.21' );
define( 'WCF_FILE',       __FILE__ );
define( 'WCF_PATH',       plugin_dir_path( __FILE__ ) );
define( 'WCF_URL',        plugin_dir_url( __FILE__ ) );
define( 'WCF_BASENAME',   plugin_basename( __FILE__ ) );
define( 'WCF_MODULES',    WCF_PATH . 'modules/' );
define( 'WCF_TEMPLATES',  WCF_PATH . 'templates/' );
define( 'WCF_ASSETS_URL', WCF_URL  . 'public/' );

// ---------------------------------------------------------------------------
// Autoloader — must be loaded manually before any WCF class can be resolved.
// ---------------------------------------------------------------------------

require_once WCF_PATH . 'includes/class-autoloader.php';
\WCF\Core\Autoloader::register();

// ---------------------------------------------------------------------------
// WooCommerce dependency helpers
// ---------------------------------------------------------------------------

/**
 * Returns true when WooCommerce is active (network-aware).
 */
function wcf_woocommerce_is_active(): bool {
    $plugin = 'woocommerce/woocommerce.php';

    if ( in_array( $plugin, (array) get_option( 'active_plugins', [] ), true ) ) {
        return true;
    }

    if ( is_multisite() ) {
        $network = get_site_option( 'active_sitewide_plugins', [] );
        return isset( $network[ $plugin ] );
    }

    return false;
}

/**
 * Admin notice when WooCommerce is missing.
 */
function wcf_missing_wc_notice(): void {
    printf(
        '<div class="notice notice-error is-dismissible"><p><strong>%s</strong> &mdash; %s</p></div>',
        esc_html__( 'WooCommerce COD Form', 'woo-cod-form' ),
        esc_html__( 'This plugin requires WooCommerce to be installed and active.', 'woo-cod-form' )
    );
}


// ---------------------------------------------------------------------------
// Arabic interface translation (plugin-only)
// ---------------------------------------------------------------------------

function wcf_arabic_translate( string $translated, string $text, string $domain ): string {
    if ( 'woo-cod-form' !== $domain ) {
        return $translated;
    }

    $map = [
        'WooCommerce COD Form' => 'نموذج الدفع عند الاستلام',
        'COD Form Settings' => 'إعدادات نموذج الدفع عند الاستلام',
        'COD Form' => 'نموذج COD',
        'Settings' => 'الإعدادات',
        'General' => 'عام',
        'Form Builder' => 'منشئ النموذج',
        'Conversion Tools' => 'أدوات التحويل',
        'Notifications' => 'الإشعارات',
        'Analytics' => 'التحليلات',
        'General Settings' => 'الإعدادات العامة',
        'Default Order Status' => 'حالة الطلب الافتراضية',
        'Thank You Page' => 'صفحة الشكر',
        'Inline Confirmation' => 'تأكيد داخل الصفحة',
        'Default Country' => 'الدولة الافتراضية',
        'Show Form on Product Pages' => 'إظهار النموذج في صفحات المنتجات',
        'Status applied to orders immediately after submission.' => 'الحالة التي تطبق على الطلب مباشرة بعد الإرسال.',
        '— Inline confirmation (no redirect) —' => '— تأكيد داخل الصفحة بدون تحويل —',
        'Show confirmation message inline without redirecting.' => 'إظهار رسالة التأكيد داخل الصفحة بدون تحويل.',
        'Automatically inject the COD form on single product pages (replaces / sits alongside the default Add to Cart button).' => 'إظهار نموذج الدفع عند الاستلام تلقائياً داخل صفحة المنتج.',
        'When disabled, use the [wcf_order_form product_id="X"] shortcode to place the form manually.' => 'عند التعطيل، استعمل الكود المختصر [wcf_order_form product_id="X"] لوضع النموذج يدوياً.',
        'Form Fields' => 'حقول النموذج',
        'Field Configuration' => 'إعدادات الحقول',
        'Control which fields appear in the COD form, rename labels, and choose required fields.' => 'تحكم في الحقول التي تظهر في نموذج الطلب، غيّر التسميات، وحدد الحقول الإجبارية.',
        'Field' => 'الحقل',
        'Show' => 'إظهار',
        'Label' => 'التسمية',
        'Required' => 'إجباري',
        'Required for COD' => 'إجباري لطلبات COD',
        'Enable Countdown Timer' => 'تفعيل العد التنازلي',
        'Enable Trust Badges' => 'تفعيل شارات الثقة',
        'Enable Social Proof' => 'تفعيل الدليل الاجتماعي',
        'Timer Duration (minutes)' => 'مدة المؤقت بالدقائق',
        'Timer Urgency Message' => 'رسالة الاستعجال',
        'Social Proof Message Template' => 'قالب رسالة الدليل الاجتماعي',
        'Admin Notification Email' => 'بريد إشعارات الإدارة',
        'Order Confirmation Message' => 'رسالة تأكيد الطلب',
        'Custom Webhook URL (on new order)' => 'رابط Webhook مخصص عند وصول طلب جديد',
        'COD Form — Order Analytics' => 'تحليلات طلبات الدفع عند الاستلام',
        'Total Orders (All Time)' => 'إجمالي الطلبات',
        'Orders (Last 30 Days)' => 'طلبات آخر 30 يوماً',
        'Revenue (Completed Orders)' => 'الأرباح من الطلبات المكتملة',
        'Orders by Status' => 'الطلبات حسب الحالة',
        'Status' => 'الحالة',
        'Count' => 'العدد',
        'Only orders created via the COD Form are counted here.' => 'يتم احتساب الطلبات التي أنشئت عبر نموذج COD فقط.',
        'You do not have permission to access this page.' => 'ليست لديك صلاحية الوصول إلى هذه الصفحة.',
        'Settings view not found.' => 'صفحة الإعدادات غير موجودة.',
        'This plugin requires WooCommerce to be installed and active.' => 'هذا الإضافة تحتاج إلى WooCommerce مثبت ومفعل.',
        'You\'re ordering' => 'أنت تطلب',
        'Cash on Delivery' => 'الدفع عند الاستلام',
        'Delivery Details' => 'معلومات التوصيل',
        'Order Now — Cash on Delivery' => 'اطلب الآن — الدفع عند الاستلام',
        'Placing your order…' => 'جاري إرسال طلبك…',
        'Quantity' => 'الكمية',
        'Total' => 'المجموع',
        'Select Option' => 'اختر النوع',
        '— Choose an option —' => '— اختر خياراً —',
        'Out of stock' => 'غير متوفر',
        'Out of stock.' => 'غير متوفر.',
        'Decrease quantity' => 'تقليل الكمية',
        'Increase quantity' => 'زيادة الكمية',
        'First Name' => 'الاسم الشخصي',
        'Last Name' => 'الاسم العائلي',
        'Phone' => 'رقم الهاتف',
        'Address' => 'العنوان',
        'City' => 'المدينة',
        'Order Notes' => 'ملاحظات الطلب',
        'Placing order…' => 'جاري إرسال الطلب…',
        'Order placed successfully!' => 'تم إرسال الطلب بنجاح!',
        'Something went wrong. Please try again.' => 'حدث خطأ. حاول مرة أخرى.',
        'Please select a product option.' => 'يرجى اختيار نوع المنتج.',
        'Please enter a valid phone number.' => 'يرجى إدخال رقم هاتف صحيح.',
        'Please enter a valid email address.' => 'يرجى إدخال بريد إلكتروني صحيح.',
        'Sorry, this product is currently out of stock.' => 'عذراً، هذا المنتج غير متوفر حالياً.',
        'The selected product does not exist.' => 'المنتج المحدد غير موجود.',
        'The selected product option is invalid.' => 'خيار المنتج المحدد غير صحيح.',
        'The selected product option does not match this product.' => 'خيار المنتج المحدد لا يطابق هذا المنتج.',
        'This product cannot be purchased.' => 'لا يمكن شراء هذا المنتج.',
        'Could not create order. Please try again.' => 'تعذر إنشاء الطلب. حاول مرة أخرى.',
        'Order submitted via COD Form.' => 'تم إرسال الطلب عبر نموذج COD.',
        'Order could not be saved. Please try again.' => 'تعذر حفظ الطلب. حاول مرة أخرى.',
        'Product' => 'المنتج',
        'Product option' => 'خيار المنتج',
        'First name' => 'الاسم الشخصي',
        'Last name' => 'الاسم العائلي',
        'Phone number' => 'رقم الهاتف',
        'State' => 'الجهة',
        'Postcode' => 'الرمز البريدي',
        'Email address' => 'البريد الإلكتروني',
        'Order notes' => 'ملاحظات الطلب',

        'Order Placed!' => 'تم إرسال الطلب!',
        'Order #' => 'رقم الطلب #',
        'Thank you! Your order has been received. Our team will contact you to confirm delivery.' => 'شكراً لك! تم استلام طلبك وسيتواصل معك فريقنا لتأكيد التوصيل.',
        'Save Changes' => 'حفظ التغييرات',
    ];

    return $map[ $text ] ?? $translated;
}
add_filter( 'gettext', 'wcf_arabic_translate', 20, 3 );

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------

add_action( 'plugins_loaded', static function (): void {

    if ( ! wcf_woocommerce_is_active() ) {
        add_action( 'admin_notices', 'wcf_missing_wc_notice' );
        return;
    }

    load_plugin_textdomain( 'woo-cod-form', false, dirname( WCF_BASENAME ) . '/languages/' );

    \WCF\Core\Plugin::instance();

}, 10 );

// ---------------------------------------------------------------------------
// Lifecycle hooks
// ---------------------------------------------------------------------------

register_activation_hook( WCF_FILE, static function (): void {
    \WCF\Core\Activator::run();
} );

register_deactivation_hook( WCF_FILE, static function (): void {
    \WCF\Core\Deactivator::run();
} );
