<?php
/**
 * Uninstall — runs when the plugin is deleted from the WP admin.
 * Removes all plugin options and transients from the database.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Complete list of every option the plugin registers.
$options = [
    // Core.
    'wcf_version',

    // Form / field schema.
    'wcf_form_fields',

    // General settings.
    'wcf_order_status',
    'wcf_thankyou_page',
    'wcf_inline_confirm',
    'wcf_default_country',

    // Security.
    'wcf_rate_limit',
    'wcf_rate_window',
    'wcf_enable_honeypot',

    // Conversion tools.
    'wcf_timer_enabled',
    'wcf_timer_minutes',
    'wcf_timer_message',
    'wcf_badges_enabled',
    'wcf_social_enabled',
    'wcf_social_message',

    // Notifications.
    'wcf_admin_email',
    'wcf_confirm_message',
    'wcf_webhook_url',
];

foreach ( $options as $option ) {
    delete_option( $option );
    delete_site_option( $option ); // Multisite safety.
}

// Bulk-remove rate-limiting transients (no WP API for pattern-based deletion).
global $wpdb;

// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query(
    "DELETE FROM {$wpdb->options}
     WHERE option_name LIKE '\_transient\_wcf\_rl\_%'
        OR option_name LIKE '\_transient\_timeout\_wcf\_rl\_%'"
);
